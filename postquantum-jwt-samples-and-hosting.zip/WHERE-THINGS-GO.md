# Where each file goes in the repo

Everything here mirrors the layout it should have in `postquantum-jwt/`.

```
postquantum-jwt/
├── README.md                         <- replace with README.patched.md (drop-in), OR
│                                        follow README-Try-It-MERGE.md to hand-edit
├── README.patched.md                 <- your real README with the Try-it block already merged
├── README-Try-It-MERGE.md            <- step-by-step if you prefer to edit by hand
├── .github/workflows/
│   └── deploy-playground.yml         <- continuous deploy to Azure Container Apps
├── docs/img/
│   ├── README.md                     <- how to capture the two assets
│   ├── playground-why-rejected.png   <- you add this (screenshot)
│   └── console-attack-mode.gif       <- you add this (recording)
└── samples/
    ├── README.md
    ├── Shared/                       <- Pq.Samples.Shared (RejectionExplainer)
    ├── ConsoleDemo/
    ├── WebApiDemo/            (+ FileBackedSigningKey.cs for key persistence)
    ├── VerifierDemo/          (2nd service; cross-service rotation)
    ├── SpecByExample/         (xUnit "lessons as test names")
    ├── DistributedReplayCache/ (Redis / IDistributedCache replay cache)
    ├── TestingSupport/        (no-crypto test auth handler for consumers)
    ├── RefreshTokenDemo/      (access/refresh split, rotation, reuse detection)
    ├── SECURE-USAGE.md        (architecture-around-the-token guide)
    ├── HARDENING-CHECKLIST.md (attack -> how the library blocks it)
    ├── docker-compose.yml     (issuer + verifier, isolated network)
    ├── LLM-USAGE.md           (rules for AI assistants consuming the library)
    ├── .cursorrules
    └── PqJwtPlayground/
        ├── DEPLOY.md                 <- Azure Container Apps host guide
        ├── CUSTOM-DOMAIN.md          <- pqjwt.systemslibrarian.dev via Cloudflare + managed cert
        └── deploy.sh                 <- one-shot build+deploy script
```

## Order of operations

1. Copy `samples/`, `.github/`, and `docs/` into the repo root (merge with any
   existing `.github/`).
   `README.md` (after the badges, before the "Read this first" callout), then
3. Follow `samples/PqJwtPlayground/DEPLOY.md` to deploy. Copy the resulting URL
   into the `<LIVE_URL>` placeholder in the README.
4. Capture the screenshot + GIF (see `docs/img/README.md`) and drop them in
   `docs/img/`.
5. `dotnet build` once locally to confirm everything compiles against your SDK.

---

*To God be the glory — 1 Corinthians 10:31.*


## library-patches/ (NOT samples — changes to src/)

`library-patches/` is a SIBLING of `samples/`, not part of it. It contains
proposed changes to the library itself:

- `PqJwtValidator.cs` — patched validator with OpenTelemetry metrics (#2). Apply
  to `src/PostQuantum.Jwt/PqJwtValidator.cs`, build, run the 79-test suite.
- `PostQuantum.Jwt.Analyzers/` — starting-point Roslyn analyzer (#3). Promote to
  `src/PostQuantum.Jwt.Analyzers` and finish (tests, code-fixes, packaging).

See `library-patches/README.md` for the full rationale and the tradeoffs.
Do NOT copy these into `samples/`.
