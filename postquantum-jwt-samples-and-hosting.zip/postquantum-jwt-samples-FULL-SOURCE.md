# PostQuantum.Jwt — Full Source for Review (v3.2)

Single concatenated document of the samples bundle PLUS two library-level
enhancements, for end-to-end AI review. v3.1 applies reviewer hardening: PQJWT001 now resolves symbols (no false positives), the test handler refuses non-test environments, and the metrics message-coupling is flagged for contributors. (v3 added four items:
(#1) a no-crypto test auth handler, (#2) validation METRICS patched into
PqJwtValidator, (#3) a Roslyn usage analyzer, and (#4) a distributed replay cache.

## Orientation

`PostQuantum.Jwt` (.NET 10): hybrid post-quantum JWTs — ML-DSA-65 signatures,
optional X-Wing (X25519 + ML-KEM-768) + AES-256-GCM. FAIL-CLOSED:
`Validate()` returns only on success and THROWS `PqJwtValidationException`
otherwise (no `IsValid`). Identifiers are NOT IANA-registered -> deliberately
non-interoperable. Preview, unaudited.

## What's a SAMPLE vs a LIBRARY change

- Everything under `samples/` references the library via ProjectReference and
  is isolated — low risk.
- Everything under `library-patches/` MODIFIES the library: the metrics change
  edits `src/PostQuantum.Jwt/PqJwtValidator.cs`, and the analyzer ships in the
  nupkg. These need a local build + the existing 79-test suite before shipping.

## Review asks for this round

- **Metrics patch**: confirm the instrumentation is purely additive and the
  fail-closed control flow is unchanged. The `reason` mapping is coupled to the
  validator's message strings — flag if that coupling concerns you.
- **Analyzer**: it's a starting point; assess the syntax/symbol checks and the
  known gaps listed in its README. No test project yet.
- **Distributed cache**: verify the atomicity argument (Redis SET NX vs the
  IDistributedCache race) — this is a correctness-critical security claim.
- **Test handler**: confirm it can never authenticate outside a test host.
- None of this was compiled in the authoring environment.)

v3.2 adds, from a set of web-auth/bug-bounty articles: a refresh-token
rotation demo (access/refresh split, reuse detection), a SECURE-USAGE guide,
and a HARDENING-CHECKLIST mapping each classic JWT attack to how the library
already blocks it. NOTE: the articles validated the library more than they
changed it — alg:none, algorithm confusion, and weak-secret attacks are
impossible by design, so these additions are demos/docs, not library edits.




## Contents

1. `samples/README.md`
2. `samples/LLM-USAGE.md`
3. `samples/.cursorrules`
4. `samples/docker-compose.yml`
5. `samples/Shared/Pq.Samples.Shared.csproj`
6. `samples/Shared/RejectionExplainer.cs`
7. `samples/ConsoleDemo/ConsoleDemo.csproj`
8. `samples/ConsoleDemo/Program.cs`
9. `samples/ConsoleDemo/README.md`
10. `samples/WebApiDemo/WebApiDemo.csproj`
11. `samples/WebApiDemo/Program.cs`
12. `samples/WebApiDemo/FileBackedSigningKey.cs`
13. `samples/WebApiDemo/appsettings.json`
14. `samples/WebApiDemo/Properties/launchSettings.json`
15. `samples/WebApiDemo/WebApiDemo.http`
16. `samples/WebApiDemo/Dockerfile`
17. `samples/WebApiDemo/README.md`
18. `samples/VerifierDemo/VerifierDemo.csproj`
19. `samples/VerifierDemo/Program.cs`
20. `samples/VerifierDemo/appsettings.json`
21. `samples/VerifierDemo/Properties/launchSettings.json`
22. `samples/VerifierDemo/Dockerfile`
23. `samples/VerifierDemo/README.md`
24. `samples/SpecByExample/SpecByExample.csproj`
25. `samples/SpecByExample/SpecByExample.cs`
26. `samples/SpecByExample/README.md`
27. `samples/DistributedReplayCache/DistributedReplayCache.csproj`
28. `samples/DistributedReplayCache/DistributedReplayCache.cs`
29. `samples/DistributedReplayCache/README.md`
30. `samples/TestingSupport/TestingSupport.csproj`
31. `samples/TestingSupport/TestPqJwtAuthHandler.cs`
32. `samples/TestingSupport/README.md`
33. `samples/RefreshTokenDemo/RefreshTokenDemo.csproj`
34. `samples/RefreshTokenDemo/Program.cs`
35. `samples/RefreshTokenDemo/appsettings.json`
36. `samples/RefreshTokenDemo/Properties/launchSettings.json`
37. `samples/RefreshTokenDemo/Dockerfile`
38. `samples/RefreshTokenDemo/README.md`
39. `samples/SECURE-USAGE.md`
40. `samples/HARDENING-CHECKLIST.md`
41. `samples/PqJwtPlayground/PqJwtPlayground.csproj`
42. `samples/PqJwtPlayground/Program.cs`
43. `samples/PqJwtPlayground/Services/PqJwtDemoService.cs`
44. `samples/PqJwtPlayground/Components/_Imports.razor`
45. `samples/PqJwtPlayground/Components/App.razor`
46. `samples/PqJwtPlayground/Components/Routes.razor`
47. `samples/PqJwtPlayground/Components/Layout/MainLayout.razor`
48. `samples/PqJwtPlayground/Components/Pages/Home.razor`
49. `samples/PqJwtPlayground/Components/Pages/SizeBar.razor`
50. `samples/PqJwtPlayground/wwwroot/app.css`
51. `samples/PqJwtPlayground/appsettings.json`
52. `samples/PqJwtPlayground/Properties/launchSettings.json`
53. `samples/PqJwtPlayground/Dockerfile`
54. `samples/PqJwtPlayground/README.md`
55. `samples/PqJwtPlayground/deploy.sh`
56. `samples/PqJwtPlayground/DEPLOY.md`
57. `samples/PqJwtPlayground/CUSTOM-DOMAIN.md`
58. `.github/workflows/deploy-playground.yml`
59. `docs/img/README.md`
60. `library-patches/README-METRICS-PATCH.md`
61. `library-patches/PqJwtValidator.cs`
62. `library-patches/PostQuantum.Jwt.Analyzers/PqJwtUsageAnalyzer.cs`
63. `library-patches/PostQuantum.Jwt.Analyzers/PostQuantum.Jwt.Analyzers.csproj`
64. `library-patches/PostQuantum.Jwt.Analyzers/README.md`

---

## 1. `samples/README.md`

~~~markdown
# PostQuantum.Jwt — Samples

Runnable demonstrations of the [PostQuantum.Jwt](../README.md) library.

| Project              | What it is                                  | Best for                          |
| -------------------- | ------------------------------------------- | --------------------------------- |
| `ConsoleDemo`        | Menu-driven console app (Spectre.Console)   | Seeing every feature fast         |
| `WebApiDemo`         | Minimal ASP.NET Core API, `AddPqJwtBearer`  | Real service integration          |
| `VerifierDemo`       | Second service that verifies via the issuer's key directory | Cross-service key rotation |
| `PqJwtPlayground`    | Blazor Server interactive UI                | Building/validating in a browser  |
| `SpecByExample`      | xUnit tests whose names are the lessons     | Learning by stepping through code |
| `DistributedReplayCache` | Redis / IDistributedCache `IPqJwtReplayCache` | Multi-node replay defense |
| `TestingSupport`     | No-crypto test auth handler                 | Testing your own `[Authorize]` endpoints |
| `RefreshTokenDemo`   | Access/refresh split with rotation + reuse detection | Logout & revocation around the token |
| `DistributedReplayCache` | `IPqJwtReplayCache` over Redis/`IDistributedCache` | Replay defense in a cluster |
| `TestingSupport`     | Test auth handler that bypasses crypto      | Testing your own `[Authorize]` endpoints |
| `Pq.Samples.Shared`  | Tiny shared library (`RejectionExplainer`)  | One source of truth for one thing |

All samples reference the local `src/` projects, so no NuGet install is needed
for development.

## For AI coding assistants

If you're using an AI assistant to build **on** this library, point it at
[`LLM-USAGE.md`](LLM-USAGE.md) (and [`.cursorrules`](.cursorrules)). Generic JWT
knowledge produces wrong code here — the library is fail-closed, single-suite,
and intentionally non-interoperable. Those files state the rules.

## Two-service demo (issuer + verifier)

[`docker-compose.yml`](docker-compose.yml) runs `WebApiDemo` (issuer) and
`VerifierDemo` (verifier) on an isolated network. The verifier validates the
issuer's tokens using public keys it fetches from `/.well-known/pqjwt-keys` —
no shared secret. Run from the repo root:

```bash
docker compose -f samples/docker-compose.yml up --build
```

## Key persistence

`WebApiDemo` generates an ephemeral key by default (and warns about it). Set
`PQJWT_KEY_PATH` to switch on persistence via
[`FileBackedSigningKey`](WebApiDemo/FileBackedSigningKey.cs), which shows the
real encrypted-PKCS#8 export/import lifecycle so tokens survive restarts.

## About `Pq.Samples.Shared`

The samples are otherwise self-contained. The one exception is
`RejectionExplainer`, which maps the validator's exception messages to
plain-language explanations and is coupled to the library's exact throw strings;
it lives in one small shared project so copies can't drift. Referenced by
`ConsoleDemo` and `PqJwtPlayground`. `WebApiDemo`/`VerifierDemo` don't use it —
their 401/403 responses deliberately don't tell a client why auth failed.

## Requirements

- .NET 10 SDK
- Native ML-KEM / ML-DSA support: **OpenSSL 3.5+** on Linux, or a recent
  Windows. Every sample fails closed with a clear error where these are absent.

## Run any sample

```bash
cd samples/ConsoleDemo     && dotnet run
cd samples/WebApiDemo      && dotnet run
cd samples/VerifierDemo    && dotnet run    # needs the issuer running on :5080
cd samples/PqJwtPlayground && dotnet run
cd samples/SpecByExample   && dotnet test
```

## Adding to the solution

```bash
dotnet sln PostQuantum.Jwt.slnx add \
  samples/Shared/Pq.Samples.Shared.csproj \
  samples/ConsoleDemo/ConsoleDemo.csproj \
  samples/WebApiDemo/WebApiDemo.csproj \
  samples/VerifierDemo/VerifierDemo.csproj \
  samples/PqJwtPlayground/PqJwtPlayground.csproj \
  samples/SpecByExample/SpecByExample.csproj
```

## Security guides

- **[SECURE-USAGE.md](SECURE-USAGE.md)** — the decisions *around* the token:
  minimal claims, in-memory access tokens (not localStorage), the refresh-token
  pattern, issuer/audience pinning, replay, key persistence.
- **[HARDENING-CHECKLIST.md](HARDENING-CHECKLIST.md)** — each classic JWT attack
  mapped to how this library blocks it (most are impossible by design).

## Library-level enhancements (separate from samples)

Two of these touch the LIBRARY, not the samples, so they live in `library-patches/`
at the bundle root rather than under `samples/`:

- **Validation metrics** — a reviewed patch to `src/PostQuantum.Jwt/PqJwtValidator.cs`
  adding OpenTelemetry-compatible counters (`pqjwt.validations`, tagged
  `outcome`/`reason`). Apply it, build, run the existing tests. See
  `library-patches/README-METRICS-PATCH.md`.
- **Roslyn analyzer** (`PostQuantum.Jwt.Analyzers`) — compile-time diagnostics
  (PQJWT001/PQJWT002) enforcing correct usage. A working starting point that
  needs a test project before shipping. See `library-patches/PostQuantum.Jwt.Analyzers/README.md`.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 2. `samples/LLM-USAGE.md`

~~~markdown
# Using PostQuantum.Jwt correctly (rules for AI coding assistants)

If you are an AI assistant helping someone build **on** PostQuantum.Jwt, follow
these rules. They exist because the library is deliberately unlike a standard
JWT library, and generic JWT knowledge will lead you to generate wrong, unsafe
code here.

(This is the *consumer* guide. The repo's `CLAUDE.md` is about *contributing to*
the library itself — different audience.)

## Hard rules

1. **Validation is fail-closed. `PqJwtValidator.Validate(token)` returns a
   `PqJwtValidationResult` ONLY on success and THROWS `PqJwtValidationException`
   on any failure.** There is no `IsValid` property and no `result.Exception`.
   Do not generate a "soft validation" wrapper that returns a bool or a result
   with an error field. Wrap the call in `try { … } catch (PqJwtValidationException)`.

2. **There is exactly one algorithm suite: ML-DSA-65 for signatures, X-Wing
   (X25519 + ML-KEM-768) + A256GCM for encryption.** Never introduce algorithm
   agility, `alg` negotiation, RSA/HMAC/ECDSA paths, or — under any
   circumstances — an `alg: none` path. The validator does not trust the token's
   own `alg` to choose a code path; do not write code that does.

3. **The identifiers are NOT IANA-registered.** These tokens will not validate
   in `System.IdentityModel.Tokens.Jwt`, `jose-jwt`, `python-jose`, Auth0/Okta,
   or any generic JWT tooling. Do not suggest interop with those stacks. This
   library is only correct when the same party controls both issuer and verifier.

4. **`exp` is required.** A token without an expiry is rejected. Always set a
   lifetime (`WithLifetime(...)` or `WithExpiration(...)`).

5. **Never log, print, or send private key material to a client.** Only the
   public key (`ExportMLDsaPublicKey()` / the X-Wing public key) is shareable.
   Persist private keys via encrypted PKCS#8, an HSM, or a key vault — never a
   plaintext file (see `samples/WebApiDemo/FileBackedSigningKey.cs`).

6. **Replay protection is opt-in and needs a shared cache in a cluster.**
   `InMemoryReplayCache` is single-process. For more than one instance, implement
   `IPqJwtReplayCache` over Redis/SQL. If you set `RequireReplayProtection = true`,
   you must also supply a `ReplayCache` or the validator constructor throws.

## Correct minimal usage

```csharp
using System.Security.Cryptography;
using PostQuantum.Jwt;

using var signingKey = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
using var verificationKey = MLDsa.ImportMLDsaPublicKey(
    MLDsaAlgorithm.MLDsa65, signingKey.ExportMLDsaPublicKey());

string token = new PqJwtBuilder()
    .WithSubject("user-123")
    .WithLifetime(TimeSpan.FromMinutes(15))
    .SignWith(signingKey)
    .Build();

try
{
    var result = new PqJwtValidator(new PqJwtValidationParameters
    {
        SignatureVerificationKey = verificationKey,
    }).Validate(token);
    // result.Subject, result.GetString("role"), result.WasEncrypted, ...
}
catch (PqJwtValidationException ex)
{
    // The ONLY failure path. ex.Message says what failed.
}
```

## Anti-patterns to never generate

```csharp
// WRONG: there is no IsValid. This will not compile and teaches the wrong model.
var result = validator.Validate(token);
if (result.IsValid) { ... }              // ❌

// WRONG: never an unsigned/none path.
var header = "{\"alg\":\"none\"}";        // ❌

// WRONG: don't claim interop with standard JWT stacks.
// "You can validate this in jose-jwt / Auth0 / etc."  ❌

// WRONG: never expose private key material.
Console.WriteLine(Convert.ToBase64String(signingKey.ExportPkcs8PrivateKey())); // ❌
```

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 3. `samples/.cursorrules`

```text
# Cursor rules for projects consuming PostQuantum.Jwt
# (See LLM-USAGE.md for the full rationale.)

- PostQuantum.Jwt is fail-closed: PqJwtValidator.Validate(token) returns a result
  ONLY on success and THROWS PqJwtValidationException on failure. There is no
  IsValid property. Always use try/catch (PqJwtValidationException); never
  generate a soft bool/result-with-error wrapper.
- One suite only: ML-DSA-65 signatures, X-Wing + A256GCM encryption. Never add
  algorithm agility, alg negotiation, RSA/HMAC/ECDSA, or an alg:none path.
- Identifiers are NOT IANA-registered. Never suggest interop with
  System.IdentityModel.Tokens.Jwt, jose-jwt, python-jose, Auth0/Okta, etc.
  Use this only when one party controls both issuer and verifier.
- exp is required; always set a lifetime.
- Never log/print/return private key material. Public key only. Persist private
  keys as encrypted PKCS#8 / HSM / key vault, never a plaintext file.
- Replay protection is opt-in; InMemoryReplayCache is single-process. Use a
  shared IPqJwtReplayCache for multiple instances.
```

---

## 4. `samples/docker-compose.yml`

```yaml
# Two-service local demo: issuer + independent verifier, on an isolated network.
#
# Shows the full cross-service flow WITHOUT any shared secret:
#   1. issuer  (WebApiDemo)   mints tokens and publishes its public keys at
#                             /.well-known/pqjwt-keys
#   2. verifier (VerifierDemo) fetches those keys over the internal network via
#                             HttpPqJwtKeyRing and validates tokens by `kid`
#
# Both images need OpenSSL 3.5+, so both Dockerfiles use Azure Linux 3.0.
# Build context is the REPOSITORY ROOT for both (they reference ../../src), so
# run this from the repo root:
#
#   docker compose -f samples/docker-compose.yml up --build
#
# Then, against the published ports on your host:
#   # mint an admin token from the issuer
#   TOKEN=$(curl -s -X POST "http://localhost:5080/token?sub=alice&role=admin" | jq -r .token)
#   # verify it on the SEPARATE verifier service (which never saw the signing key)
#   curl -s http://localhost:5090/verify -H "Authorization: Bearer $TOKEN" | jq
#
# To God be the glory - 1 Corinthians 10:31.

services:
  issuer:
    build:
      context: ..
      dockerfile: samples/WebApiDemo/Dockerfile
    environment:
      ASPNETCORE_HTTP_PORTS: "8080"
      # Persist the issuer key inside the container volume so a restart keeps the
      # same kid (and previously issued tokens keep validating).
      PQJWT_KEY_PATH: "/keys/issuer-signing.pkcs8"
      PQJWT_KEY_PASSPHRASE: "compose-demo-passphrase"
    volumes:
      - issuer-keys:/keys
    ports:
      - "5080:8080"
    networks: [pqjwt]

  verifier:
    build:
      context: ..
      dockerfile: samples/VerifierDemo/Dockerfile
    environment:
      ASPNETCORE_HTTP_PORTS: "8080"
      # Internal service name resolves on the compose network - no host ports needed.
      ISSUER_KEYS_URL: "http://issuer:8080/.well-known/pqjwt-keys"
    ports:
      - "5090:8080"
    depends_on: [issuer]
    networks: [pqjwt]

volumes:
  issuer-keys:

networks:
  pqjwt:
    driver: bridge
```

---

## 5. `samples/Shared/Pq.Samples.Shared.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <!--
    Tiny shared library for the PostQuantum.Jwt samples.

    Its ONE job is to hold code that is coupled to the library's behavior and
    must not silently drift between samples - specifically RejectionExplainer,
    whose plain-language mapping keys off the validator's exact exception
    messages. A single source of truth here means a validator-message change is
    fixed in one place, not three.

    Everything else in the samples stays self-contained and copy-paste-readable;
    this project deliberately holds nothing that a reader needs in order to
    understand an individual sample end to end.
  -->
  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <AssemblyName>Pq.Samples.Shared</AssemblyName>
    <RootNamespace>Pq.Samples.Shared</RootNamespace>
  </PropertyGroup>

  <ItemGroup>
    <ProjectReference Include="..\..\src\PostQuantum.Jwt\PostQuantum.Jwt.csproj" />
  </ItemGroup>

</Project>
```

---

## 6. `samples/Shared/RejectionExplainer.cs`

```csharp
// RejectionExplainer
//
// Turns a PqJwtValidationException into a plain-language explanation of WHY the
// token was rejected. The mapping keys off the real messages the validator
// throws (see PqJwtValidator.cs) — when none match, we fall back to the raw
// message rather than inventing a reason. It lives in the shared samples
// project (Pq.Samples.Shared) because it is coupled to the validator's exact
// exception messages and must not drift between samples.
//
// To God be the glory — 1 Corinthians 10:31.

using PostQuantum.Jwt;

namespace Pq.Samples.Shared;

public static class RejectionExplainer
{
    /// <summary>
    /// A short headline ("what happened") and a one-line "why it matters",
    /// derived from the exception the fail-closed validator threw.
    /// </summary>
    public static (string What, string Why) Explain(PqJwtValidationException ex)
    {
        string m = ex.Message;

        // Order matters: check the most specific signals first.
        if (Has(m, "signature verification failed"))
            return ("Signature did not verify",
                "The token was altered after signing, or signed by a different key. ML-DSA-65 over the header+payload no longer matches.");

        if (Has(m, "not valid base64url"))
            return ("Signature segment is corrupt",
                "The signature bytes aren't valid base64url — the token was truncated or mangled in transit.");

        if (Has(m, "expired at"))
            return ("Token expired",
                "The 'exp' instant is in the past (beyond the allowed clock skew). Expiry is enforced by default; there is no opt-out.");

        if (Has(m, "not valid before"))
            return ("Token not yet valid",
                "The 'nbf' instant is in the future. The token is being presented before its activation time.");

        if (Has(m, "missing the required 'exp'"))
            return ("No expiry claim",
                "Every token must carry 'exp'. A token with no expiry is rejected rather than treated as eternal.");

        if (Has(m, "replay detected"))
            return ("Replay detected",
                "This 'jti' was already seen by the replay cache. The same token cannot be used twice when replay protection is on.");

        if (Has(m, "no 'jti'"))
            return ("Replay protection without a jti",
                "Replay protection is enabled but the token carries no 'jti' to track. It is refused rather than silently allowed.");

        if (Has(m, "issuer"))
            return ("Issuer mismatch",
                "The 'iss' claim does not equal the configured ValidIssuer. The token was minted for a different issuer.");

        if (Has(m, "audience"))
            return ("Audience mismatch",
                "The 'aud' claim does not include the configured ValidAudience. The token was minted for a different recipient.");

        if (Has(m, "Unsupported or disallowed signature algorithm") || Has(m, "Unsupported key-agreement") || Has(m, "Unsupported content-encryption"))
            return ("Algorithm not accepted",
                "The validator accepts exactly one suite (ML-DSA-65 / X-Wing / A256GCM). It never trusts the token's own 'alg' to pick a path — that's how 'alg: none' and downgrade attacks are foreclosed.");

        if (Has(m, "No verification key was resolved for kid"))
            return ("Unknown key id",
                "The 'kid' resolved to no key in the ring. An unknown signing key fails closed instead of being trusted.");

        if (Has(m, "decryption failed") || Has(m, "authentication tag mismatch"))
            return ("Decryption / tag check failed",
                "The AES-256-GCM tag didn't authenticate, or the wrong X-Wing private key was used. Ciphertext integrity is enforced.");

        if (Has(m, "key-agreement material is malformed"))
            return ("Malformed key-agreement material",
                "The X-Wing encapsulation in the token is structurally invalid.");

        if (Has(m, "Decrypted content is not a signed JWT"))
            return ("Inner token isn't a signed JWT",
                "After decryption, the contents weren't a valid signed token — the sign-then-encrypt invariant was violated.");

        if (Has(m, "payload is not valid JSON") || Has(m, "payload is not a JSON object"))
            return ("Payload isn't a JSON object",
                "The decoded payload didn't parse as a JSON object. The token is structurally invalid.");

        if (Has(m, "Malformed token: expected") || Has(m, "malformed structure"))
            return ("Wrong segment count",
                "A signed token has 3 segments and an encrypted one has 5. This token had neither — it isn't a PostQuantum.Jwt token.");

        // Fall back to the real message rather than fabricate a reason.
        return ("Rejected", m);
    }

    private static bool Has(string haystack, string needle) =>
        haystack.Contains(needle, StringComparison.OrdinalIgnoreCase);
}
```

---

## 7. `samples/ConsoleDemo/ConsoleDemo.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net10.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <!-- Samples relax the repo's warnings-as-errors so demo code stays readable. -->
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <AssemblyName>PostQuantum.Jwt.ConsoleDemo</AssemblyName>
    <RootNamespace>PostQuantum.Jwt.ConsoleDemo</RootNamespace>
  </PropertyGroup>

  <ItemGroup>
    <!-- Develop against the local library. Switch to a PackageReference to ship standalone. -->
    <ProjectReference Include="..\..\src\PostQuantum.Jwt\PostQuantum.Jwt.csproj" />
    <ProjectReference Include="..\Shared\Pq.Samples.Shared.csproj" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="Spectre.Console" Version="0.50.0" />
  </ItemGroup>

</Project>
```

---

## 8. `samples/ConsoleDemo/Program.cs`

```csharp
// PostQuantum.Jwt.ConsoleDemo
// Educational console application demonstrating the PostQuantum.Jwt library.
//
// Shows: ML-DSA-65 signing, optional X-Wing (X25519 + ML-KEM-768) hybrid
// encryption, replay protection, kid resolution, token size/timing, and the
// library's fail-closed validation behavior (invalid tokens THROW; there is
// no "best-effort" result).
//
// This is a DEMO. Keys live only in memory; do not copy these key-handling
// patterns into production without real key management.
//
// To God be the glory — 1 Corinthians 10:31.

using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using PostQuantum.Jwt;
using PostQuantum.Jwt.Cryptography;
using Spectre.Console;
using Pq.Samples.Shared;

namespace PostQuantum.Jwt.ConsoleDemo;

internal static class Program
{
    // Session state. Held in memory only.
    private static MLDsa? _signingKey;          // private signing key (ML-DSA-65)
    private static MLDsa? _verificationKey;      // public verification key
    private static string _signingKid = "demo-signing-key-2026";
    private static XWingPrivateKey? _recipientKey;   // for the encrypt demo

    public static async Task Main()
    {
        AnsiConsole.Clear();
        ShowHeader();

        using var cts = new CancellationTokenSource();
        Console.CancelKeyPress += (_, e) => { e.Cancel = true; cts.Cancel(); };

        try
        {
            await RunMainLoopAsync(cts.Token);
        }
        catch (OperationCanceledException)
        {
            AnsiConsole.MarkupLine("\n[yellow]Cancelled.[/]");
        }
        catch (Exception ex)
        {
            AnsiConsole.WriteException(ex, ExceptionFormats.ShortenEverything);
        }
        finally
        {
            DisposeKeys();
            AnsiConsole.MarkupLine("\n[dim]To God be the glory — 1 Corinthians 10:31.[/]");
        }
    }

    private static void ShowHeader()
    {
        AnsiConsole.Write(new Rule("[bold blue]Post-Quantum JWT — Console Demo[/]").RuleStyle("blue"));
        AnsiConsole.MarkupLine("[dim]ML-DSA-65 signatures + optional X-Wing (X25519 + ML-KEM-768) encryption · .NET 10[/]");
        AnsiConsole.MarkupLine("[dim]PostQuantum.Jwt 1.0.0-preview.1 · preview software, not for production[/]\n");
    }

    private static async Task RunMainLoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            var choice = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("[bold]Choose an action:[/]")
                    .PageSize(14)
                    .AddChoices(
                        "1. Generate ML-DSA keypair",
                        "2. Create signed token (ML-DSA-65 only)",
                        "3. Create sign-then-encrypt token (X-Wing)",
                        "4. Validate a token",
                        "5. Replay protection demo",
                        "6. Key rotation (kid resolver) demo",
                        "7. Attack mode (wrong key / expired / tampered / replay)",
                        "8. View current session keys",
                        "9. Security notes & limitations",
                        "0. Exit"));

            if (choice.StartsWith('0')) break;

            AnsiConsole.Clear();
            ShowHeader();

            try
            {
                switch (choice[0])
                {
                    case '1': GenerateKeypair(); break;
                    case '2': CreateSignedToken(); break;
                    case '3': CreateEncryptedToken(); break;
                    case '4': await ValidateTokenInteractiveAsync(); break;
                    case '5': ReplayProtectionDemo(); break;
                    case '6': KeyRotationDemo(); break;
                    case '7': AttackMode(); break;
                    case '8': ShowCurrentKeys(); break;
                    case '9': ShowSecurityNotes(); break;
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                AnsiConsole.MarkupLine($"[red]Error:[/] {Markup.Escape(ex.Message)}");
            }

            AnsiConsole.WriteLine();
            AnsiConsole.MarkupLine("[dim]Press any key to return to the menu...[/]");
            Console.ReadKey(true);
            AnsiConsole.Clear();
            ShowHeader();
        }
    }

    // ── 1. Key generation ────────────────────────────────────────────────
    private static void GenerateKeypair()
    {
        AnsiConsole.MarkupLine("[bold green]Generating ML-DSA-65 keypair...[/]");
        var sw = Stopwatch.StartNew();

        DisposeKeys();
        _signingKey = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
        _verificationKey = MLDsa.ImportMLDsaPublicKey(
            MLDsaAlgorithm.MLDsa65, _signingKey.ExportMLDsaPublicKey());

        sw.Stop();
        AnsiConsole.MarkupLine($"[green]✓[/] Generated in [yellow]{sw.ElapsedMilliseconds} ms[/]\n");

        var pub = _verificationKey.ExportMLDsaPublicKey();
        var table = new Table().Border(TableBorder.Rounded)
            .AddColumn("Key").AddColumn("Algorithm").AddColumn("Public key (bytes)");
        table.AddRow("Signing (private, kept in memory)", "ML-DSA-65", "[dim]not exported[/]");
        table.AddRow("Verification (public, shareable)", "ML-DSA-65", pub.Length.ToString());
        AnsiConsole.Write(table);

        AnsiConsole.MarkupLine("\n[dim]Private key material is never printed. Only the public key is exportable here.[/]");
    }

    // ── 2. Signed token ──────────────────────────────────────────────────
    private static void CreateSignedToken()
    {
        if (!RequireKeys()) return;

        var subject = AnsiConsole.Ask("Subject:", "demo-user-42");
        var minutes = AnsiConsole.Ask("Lifetime (minutes):", 15);

        var sw = Stopwatch.StartNew();
        string token = new PqJwtBuilder()
            .WithIssuer("https://demo.systemslibrarian.dev")
            .WithSubject(subject)
            .WithAudience("https://api.demo.local")
            .WithLifetime(TimeSpan.FromMinutes(minutes))
            .WithKeyId(_signingKid)
            .WithJwtId(Guid.NewGuid().ToString("N"))
            .WithClaim("role", "reader")
            .SignWith(_signingKey!)
            .Build();
        sw.Stop();

        DisplayToken("Signed (ML-DSA-65)", token, sw.Elapsed, encrypted: false);
    }

    // ── 3. Sign + encrypt token ──────────────────────────────────────────
    private static void CreateEncryptedToken()
    {
        if (!RequireKeys()) return;

        _recipientKey ??= XWingPrivateKey.Generate();
        var recipientPublic = _recipientKey.PublicKey;   // XWingPublicKey

        var subject = AnsiConsole.Ask("Confidential subject:", "confidential-789");
        var minutes = AnsiConsole.Ask("Lifetime (minutes):", 5);

        var sw = Stopwatch.StartNew();
        string token = new PqJwtBuilder()
            .WithSubject(subject)
            .WithLifetime(TimeSpan.FromMinutes(minutes))
            .WithKeyId(_signingKid)
            .WithJwtId(Guid.NewGuid().ToString("N"))
            .SignWith(_signingKey!)
            .EncryptFor(recipientPublic)
            .Build();
        sw.Stop();

        DisplayToken("Sign-then-encrypt (ML-DSA-65 + X-Wing → A256GCM)", token, sw.Elapsed, encrypted: true);
        AnsiConsole.MarkupLine("\n[dim]The session recipient key is held in memory; validate with option 4 while this session lives.[/]");
    }

    private static void DisplayToken(string title, string token, TimeSpan elapsed, bool encrypted)
    {
        AnsiConsole.Write(new Rule($"[bold]{title}[/]").RuleStyle("green"));
        AnsiConsole.Write(new Panel(Markup.Escape(token))
            .Header("Compact token (copy this)").Border(BoxBorder.Rounded).Padding(1, 0));

        var info = new Table().Border(TableBorder.None).AddColumn("Property").AddColumn("Value");
        info.AddRow("Encoded length", $"{token.Length} chars (~{token.Length * 3 / 4} bytes)");
        info.AddRow("Segments", encrypted ? "5 (JWE-style)" : "3 (JWS-style)");
        info.AddRow("Creation time", $"{elapsed.TotalMilliseconds:F1} ms");
        info.AddRow("Encrypted", encrypted ? "[green]Yes (X-Wing + A256GCM)[/]" : "[yellow]No (signed only)[/]");
        AnsiConsole.Write(info);
    }

    // ── 4. Validate ──────────────────────────────────────────────────────
    private static Task ValidateTokenInteractiveAsync()
    {
        if (_verificationKey is null)
        {
            AnsiConsole.MarkupLine("[red]No verification key. Generate a keypair first (option 1).[/]");
            return Task.CompletedTask;
        }

        var token = AnsiConsole.Ask<string>("Paste token to validate:");

        var validator = new PqJwtValidator(new PqJwtValidationParameters
        {
            SignatureVerificationKey = _verificationKey,
            DecryptionKey = _recipientKey,   // null is fine for signed-only tokens
            RequireReplayProtection = false,
        });

        var sw = Stopwatch.StartNew();
        try
        {
            // Fail-closed: this returns ONLY on success, otherwise it throws.
            var result = validator.Validate(token);
            sw.Stop();

            var t = new Table().Border(TableBorder.Rounded).Title("[bold green]✓ Valid[/]")
                .AddColumn("Claim").AddColumn("Value");
            t.AddRow("sub", result.Subject ?? "[dim]none[/]");
            t.AddRow("iss", result.Issuer ?? "[dim]none[/]");
            t.AddRow("aud", result.GetString("aud") ?? "[dim]none[/]");
            t.AddRow("jti", result.JwtId ?? "[dim]none[/]");
            t.AddRow("exp", result.ExpiresAt?.ToString("u") ?? "[dim]none[/]");
            t.AddRow("Encrypted", result.WasEncrypted ? "[green]Yes[/]" : "[yellow]No[/]");
            t.AddRow("Validation time", $"{sw.ElapsedMilliseconds} ms");
            AnsiConsole.Write(t);

            if (result.Claims.Count > 0)
            {
                AnsiConsole.MarkupLine("\n[bold]All claims:[/]");
                AnsiConsole.WriteLine(JsonSerializer.Serialize(
                    result.Claims.ToDictionary(kv => kv.Key, kv => kv.Value),
                    new JsonSerializerOptions { WriteIndented = true }));
            }
        }
        catch (PqJwtValidationException ex)
        {
            sw.Stop();
            var (what, why) = RejectionExplainer.Explain(ex);
            AnsiConsole.MarkupLine($"[red]✗ Rejected[/] after {sw.ElapsedMilliseconds} ms — [white]{Markup.Escape(what)}[/]");
            AnsiConsole.MarkupLine($"[dim]{Markup.Escape(why)}[/]");
            AnsiConsole.MarkupLine($"[dim]validator: {Markup.Escape(ex.Message)}[/]");
        }
        return Task.CompletedTask;
    }

    // ── 5. Replay protection ─────────────────────────────────────────────
    private static void ReplayProtectionDemo()
    {
        if (!RequireKeys()) return;

        var cache = new InMemoryReplayCache();
        string token = new PqJwtBuilder()
            .WithSubject("replay-test")
            .WithLifetime(TimeSpan.FromMinutes(5))
            .WithJwtId(Guid.NewGuid().ToString("N"))
            .SignWith(_signingKey!)
            .Build();

        var validator = new PqJwtValidator(new PqJwtValidationParameters
        {
            SignatureVerificationKey = _verificationKey,
            ReplayCache = cache,
            RequireReplayProtection = true,
        });

        try
        {
            validator.Validate(token);
            AnsiConsole.MarkupLine("[green]✓ First use accepted (jti registered).[/]");
        }
        catch (PqJwtValidationException ex)
        {
            AnsiConsole.MarkupLine($"[red]Unexpected first-use failure:[/] {Markup.Escape(ex.Message)}");
            return;
        }

        try
        {
            validator.Validate(token);
            AnsiConsole.MarkupLine("[red]✗ Second use accepted — replay was NOT detected![/]");
        }
        catch (PqJwtValidationException)
        {
            AnsiConsole.MarkupLine("[green]✓ Second use correctly rejected as a replay.[/]");
        }
    }

    // ── 6. Key rotation / kid resolver ───────────────────────────────────
    private static void KeyRotationDemo()
    {
        AnsiConsole.MarkupLine("[bold]Two signing keys, resolved by [yellow]kid[/] at validation time.[/]\n");

        using var keyA = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
        using var keyB = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
        using var pubA = MLDsa.ImportMLDsaPublicKey(MLDsaAlgorithm.MLDsa65, keyA.ExportMLDsaPublicKey());
        using var pubB = MLDsa.ImportMLDsaPublicKey(MLDsaAlgorithm.MLDsa65, keyB.ExportMLDsaPublicKey());

        var ring = new Dictionary<string, MLDsa> { ["key-A"] = pubA, ["key-B"] = pubB };

        string tokenB = new PqJwtBuilder()
            .WithSubject("rotated-user")
            .WithLifetime(TimeSpan.FromMinutes(5))
            .WithKeyId("key-B")
            .SignWith(keyB)
            .Build();

        var validator = new PqJwtValidator(new PqJwtValidationParameters
        {
            SignatureKeyResolver = kid => kid is not null && ring.TryGetValue(kid, out var k) ? k : null,
        });

        try
        {
            var r = validator.Validate(tokenB);
            AnsiConsole.MarkupLine($"[green]✓ Token signed with key-B validated via resolver.[/] sub = {r.Subject}");
        }
        catch (PqJwtValidationException ex)
        {
            AnsiConsole.MarkupLine($"[red]✗ {Markup.Escape(ex.Message)}[/]");
        }

        AnsiConsole.MarkupLine("\n[dim]An unknown kid resolves to null → fail-closed rejection. Rotate by adding the new kid to the ring before issuing with it.[/]");
    }

    // ── 7. Attack mode ───────────────────────────────────────────────────
    // A guided walk through realistic forgery attempts. Each one is the kind of
    // thing an attacker who has captured a valid token would actually try; each
    // must fail closed, and we explain *why* in plain language so the mechanism
    // — not just the outcome — is visible.
    private static void AttackMode()
    {
        if (!RequireKeys()) return;
        AnsiConsole.Write(new Rule("[bold red]Attack mode[/]").RuleStyle("red"));
        AnsiConsole.MarkupLine("[dim]An attacker holds a captured, valid token. Watch each forgery attempt fail closed.[/]\n");

        var honestValidator = new PqJwtValidator(new PqJwtValidationParameters
        {
            SignatureVerificationKey = _verificationKey,
        });

        // The legitimate token the attacker starts from: a low-privilege user.
        string captured = new PqJwtBuilder()
            .WithIssuer("https://demo.systemslibrarian.dev")
            .WithSubject("alice")
            .WithLifetime(TimeSpan.FromMinutes(15))
            .WithClaim("role", "reader")
            .SignWith(_signingKey!)
            .Build();

        // Sanity: the captured token is genuinely valid before we attack it.
        try
        {
            var ok = honestValidator.Validate(captured);
            AnsiConsole.MarkupLine($"[dim]Baseline: captured token is valid. sub={ok.Subject}, role={ok.GetString("role")}.[/]\n");
        }
        catch (PqJwtValidationException)
        {
            AnsiConsole.MarkupLine("[red]Baseline token failed to validate — environment problem, aborting attack demo.[/]");
            return;
        }

        // (1) Privilege escalation by editing a CLAIM and keeping the old signature.
        // This is the realistic tamper: decode payload, change "reader" -> "admin",
        // re-encode, leave the original signature untouched.
        RunAttack("Privilege escalation (edit role, reuse signature)",
            "Decode payload -> change role 'reader' to 'admin' -> re-encode -> keep the captured signature. The classic 'just edit the JSON' forgery.",
            () => honestValidator.Validate(EscalateRole(captured)));

        // (2) Algorithm-confusion / "alg: none" substitution.
        // Swap the header for {"alg":"none"} and drop the signature — the classic
        // JWT downgrade. The validator never trusts the token's alg to pick a path.
        RunAttack("Algorithm confusion ('alg: none')",
            "Replace the header with {\"alg\":\"none\"} and strip the signature, hoping the verifier honors it.",
            () => honestValidator.Validate(ForgeAlgNone(captured)));

        // (3) Wrong signing key (attacker mints their own token with their own key).
        using var attackerKey = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
        string forged = new PqJwtBuilder()
            .WithSubject("alice").WithClaim("role", "admin")
            .WithLifetime(TimeSpan.FromMinutes(15)).SignWith(attackerKey).Build();
        RunAttack("Forged with attacker's own key",
            "Mint a fresh 'admin' token signed with a key the attacker controls.",
            () => honestValidator.Validate(forged));

        // (4) Expired token.
        string expired = new PqJwtBuilder()
            .WithSubject("alice")
            .WithExpiration(DateTimeOffset.UtcNow.AddMinutes(-10))
            .WithNotBefore(DateTimeOffset.UtcNow.AddMinutes(-20))
            .SignWith(_signingKey!).Build();
        RunAttack("Replay an expired token",
            "Present a properly-signed token whose lifetime has already passed.",
            () => honestValidator.Validate(expired));

        // (5) Missing required 'exp'.
        string noExp = new PqJwtBuilder()
            .WithSubject("alice").WithClaim("role", "reader")
            .SignWith(_signingKey!).Build();
        RunAttack("Token with no expiry",
            "Issue a signed token that omits 'exp', hoping it is treated as eternal.",
            () => honestValidator.Validate(noExp));

        // (6) Replay of a valid, unexpired token.
        var replayValidator = new PqJwtValidator(new PqJwtValidationParameters
        {
            SignatureVerificationKey = _verificationKey,
            ReplayCache = new InMemoryReplayCache(),
            RequireReplayProtection = true,
        });
        string jtiTok = new PqJwtBuilder()
            .WithSubject("alice").WithLifetime(TimeSpan.FromMinutes(5))
            .WithJwtId(Guid.NewGuid().ToString("N")).SignWith(_signingKey!).Build();
        try { replayValidator.Validate(jtiTok); } catch { /* first use legitimately passes */ }
        RunAttack("Reuse a one-time token (replay)",
            "Submit the same valid token a second time after it was already accepted once.",
            () => replayValidator.Validate(jtiTok));

        AnsiConsole.MarkupLine("\n[dim]Every attempt above must say REJECTED. An ACCEPTED line would be a bug worth reporting.[/]");
    }

    private static void RunAttack(string title, string approach, Func<PqJwtValidationResult> attempt)
    {
        AnsiConsole.MarkupLine($"[bold]» {Markup.Escape(title)}[/]");
        AnsiConsole.MarkupLine($"  [dim]{Markup.Escape(approach)}[/]");
        try
        {
            attempt();
            AnsiConsole.MarkupLine("  [red]✗ ACCEPTED — this should not happen.[/]\n");
        }
        catch (PqJwtValidationException ex)
        {
            var (what, why) = RejectionExplainer.Explain(ex);
            AnsiConsole.MarkupLine($"  [green]✓ REJECTED[/] — [white]{Markup.Escape(what)}[/]");
            AnsiConsole.MarkupLine($"  [dim]{Markup.Escape(why)}[/]\n");
        }
    }

    // Realistic claim-level tamper: change role to "admin" but keep the signature.
    // Returns a structurally-valid 3-part token whose payload no longer matches
    // the signature — so the failure is "signature verification failed", the
    // exact lesson we want (not "malformed base64").
    private static string EscalateRole(string token)
    {
        var parts = token.Split('.');
        if (parts.Length != 3) return token;
        string payloadJson = DecodeSegment(parts[1]);
        using var doc = System.Text.Json.JsonDocument.Parse(payloadJson);
        var dict = new Dictionary<string, System.Text.Json.JsonElement>();
        foreach (var p in doc.RootElement.EnumerateObject()) dict[p.Name] = p.Value.Clone();
        // Overwrite the role claim with a privileged value.
        using var adminDoc = System.Text.Json.JsonDocument.Parse("\"admin\"");
        dict["role"] = adminDoc.RootElement.Clone();
        string mutated = System.Text.Json.JsonSerializer.Serialize(dict);
        parts[1] = EncodeSegment(mutated);   // signature (parts[2]) is left intact
        return string.Join('.', parts);
    }

    // Classic "alg: none" downgrade: header says no signature, third segment empty.
    private static string ForgeAlgNone(string token)
    {
        var parts = token.Split('.');
        if (parts.Length < 2) return token;
        parts[0] = EncodeSegment("{\"alg\":\"none\",\"typ\":\"JWT\"}");
        // Keep payload, drop the signature entirely.
        return parts[0] + "." + parts[1] + ".";
    }

    private static string DecodeSegment(string seg)
    {
        string s = seg.Replace('-', '+').Replace('_', '/');
        switch (s.Length % 4) { case 2: s += "=="; break; case 3: s += "="; break; }
        return System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(s));
    }

    private static string EncodeSegment(string text)
    {
        var b = System.Text.Encoding.UTF8.GetBytes(text);
        return Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    }

    // ── 8. Show keys ─────────────────────────────────────────────────────
    private static void ShowCurrentKeys()
    {
        if (_verificationKey is null)
        {
            AnsiConsole.MarkupLine("[yellow]No keys generated yet.[/]");
            return;
        }
        var pub = Convert.ToBase64String(_verificationKey.ExportMLDsaPublicKey());
        var t = new Table().Border(TableBorder.Rounded).AddColumn("Key").AddColumn("Algorithm").AddColumn("Public (base64, truncated)");
        t.AddRow("ML-DSA verification", "ML-DSA-65", pub[..32] + "…");
        if (_recipientKey is not null)
        {
            var xpub = Convert.ToBase64String(_recipientKey.PublicKey.Export());
            t.AddRow("X-Wing recipient", "X-Wing", xpub[..32] + "…");
        }
        AnsiConsole.Write(t);
        AnsiConsole.MarkupLine($"\n[dim]Active signing kid: [yellow]{_signingKid}[/][/]");
    }

    // ── 9. Security notes ────────────────────────────────────────────────
    private static void ShowSecurityNotes()
    {
        AnsiConsole.Write(new Rule("[bold red]Security notes & limitations (preview)[/]").RuleStyle("red"));
        AnsiConsole.Write(new Panel(
            "• [bold]Preview software, not audited.[/] API and wire format may change before 1.0.\n" +
            "• Native .NET 10 BCL primitives: ML-DSA-65 (FIPS 204), ML-KEM-768 (FIPS 203). X25519 + SHA3-256 via BouncyCastle.\n" +
            "• [bold]Non-IANA identifiers[/] (ML-DSA-65 / X-Wing / A256GCM) → tokens will NOT validate in generic JWT tooling.\n" +
            "• Fail-closed: any validation failure throws PqJwtValidationException. No alg:none, no unsigned path.\n" +
            "• Replay protection requires a shared cache across all validating nodes.\n" +
            "• X-Wing encryption is one recipient per token.\n" +
            "• Signed token ≈ 4.5 KB; encrypted ≈ 6.5 KB — fine for Authorization headers, likely too big for cookies.")
            .Border(BoxBorder.Rounded).Padding(1));
        AnsiConsole.MarkupLine("\n[dim]Full detail: KNOWN-GAPS.md and SECURITY.md in the repository.[/]");
    }

    // ── helpers ──────────────────────────────────────────────────────────
    private static bool RequireKeys()
    {
        if (_signingKey is not null && _verificationKey is not null) return true;
        AnsiConsole.MarkupLine("[red]No keys in session. Generate a keypair first (option 1).[/]");
        return false;
    }

    private static void DisposeKeys()
    {
        _signingKey?.Dispose();
        _verificationKey?.Dispose();
        _recipientKey?.Dispose();
        _signingKey = _verificationKey = null;
        _recipientKey = null;
    }
}
```

---

## 9. `samples/ConsoleDemo/README.md`

~~~markdown
# PostQuantum.Jwt — Console Demo

An interactive, menu-driven console app that exercises every core feature of
**PostQuantum.Jwt** and shows the library's fail-closed behavior in action.

## What it demonstrates

- ML-DSA-65 signatures (FIPS 204)
- Optional hybrid encryption with X-Wing (X25519 + ML-KEM-768) → AES-256-GCM
- Replay protection with `InMemoryReplayCache`
- Key rotation via a `kid` resolver
- Real token sizes and timings
- **Attack mode** — a guided walk through six realistic forgery attempts, each
  rejected, each with a plain-language explanation of *why*:
  1. Privilege escalation (edit the `role` claim, reuse the signature)
  2. Algorithm confusion (`alg: none` substitution)
  3. Forgery with an attacker's own key
  4. Expired token
  5. Token with no `exp`
  6. Replay of a one-time token

The privilege-escalation case is a *real* tamper: it decodes the payload,
rewrites `role` to `admin`, re-encodes, and leaves the original signature in
place — so the failure is genuinely "signature verification failed," not a
base64 parse error. That is the lesson: the signature, not the transport, is
what stops the forgery.

## Quick start

```bash
cd samples/ConsoleDemo
dotnet run
```

Start with option **1** (generate a keypair), then try **2**, **3**, **4**, and **7**.

## Requirements

- .NET 10 SDK
- Native ML-KEM / ML-DSA support: **OpenSSL 3.5+** on Linux, or a recent
  Windows. Without it the PQ paths fail closed with a clear error.

## Notes

- All keys live only in memory for the session; nothing is persisted.
- Private key material is never printed — only the public key is exportable.
- This is **preview software** and the construction is **not audited**.
- Tokens use non-IANA identifiers and will not validate in generic JWT tooling.

## Next steps

- `samples/WebApiDemo` — real ASP.NET Core integration with `AddPqJwtBearer`
- `samples/PqJwtPlayground` — interactive Blazor Server UI

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 10. `samples/WebApiDemo/WebApiDemo.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <AssemblyName>PostQuantum.Jwt.WebApiDemo</AssemblyName>
    <RootNamespace>PostQuantum.Jwt.WebApiDemo</RootNamespace>
    <UserSecretsId>postquantum-jwt-webapidemo</UserSecretsId>
  </PropertyGroup>

  <ItemGroup>
    <ProjectReference Include="..\..\src\PostQuantum.Jwt\PostQuantum.Jwt.csproj" />
    <ProjectReference Include="..\..\src\PostQuantum.Jwt.AspNetCore\PostQuantum.Jwt.AspNetCore.csproj" />
  </ItemGroup>

</Project>
```

---

## 11. `samples/WebApiDemo/Program.cs`

```csharp
// PostQuantum.Jwt.WebApiDemo
// Minimal ASP.NET Core API demonstrating real integration of PostQuantum.Jwt
// via the PostQuantum.Jwt.AspNetCore companion (AddPqJwtBearer).
//
// Endpoints:
//   POST /token            : issue a signed ML-DSA-65 token (demo "login")
//   GET  /me               : protected; requires a valid PQ JWT
//   GET  /admin            : protected; requires the "admins" policy (role claim)
//   GET  /.well-known/pqjwt-keys : key directory (JWKS-equivalent)
//
// KEY LIFECYCLE (read this):
//   This demo generates a BRAND-NEW signing key every time the process starts.
//   That means: every restart invalidates every token issued before it. This is
//   deliberate for a zero-config demo, and it is exactly what a real service must
//   NOT do. A production issuer loads a persisted, securely-stored key (HSM, key
//   vault, sealed file) so tokens survive restarts and key rotation is explicit.
//   We log a loud warning at startup so this is impossible to miss.
//
// To God be the glory - 1 Corinthians 10:31.

using System.Diagnostics;
using System.Security.Cryptography;
using PostQuantum.Jwt;
using PostQuantum.Jwt.AspNetCore;

const string Issuer = "https://demo.systemslibrarian.dev";
const string Audience = "https://api.demo.local";

var builder = WebApplication.CreateBuilder(args);

// -- Issuer signing key --------------------------------------------------------
// Two modes, chosen by the PQJWT_KEY_PATH environment variable:
//
//   (default, unset)  EPHEMERAL: a new key per process. Demonstrates the wrong
//                     thing on purpose, with a loud warning below. Restarting
//                     invalidates every token issued before it.
//
//   PQJWT_KEY_PATH=…  PERSISTENT: load (or first-time create) an encrypted
//                     PKCS#8 key file via FileBackedSigningKey, so issued tokens
//                     survive restarts. This is the production-SHAPED answer —
//                     see FileBackedSigningKey.cs for the real export/import
//                     lifecycle and why a file still isn't a vault.
//
// Either way the key is created ONCE and captured in closures, so the demo's
// trust relationship (this key signs; its public half verifies) lives in one place.
var keyPath = Environment.GetEnvironmentVariable("PQJWT_KEY_PATH");
FileBackedSigningKey? persisted = keyPath is null
    ? null
    : FileBackedSigningKey.LoadOrCreate(
        keyPath,
        Environment.GetEnvironmentVariable("PQJWT_KEY_PASSPHRASE")
            ?? "demo-passphrase-change-me");   // a real service pulls this from a secret store

string Kid = persisted?.KeyId ?? "demo-2026-01";
var signingKey = persisted?.SigningKey ?? MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
var publicKeyBytes = persisted?.PublicKeyBytes ?? signingKey.ExportMLDsaPublicKey();
var verificationKey = persisted?.VerificationKey
    ?? MLDsa.ImportMLDsaPublicKey(MLDsaAlgorithm.MLDsa65, publicKeyBytes);

builder.Services
    .AddAuthentication(PqJwtBearerDefaults.AuthenticationScheme)
    .AddPqJwtBearer(options =>
    {
        options.ValidationParameters = new PqJwtValidationParameters
        {
            // Resolve by kid (enables rotation). The closure captures the public
            // key created above; an unknown kid resolves to null -> fail closed.
            SignatureKeyResolver = kid => kid == Kid ? verificationKey : null,
            ValidIssuer = Issuer,
            ValidAudience = Audience,
            // Single-process replay defense. Swap for a Redis/SQL-backed
            // IPqJwtReplayCache when running more than one instance.
            ReplayCache = new InMemoryReplayCache(),
        };
    });

builder.Services.AddAuthorization(options =>
    options.AddPolicy("admins", p => p.RequireClaim("role", "admin")));

var app = builder.Build();

// -- Startup key-lifecycle log: honest about which mode is active. -----------
var startupLog = app.Services.GetRequiredService<ILoggerFactory>().CreateLogger("Startup");
if (persisted is null)
{
    startupLog.LogWarning(
        "DEMO key lifecycle: EPHEMERAL. A NEW ML-DSA-65 signing key (kid={Kid}) was generated " +
        "at startup; all tokens issued by this process become invalid after a restart. Set " +
        "PQJWT_KEY_PATH to load/persist an encrypted key instead (see FileBackedSigningKey.cs).", Kid);
}
else
{
    startupLog.LogInformation(
        "Key lifecycle: PERSISTENT. ML-DSA-65 signing key (kid={Kid}) {Origin} encrypted PKCS#8 at the " +
        "configured path; tokens survive restarts. (A file still isn't a vault — see FileBackedSigningKey.cs.)",
        Kid, persisted.LoadedFromDisk ? "loaded from" : "generated and saved to");
}

// -- Lightweight request correlation so the logs feel like a real service. --
app.Use(async (ctx, next) =>
{
    var correlationId = ctx.Request.Headers.TryGetValue("X-Correlation-ID", out var incoming) && !string.IsNullOrEmpty(incoming)
        ? incoming.ToString()
        : Activity.Current?.Id ?? ctx.TraceIdentifier;
    ctx.Response.Headers["X-Correlation-ID"] = correlationId;

    using (app.Logger.BeginScope(new Dictionary<string, object> { ["CorrelationId"] = correlationId }))
    {
        var sw = Stopwatch.StartNew();
        await next();
        sw.Stop();
        app.Logger.LogInformation("{Method} {Path} -> {Status} in {Elapsed} ms",
            ctx.Request.Method, ctx.Request.Path, ctx.Response.StatusCode, sw.ElapsedMilliseconds);
    }
});

app.UseAuthentication();
app.UseAuthorization();

// -- Helpful-but-secure 401/403. We never reveal WHY auth failed (that would
// leak validator internals to an attacker); we return RFC 7807 problem details
// with a correlation id the operator can match against the logs. --------------
app.UseStatusCodePages(async ctx =>
{
    var r = ctx.HttpContext.Response;
    if (r.StatusCode is 401 or 403)
    {
        r.ContentType = "application/problem+json";
        var corr = r.Headers["X-Correlation-ID"].ToString();
        var detail = r.StatusCode == 401
            ? "No valid post-quantum bearer token was presented."
            : "The token is valid but lacks the required claim for this resource.";
        await r.WriteAsJsonAsync(new
        {
            type = "about:blank",
            title = r.StatusCode == 401 ? "Unauthorized" : "Forbidden",
            status = r.StatusCode,
            detail,
            correlationId = corr,
        });
    }
});

// -- Demo "login": issue a signed token -------------------------------------
// POST /token?sub=alice&role=admin
app.MapPost("/token", (string? sub, string? role, ILogger<Program> log) =>
{
    var b = new PqJwtBuilder()
        .WithIssuer(Issuer)
        .WithAudience(Audience)
        .WithSubject(sub ?? "demo-user")
        .WithLifetime(TimeSpan.FromMinutes(15))
        .WithKeyId(Kid)
        .WithJwtId(Guid.NewGuid().ToString("N"))
        .SignWith(signingKey);

    if (!string.IsNullOrEmpty(role))
        b = b.WithClaim("role", role);

    log.LogInformation("Issued token for sub={Sub} role={Role}", sub ?? "demo-user", role ?? "(none)");
    return Results.Ok(new { token = b.Build(), kid = Kid, token_type = "PqJwtBearer", expires_in = 900 });
});

// -- Protected: requires a valid PQ JWT -------------------------------------
app.MapGet("/me", (HttpContext ctx) => Results.Ok(new
{
    sub = ctx.User.FindFirst("sub")?.Value,
    role = ctx.User.FindFirst("role")?.Value,
    authenticated = ctx.User.Identity?.IsAuthenticated ?? false,
})).RequireAuthorization();

// -- Protected + role policy -------------------------------------------------
app.MapGet("/admin", () => Results.Ok(new { message = "Welcome, admin." }))
   .RequireAuthorization("admins");

// -- Key directory (JWKS-equivalent) ----------------------------------------
// Shape: { keys: [ { kid, alg, key(base64) } ] } - exactly what HttpPqJwtKeyRing
// fetches. A separate verifier service points its key ring at this URL and
// resolves verification keys by kid, with periodic refresh. That is how real
// multi-service rotation works: rotate the issuer's key + kid, publish both old
// and new here during the overlap window, and verifiers pick up the new one on
// their next refresh without redeploying.
app.MapGet("/.well-known/pqjwt-keys", () => Results.Ok(new
{
    keys = new[]
    {
        new { kid = Kid, alg = PqJwtAlgorithms.MLDsa65, key = Convert.ToBase64String(publicKeyBytes) }
    }
}));

app.MapGet("/", () => Results.Text(
    "PostQuantum.Jwt WebApiDemo. POST /token then GET /me with the bearer token. " +
    "Public keys at /.well-known/pqjwt-keys."));

app.Run();
```

---

## 12. `samples/WebApiDemo/FileBackedSigningKey.cs`

```csharp
// FileBackedSigningKey
//
// The WebApiDemo's main Program.cs generates a NEW signing key on every startup
// and warns loudly that a real service must NOT do that. THIS file is the other
// half of that lesson: the smallest honest example of *persisting* an ML-DSA-65
// signing key across restarts, so issued tokens survive a redeploy.
//
// It demonstrates the real .NET 10 BCL key lifecycle:
//   • export the private key as PKCS#8  (MLDsa.ExportPkcs8PrivateKey)
//   • write it to disk once, with locked-down file permissions
//   • load it back on startup          (MLDsa.ImportPkcs8PrivateKey)
//   • derive + publish the public half  (ExportSubjectPublicKeyInfo)
//
// WHY PKCS#8 and not the raw seed/secret-key exports? PKCS#8 is the portable,
// standards-based container the rest of the .NET ecosystem understands, it
// round-trips cleanly, and it has an *encrypted* variant
// (ExportEncryptedPkcs8PrivateKey) you should prefer in production. The compact
// alternative is the 32-byte private seed (ExportMLDsaPrivateSeed /
// ImportMLDsaPrivateSeed) — smallest to store, but rawer.
//
// WHAT THIS IS STILL NOT: production key management. A real deployment stores
// the key in an HSM, Azure Key Vault, or at minimum an OS keystore — never a
// plaintext PKCS#8 file on the app's own disk. This class uses an encrypted
// PKCS#8 file with a passphrase as a deliberate middle ground: it shows the
// export/import mechanics honestly without pretending a file is a vault.
//
// To God be the glory - 1 Corinthians 10:31.

using System.Security.Cryptography;

namespace PostQuantum.Jwt.WebApiDemo;

/// <summary>
/// A signing key that is generated once, persisted to an encrypted PKCS#8 file,
/// and reloaded on every subsequent startup — so tokens issued before a restart
/// keep validating after it. Holds both the private signing key and the derived
/// public verification key for the life of the process.
/// </summary>
public sealed class FileBackedSigningKey : IDisposable
{
    private const string Kid = "demo-persistent-2026-01";

    /// <summary>The ML-DSA-65 private key used to sign tokens.</summary>
    public MLDsa SigningKey { get; }

    /// <summary>The matching public key, for verification and for the key directory.</summary>
    public MLDsa VerificationKey { get; }

    /// <summary>Raw public-key bytes, base64-encoded into the JWKS-equivalent directory.</summary>
    public byte[] PublicKeyBytes { get; }

    /// <summary>The key id this signer stamps into a token's <c>kid</c> header.</summary>
    public string KeyId => Kid;

    /// <summary>Whether the key was loaded from disk (true) or freshly generated (false).</summary>
    public bool LoadedFromDisk { get; }

    private FileBackedSigningKey(MLDsa signingKey, bool loadedFromDisk)
    {
        SigningKey = signingKey;
        LoadedFromDisk = loadedFromDisk;

        // The public half is always derived from the private key — never stored
        // separately, so the two cannot drift.
        PublicKeyBytes = signingKey.ExportMLDsaPublicKey();
        VerificationKey = MLDsa.ImportMLDsaPublicKey(MLDsaAlgorithm.MLDsa65, PublicKeyBytes);
    }

    /// <summary>
    /// Loads the signing key from <paramref name="path"/> if it exists, otherwise
    /// generates a new one and persists it (encrypted) for next time.
    /// </summary>
    /// <param name="path">File path for the encrypted PKCS#8 key material.</param>
    /// <param name="passphrase">Passphrase protecting the PKCS#8 file. In a real
    /// service this comes from a secret store, NOT source or config.</param>
    public static FileBackedSigningKey LoadOrCreate(string path, string passphrase)
    {
        ArgumentException.ThrowIfNullOrEmpty(path);
        ArgumentException.ThrowIfNullOrEmpty(passphrase);

        // These ML-DSA export/import APIs are still marked experimental in .NET 10.
#pragma warning disable SYSLIB5006
        if (File.Exists(path))
        {
            byte[] encrypted = File.ReadAllBytes(path);
            // Reconstruct the exact same key from the encrypted PKCS#8 blob.
            var loaded = MLDsa.ImportEncryptedPkcs8PrivateKey(passphrase, encrypted);
            return new FileBackedSigningKey(loaded, loadedFromDisk: true);
        }

        // First run: generate, then persist encrypted so the NEXT start reuses it.
        var key = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);

        // PBES2 with sensible-for-a-demo iteration count. Tune for your threat model.
        var pbe = new PbeParameters(
            PbeEncryptionAlgorithm.Aes256Cbc, HashAlgorithmName.SHA256, iterationCount: 200_000);
        byte[] encryptedPkcs8 = key.ExportEncryptedPkcs8PrivateKey(passphrase, pbe);

        WriteLockedDown(path, encryptedPkcs8);
#pragma warning restore SYSLIB5006

        return new FileBackedSigningKey(key, loadedFromDisk: false);
    }

    // Write the key file with owner-only permissions where the OS supports it.
    private static void WriteLockedDown(string path, byte[] bytes)
    {
        var dir = Path.GetDirectoryName(Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

        File.WriteAllBytes(path, bytes);

        if (!OperatingSystem.IsWindows())
        {
            // chmod 600 — owner read/write only. On Windows, rely on ACL inheritance
            // from a suitably-protected directory (or DPAPI in a real implementation).
            File.SetUnixFileMode(path,
                UnixFileMode.UserRead | UnixFileMode.UserWrite);
        }
    }

    public void Dispose()
    {
        SigningKey.Dispose();
        VerificationKey.Dispose();
    }
}
```

---

## 13. `samples/WebApiDemo/appsettings.json`

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

---

## 14. `samples/WebApiDemo/Properties/launchSettings.json`

```json
{
  "profiles": {
    "http": {
      "commandName": "Project",
      "launchBrowser": false,
      "applicationUrl": "http://localhost:5080",
      "environmentVariables": { "ASPNETCORE_ENVIRONMENT": "Development" }
    }
  }
}
```

---

## 15. `samples/WebApiDemo/WebApiDemo.http`

```http
@host = http://localhost:5080

### Issue an admin token
# @name login
POST {{host}}/token?sub=alice&role=admin

### Call the protected endpoint with the token from /token
GET {{host}}/me
Authorization: Bearer {{login.response.body.token}}

### Admin-only endpoint
GET {{host}}/admin
Authorization: Bearer {{login.response.body.token}}

### Key directory (JWKS-equivalent)
GET {{host}}/.well-known/pqjwt-keys
```

---

## 16. `samples/WebApiDemo/Dockerfile`

```dockerfile
# PostQuantum.Jwt WebApiDemo
#
# IMPORTANT: the native ML-KEM / ML-DSA primitives require OpenSSL 3.5+.
# The default Debian-based aspnet images ship an older OpenSSL, where the PQ
# paths fail closed. We use the Azure Linux (Mariner) 10 images, which provide
# a new-enough OpenSSL. Confirm with `openssl version` inside the container if
# you swap the base image.
#
# Build context is the REPO ROOT (we reference ../../src). Build with:
#   docker build -f samples/WebApiDemo/Dockerfile -t pqjwt-webapidemo .
#   docker run --rm -p 5080:8080 pqjwt-webapidemo

# ---- build ----
FROM mcr.microsoft.com/dotnet/sdk:10.0-azurelinux3.0 AS build
WORKDIR /src

# Copy only what the demo needs to build (core lib + aspnetcore + this sample).
COPY src/PostQuantum.Jwt/ src/PostQuantum.Jwt/
COPY src/PostQuantum.Jwt.AspNetCore/ src/PostQuantum.Jwt.AspNetCore/
COPY Directory.Build.props ./
COPY samples/WebApiDemo/ samples/WebApiDemo/

RUN dotnet restore samples/WebApiDemo/WebApiDemo.csproj
RUN dotnet publish samples/WebApiDemo/WebApiDemo.csproj -c Release -o /app --no-restore

# ---- runtime ----
FROM mcr.microsoft.com/dotnet/aspnet:10.0-azurelinux3.0 AS runtime
WORKDIR /app
COPY --from=build /app .
ENV ASPNETCORE_HTTP_PORTS=8080
EXPOSE 8080
ENTRYPOINT ["dotnet", "PostQuantum.Jwt.WebApiDemo.dll"]
```

---

## 17. `samples/WebApiDemo/README.md`

~~~markdown
# PostQuantum.Jwt — Web API Demo

A minimal ASP.NET Core API showing real integration via the
**PostQuantum.Jwt.AspNetCore** companion package (`AddPqJwtBearer`).

## Endpoints

| Method | Route                          | Purpose                                  |
| ------ | ------------------------------ | ---------------------------------------- |
| POST   | `/token?sub=&role=`            | Issue a signed ML-DSA-65 token ("login") |
| GET    | `/me`                          | Protected — requires a valid PQ JWT      |
| GET    | `/admin`                       | Protected — requires `role=admin`        |
| GET    | `/.well-known/pqjwt-keys`      | Key directory (JWKS-equivalent)          |

## Key lifecycle — read this first

**This demo generates a brand-new signing key every time the process starts.**
Every restart invalidates every token issued before it. That is deliberate for
a zero-config demo, and it is exactly what a real service must *not* do. The app
logs a loud `Warning` at startup so this is impossible to miss.

A production issuer instead loads a **persisted, securely-stored** key (HSM, key
vault, sealed file) so tokens survive restarts and rotation is explicit. The
issuer's signing key and its public verification half are created once at
startup and captured in closures, so the trust relationship (this key signs;
this key verifies) lives in one readable place in `Program.cs`.

## Quick start

```bash
cd samples/WebApiDemo
dotnet run
```

Then, in another terminal:

```bash
# 1) Get a token
TOKEN=$(curl -s -X POST "http://localhost:5080/token?sub=alice&role=admin" | jq -r .token)

# 2) Call the protected endpoint
curl -s http://localhost:5080/me -H "Authorization: Bearer $TOKEN" | jq

# 3) Admin-only
curl -s http://localhost:5080/admin -H "Authorization: Bearer $TOKEN" | jq

# 4) Public key directory
curl -s http://localhost:5080/.well-known/pqjwt-keys | jq

# 5) See the secure 401 (no token) — note the correlationId
curl -s http://localhost:5080/me | jq
```

(`WebApiDemo.http` has the same calls for VS / VS Code REST Client.)

## Logging & error responses

- Every request gets an `X-Correlation-ID` (honored from the inbound header or
  generated), logged in a scope alongside method, path, status, and latency —
  so the demo reads like a real service.
- `401`/`403` return RFC 7807 `application/problem+json` with that correlation
  id. They deliberately do **not** explain *why* auth failed (that would leak
  validator internals to an attacker); the operator matches the id to the logs.

## Multi-service key rotation

For separate issuer and verifier services, point `HttpPqJwtKeyRing` at the
issuer's `/.well-known/pqjwt-keys` URL and feed its `Resolve` into
`SignatureKeyResolver`:

```csharp
builder.Services.AddHttpClient();
builder.Services.AddSingleton<IPqJwtKeyRing>(sp =>
    new HttpPqJwtKeyRing(
        sp.GetRequiredService<IHttpClientFactory>().CreateClient(),
        new Uri("https://issuer.example/.well-known/pqjwt-keys"),
        refreshInterval: TimeSpan.FromMinutes(5)));

// in AddPqJwtBearer(...):
options.ValidationParameters = new PqJwtValidationParameters
{
    SignatureKeyResolver = kid =>
        sp.GetRequiredService<IPqJwtKeyRing>().Resolve(kid),
    ValidIssuer = "...", ValidAudience = "...",
};
```

The directory shape this demo serves —
`{ "keys": [ { "kid", "alg", "key" } ] }` — is exactly what that key ring reads,
and entries whose `alg` isn't `ML-DSA-65` are ignored (single-suite policy).
**Rotation flow:** mint with a new `kid`, publish *both* old and new keys here
during the overlap window, and verifiers pick up the new key on their next
refresh — no redeploy, and in-flight old-kid tokens keep validating until they
expire.

## Docker

> **OpenSSL 3.5+ is required for the PQ primitives.** Ubuntu 24.04 (the new
> default .NET 10 base image) ships OpenSSL 3.0 and will **fail closed** on the
> ML-KEM / ML-DSA paths. This Dockerfile uses the **Azure Linux 3.0** images,
> which carry a new-enough OpenSSL. Verify with `openssl version` if you change
> the base.

Build from the **repository root** (the Dockerfile references `../../src`):

```bash
docker build -f samples/WebApiDemo/Dockerfile -t pqjwt-webapidemo .
docker run --rm -p 5080:8080 pqjwt-webapidemo
```

## Notes

- **DEMO ONLY.** See the key-lifecycle section above.
- Don't also call `AddJwtBearer` — the standard handler can't parse `ML-DSA-65`.
- Preview software, not audited; non-IANA identifiers, non-interoperable tokens.

## Persisting the signing key (surviving restarts)

By default this demo generates a new key per process — fine for a demo, wrong
for production. Set `PQJWT_KEY_PATH` to switch on persistence:

```bash
PQJWT_KEY_PATH=./keys/issuer.pkcs8 \
PQJWT_KEY_PASSPHRASE=change-me \
dotnet run
```

Now the key is generated once, written as **encrypted PKCS#8**, and reloaded on
every subsequent start — so tokens issued before a restart keep validating.
[`FileBackedSigningKey.cs`](FileBackedSigningKey.cs) shows the real lifecycle
(`ExportEncryptedPkcs8PrivateKey` / `ImportEncryptedPkcs8PrivateKey`, owner-only
file mode) and is honest that a file still isn't an HSM or key vault.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 18. `samples/VerifierDemo/VerifierDemo.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <AssemblyName>PostQuantum.Jwt.VerifierDemo</AssemblyName>
    <RootNamespace>PostQuantum.Jwt.VerifierDemo</RootNamespace>
  </PropertyGroup>

  <ItemGroup>
    <ProjectReference Include="..\..\src\PostQuantum.Jwt\PostQuantum.Jwt.csproj" />
    <ProjectReference Include="..\..\src\PostQuantum.Jwt.AspNetCore\PostQuantum.Jwt.AspNetCore.csproj" />
  </ItemGroup>

</Project>
```

---

## 19. `samples/VerifierDemo/Program.cs`

```csharp
// PostQuantum.Jwt.VerifierDemo
//
// A SECOND service that verifies tokens minted by WebApiDemo (the issuer) WITHOUT
// sharing any signing key with it. It resolves verification keys at runtime by
// fetching the issuer's JWKS-equivalent directory (/.well-known/pqjwt-keys) over
// HTTP via HttpPqJwtKeyRing, keyed by the token's `kid`.
//
// This is the real multi-service rotation story made runnable: the issuer can
// rotate its signing key + kid and publish both old and new in its directory
// during the overlap window; this verifier picks up the new key on its next
// refresh - no redeploy, no shared secret, no manual key copying.
//
// Run it alongside the issuer with docker compose (see samples/docker-compose.yml),
// which sets ISSUER_KEYS_URL to the issuer's in-network address.
//
// To God be the glory - 1 Corinthians 10:31.

using PostQuantum.Jwt;
using PostQuantum.Jwt.AspNetCore;

const string Issuer = "https://demo.systemslibrarian.dev";
const string Audience = "https://api.demo.local";

var builder = WebApplication.CreateBuilder(args);

// Where to fetch the issuer's public keys. In compose this is the issuer
// service's internal URL; locally it defaults to the issuer's dev port.
var keysUrl = builder.Configuration["ISSUER_KEYS_URL"]
    ?? "http://localhost:5080/.well-known/pqjwt-keys";

// Build the HTTP-backed key ring ONCE and capture it in the auth closure below.
// HttpPqJwtKeyRing caches fetched public keys and refreshes on its interval; an
// unknown kid forces a single refresh before resolving to null (fail closed).
// No signing key ever lives in this process - it only holds public verification
// keys it fetched from the issuer.
var http = new HttpClient();
var keyRing = new HttpPqJwtKeyRing(
    http,
    new Uri(keysUrl),
    refreshInterval: TimeSpan.FromSeconds(30));   // short, so rotation is visible in a demo

builder.Services
    .AddAuthentication(PqJwtBearerDefaults.AuthenticationScheme)
    .AddPqJwtBearer(options =>
    {
        options.ValidationParameters = new PqJwtValidationParameters
        {
            // Every token's kid is resolved through the HTTP key ring.
            SignatureKeyResolver = kid => keyRing.Resolve(kid),
            ValidIssuer = Issuer,
            ValidAudience = Audience,
            ReplayCache = new InMemoryReplayCache(),
        };
    });

builder.Services.AddAuthorization();

var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/", () => Results.Text(
    $"PostQuantum.Jwt VerifierDemo. Verifies tokens via issuer keys at: {keysUrl}\n" +
    "Call GET /verify with an Authorization: Bearer <token> minted by the issuer."));

// Succeeds only if the token validates against a key fetched from the issuer.
app.MapGet("/verify", (HttpContext ctx) => Results.Ok(new
{
    verified = true,
    sub = ctx.User.FindFirst("sub")?.Value,
    role = ctx.User.FindFirst("role")?.Value,
    note = "Validated using a public key fetched from the issuer's /.well-known/pqjwt-keys.",
})).RequireAuthorization();

app.Run();
```

---

## 20. `samples/VerifierDemo/appsettings.json`

```json
{
  "Logging": { "LogLevel": { "Default": "Information", "Microsoft.AspNetCore": "Warning" } },
  "AllowedHosts": "*"
}
```

---

## 21. `samples/VerifierDemo/Properties/launchSettings.json`

```json
{
  "profiles": {
    "http": {
      "commandName": "Project",
      "launchBrowser": false,
      "applicationUrl": "http://localhost:5090",
      "environmentVariables": {
        "ASPNETCORE_ENVIRONMENT": "Development",
        "ISSUER_KEYS_URL": "http://localhost:5080/.well-known/pqjwt-keys"
      }
    }
  }
}
```

---

## 22. `samples/VerifierDemo/Dockerfile`

```dockerfile
# PostQuantum.Jwt VerifierDemo
# OpenSSL 3.5+ required (Azure Linux 3.0 base). Build context = repo root.
#   docker build -f samples/VerifierDemo/Dockerfile -t pqjwt-verifier .

FROM mcr.microsoft.com/dotnet/sdk:10.0-azurelinux3.0 AS build
WORKDIR /src
COPY src/PostQuantum.Jwt/ src/PostQuantum.Jwt/
COPY src/PostQuantum.Jwt.AspNetCore/ src/PostQuantum.Jwt.AspNetCore/
COPY Directory.Build.props ./
COPY samples/VerifierDemo/ samples/VerifierDemo/
RUN dotnet restore samples/VerifierDemo/VerifierDemo.csproj
RUN dotnet publish samples/VerifierDemo/VerifierDemo.csproj -c Release -o /app --no-restore

FROM mcr.microsoft.com/dotnet/aspnet:10.0-azurelinux3.0 AS runtime
WORKDIR /app
COPY --from=build /app .
ENV ASPNETCORE_HTTP_PORTS=8080
EXPOSE 8080
ENTRYPOINT ["dotnet", "PostQuantum.Jwt.VerifierDemo.dll"]
```

---

## 23. `samples/VerifierDemo/README.md`

~~~markdown
# PostQuantum.Jwt — Verifier Demo (cross-service rotation)

A **second** service that validates tokens minted by `WebApiDemo` **without
sharing a signing key**. It fetches the issuer's public keys from
`/.well-known/pqjwt-keys` over HTTP via `HttpPqJwtKeyRing` and resolves each
token's `kid` against them.

This is the real multi-service story: the issuer can rotate its key + `kid` and
publish both old and new during an overlap window; this verifier picks up the
new key on its next refresh — no redeploy, no shared secret.

## Run it with the issuer (recommended)

Use the two-service compose file from the repo root:

```bash
docker compose -f samples/docker-compose.yml up --build

# mint a token from the issuer
TOKEN=$(curl -s -X POST "http://localhost:5080/token?sub=alice&role=admin" | jq -r .token)
# verify it on the SEPARATE verifier (which never saw the signing key)
curl -s http://localhost:5090/verify -H "Authorization: Bearer $TOKEN" | jq
```

## Run it locally (issuer must be running on :5080)

```bash
cd samples/VerifierDemo
dotnet run    # reads ISSUER_KEYS_URL, defaults to http://localhost:5080/.well-known/pqjwt-keys
```

## Notes

- No signing key lives in this process — only public verification keys it fetched.
- The key ring refreshes every 30s here so rotation is visible quickly in a demo;
  use a longer interval in production.
- Preview software, not audited; non-IANA identifiers; non-interoperable tokens.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 24. `samples/SpecByExample/SpecByExample.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <!--
    Executable specification: learn PostQuantum.Jwt by reading and stepping
    through tests. The test NAMES are the lessons; set a breakpoint in any [Fact]
    and watch (for example) a claim edit fail signature verification in your IDE.
    This is documentation that happens to be runnable - NOT the library's own
    test suite (that lives in tests/).
  -->
  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <IsPackable>false</IsPackable>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.12.0" />
    <PackageReference Include="xunit" Version="2.9.2" />
    <PackageReference Include="xunit.runner.visualstudio" Version="2.8.2" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="..\..\src\PostQuantum.Jwt\PostQuantum.Jwt.csproj" />
  </ItemGroup>

</Project>
```

---

## 25. `samples/SpecByExample/SpecByExample.cs`

```csharp
// PostQuantum.Jwt — Spec by Example
//
// An executable specification. Each test name is a lesson about how the library
// behaves; the body is the smallest code that proves it. Set a breakpoint in any
// test and step through it to watch the mechanics — especially the Attack-Mode
// cases, where you can see a tampered token fail signature verification line by
// line, in your own IDE, without a console menu.
//
// These tests skip themselves on hosts without native ML-KEM/ML-DSA support
// (OpenSSL 3.5+ or recent Windows) rather than failing spuriously.
//
// To God be the glory — 1 Corinthians 10:31.

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using PostQuantum.Jwt;
using PostQuantum.Jwt.Cryptography;
using Xunit;

namespace PostQuantum.Jwt.SpecByExample;

/// <summary>Skips a fact when the runtime lacks native ML-DSA/ML-KEM support.</summary>
public sealed class RequiresPqAttribute : FactAttribute
{
    public RequiresPqAttribute()
    {
        if (!MLDsa.IsSupported)
            Skip = "Native ML-DSA/ML-KEM not available (needs OpenSSL 3.5+ or recent Windows).";
    }
}

public sealed class HappyPath : IDisposable
{
    private readonly MLDsa _signing = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
    private readonly MLDsa _verify;

    public HappyPath() =>
        _verify = MLDsa.ImportMLDsaPublicKey(MLDsaAlgorithm.MLDsa65, _signing.ExportMLDsaPublicKey());

    [RequiresPq]
    public void A_signed_token_round_trips_and_exposes_its_claims()
    {
        string token = new PqJwtBuilder()
            .WithIssuer("https://issuer.example")
            .WithSubject("user-123")
            .WithAudience("https://api.example")
            .WithLifetime(TimeSpan.FromMinutes(10))
            .WithClaim("role", "reader")
            .SignWith(_signing)
            .Build();

        var result = new PqJwtValidator(new PqJwtValidationParameters
        {
            SignatureVerificationKey = _verify,
            ValidIssuer = "https://issuer.example",
            ValidAudience = "https://api.example",
        }).Validate(token);   // fail-closed: returns ONLY on success

        Assert.Equal("user-123", result.Subject);
        Assert.Equal("reader", result.GetString("role"));
        Assert.False(result.WasEncrypted);
    }

    [RequiresPq]
    public void A_sign_then_encrypt_token_is_confidential_and_validates_with_the_recipient_key()
    {
        using var recipient = XWingPrivateKey.Generate();

        string token = new PqJwtBuilder()
            .WithSubject("confidential")
            .WithLifetime(TimeSpan.FromMinutes(5))
            .SignWith(_signing)
            .EncryptFor(recipient.PublicKey)
            .Build();

        // 5 segments = JWE-style encrypted form.
        Assert.Equal(5, token.Split('.').Length);

        var result = new PqJwtValidator(new PqJwtValidationParameters
        {
            SignatureVerificationKey = _verify,
            DecryptionKey = recipient,
        }).Validate(token);

        Assert.True(result.WasEncrypted);
        Assert.Equal("confidential", result.Subject);
    }

    public void Dispose() { _signing.Dispose(); _verify.Dispose(); }
}

public sealed class AttackMode : IDisposable
{
    private readonly MLDsa _signing = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
    private readonly MLDsa _verify;
    private readonly PqJwtValidator _validator;

    public AttackMode()
    {
        _verify = MLDsa.ImportMLDsaPublicKey(MLDsaAlgorithm.MLDsa65, _signing.ExportMLDsaPublicKey());
        _validator = new PqJwtValidator(new PqJwtValidationParameters
        {
            SignatureVerificationKey = _verify,
        });
    }

    private string CapturedReaderToken() => new PqJwtBuilder()
        .WithSubject("alice")
        .WithLifetime(TimeSpan.FromMinutes(15))
        .WithClaim("role", "reader")
        .SignWith(_signing)
        .Build();

    [RequiresPq]
    public void Editing_a_claim_and_reusing_the_signature_breaks_verification()
    {
        // The realistic forgery: decode payload, escalate role to admin,
        // re-encode, keep the captured signature. Breakpoint here and step in.
        string tampered = EscalateRole(CapturedReaderToken());

        var ex = Assert.Throws<PqJwtValidationException>(() => _validator.Validate(tampered));
        Assert.Contains("signature", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [RequiresPq]
    public void An_alg_none_token_is_rejected()
    {
        string forged = ForgeAlgNone(CapturedReaderToken());
        Assert.Throws<PqJwtValidationException>(() => _validator.Validate(forged));
    }

    [RequiresPq]
    public void A_token_signed_by_the_wrong_key_is_rejected()
    {
        using var attacker = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
        string forged = new PqJwtBuilder()
            .WithSubject("alice").WithClaim("role", "admin")
            .WithLifetime(TimeSpan.FromMinutes(15)).SignWith(attacker).Build();

        Assert.Throws<PqJwtValidationException>(() => _validator.Validate(forged));
    }

    [RequiresPq]
    public void An_expired_token_is_rejected()
    {
        string expired = new PqJwtBuilder()
            .WithSubject("alice")
            .WithExpiration(DateTimeOffset.UtcNow.AddMinutes(-10))
            .WithNotBefore(DateTimeOffset.UtcNow.AddMinutes(-20))
            .SignWith(_signing).Build();

        Assert.Throws<PqJwtValidationException>(() => _validator.Validate(expired));
    }

    [RequiresPq]
    public void A_token_with_no_exp_is_rejected()
    {
        string noExp = new PqJwtBuilder()
            .WithSubject("alice").WithClaim("role", "reader")
            .SignWith(_signing).Build();

        Assert.Throws<PqJwtValidationException>(() => _validator.Validate(noExp));
    }

    [RequiresPq]
    public void The_same_one_time_token_cannot_be_used_twice()
    {
        var replayValidator = new PqJwtValidator(new PqJwtValidationParameters
        {
            SignatureVerificationKey = _verify,
            ReplayCache = new InMemoryReplayCache(),
            RequireReplayProtection = true,
        });

        string token = new PqJwtBuilder()
            .WithSubject("alice").WithLifetime(TimeSpan.FromMinutes(5))
            .WithJwtId(Guid.NewGuid().ToString("N")).SignWith(_signing).Build();

        replayValidator.Validate(token);   // first use: accepted
        Assert.Throws<PqJwtValidationException>(() => replayValidator.Validate(token)); // second: replay
    }

    // --- helpers (educational tampering only) ---

    private static string EscalateRole(string token)
    {
        var parts = token.Split('.');
        string payloadJson = Decode(parts[1]);
        using var doc = JsonDocument.Parse(payloadJson);
        var dict = new Dictionary<string, JsonElement>();
        foreach (var p in doc.RootElement.EnumerateObject()) dict[p.Name] = p.Value.Clone();
        using var admin = JsonDocument.Parse("\"admin\"");
        dict["role"] = admin.RootElement.Clone();
        parts[1] = Encode(JsonSerializer.Serialize(dict));   // signature (parts[2]) untouched
        return string.Join('.', parts);
    }

    private static string ForgeAlgNone(string token)
    {
        var parts = token.Split('.');
        parts[0] = Encode("{\"alg\":\"none\",\"typ\":\"JWT\"}");
        return parts[0] + "." + parts[1] + ".";
    }

    private static string Decode(string seg)
    {
        string s = seg.Replace('-', '+').Replace('_', '/');
        switch (s.Length % 4) { case 2: s += "=="; break; case 3: s += "="; break; }
        return Encoding.UTF8.GetString(Convert.FromBase64String(s));
    }

    private static string Encode(string text) =>
        Convert.ToBase64String(Encoding.UTF8.GetBytes(text)).TrimEnd('=').Replace('+', '-').Replace('/', '_');

    public void Dispose() { _signing.Dispose(); _verify.Dispose(); }
}
```

---

## 26. `samples/SpecByExample/README.md`

~~~markdown
# PostQuantum.Jwt — Spec by Example (xUnit)

An **executable specification**. Each test name is a lesson; the body is the
smallest code that proves it. Prefer learning a library by stepping through
tests in your IDE? Start here.

```bash
cd samples/SpecByExample
dotnet test
```

Set a breakpoint in any `[RequiresPq]` test and step through it. The Attack-Mode
tests are the most instructive — watch a tampered token fail signature
verification line by line:

- `Editing_a_claim_and_reusing_the_signature_breaks_verification`
- `An_alg_none_token_is_rejected`
- `A_token_signed_by_the_wrong_key_is_rejected`
- `An_expired_token_is_rejected`
- `A_token_with_no_exp_is_rejected`
- `The_same_one_time_token_cannot_be_used_twice`

Tests **skip themselves** (not fail) on hosts without native ML-DSA/ML-KEM
(needs OpenSSL 3.5+ or recent Windows).

> This is documentation that happens to run. It is **not** the library's own
> test suite — that lives in `tests/` and is far more exhaustive.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 27. `samples/DistributedReplayCache/DistributedReplayCache.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <!--
    Sample implementations of IPqJwtReplayCache backed by a distributed store,
    for multi-node deployments where InMemoryReplayCache (single-process) isn't
    enough. See DistributedReplayCache.cs for the atomicity caveat: prefer the
    Redis SET NX variant; the IDistributedCache variant has a residual race.
  -->
  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
  </PropertyGroup>

  <ItemGroup>
    <ProjectReference Include="..\..\src\PostQuantum.Jwt\PostQuantum.Jwt.csproj" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.Extensions.Caching.Abstractions" Version="10.0.0" />
    <PackageReference Include="StackExchange.Redis" Version="2.8.16" />
  </ItemGroup>

</Project>
```

---

## 28. `samples/DistributedReplayCache/DistributedReplayCache.cs`

```csharp
// DistributedReplayCache
//
// InMemoryReplayCache (in the library) proves the jti-replay concept but is
// single-process: a token "replayed" on a different node is NOT detected. The
// moment you scale horizontally you need a SHARED store. This sample shows two
// implementations of IPqJwtReplayCache backed by a distributed cache.
//
// THE CRITICAL CONSTRAINT: IPqJwtReplayCache.TryRegister must be ATOMIC — it has
// to record-and-test in one indivisible step, or two nodes racing the same
// replayed token can both see "not present" and both accept it. A naive
// get-then-set has exactly that race and is WRONG for replay defense.
//
//   • RedisReplayCache (RECOMMENDED) uses Redis SET key value NX PX <ttl>, which
//     is atomic set-if-absent at the server — the correct primitive. Add the
//     StackExchange.Redis package to use it.
//
//   • DistributedCacheReplayCache uses IDistributedCache for portability across
//     providers, but IDistributedCache has no atomic set-if-absent, so it cannot
//     fully close the race on its own. It is acceptable only when your provider
//     guarantees atomic Set semantics or you accept a tiny race window. We
//     include it because Gemini-style "use IDistributedCache" is a common ask —
//     but we are honest that Redis SETNX is the right answer.
//
// To God be the glory - 1 Corinthians 10:31.

using Microsoft.Extensions.Caching.Distributed;
using PostQuantum.Jwt;
using StackExchange.Redis;

namespace PostQuantum.Jwt.Samples.DistributedReplayCache;

/// <summary>
/// RECOMMENDED distributed replay cache. Uses Redis <c>SET … NX PX</c> for a
/// genuinely atomic "register if absent", which is what replay defense requires
/// across multiple nodes.
/// </summary>
public sealed class RedisReplayCache : IPqJwtReplayCache
{
    private readonly IDatabase _db;
    private readonly string _prefix;
    private readonly TimeProvider _time;

    /// <param name="multiplexer">A shared <see cref="IConnectionMultiplexer"/> (register it as a singleton).</param>
    /// <param name="keyPrefix">Namespace for jti keys, so they don't collide with other Redis data.</param>
    /// <param name="timeProvider">Clock for computing TTL; defaults to system.</param>
    public RedisReplayCache(
        IConnectionMultiplexer multiplexer,
        string keyPrefix = "pqjwt:jti:",
        TimeProvider? timeProvider = null)
    {
        ArgumentNullException.ThrowIfNull(multiplexer);
        _db = multiplexer.GetDatabase();
        _prefix = keyPrefix;
        _time = timeProvider ?? TimeProvider.System;
    }

    /// <inheritdoc />
    public bool TryRegister(string jwtId, DateTimeOffset expiresAt)
    {
        ArgumentException.ThrowIfNullOrEmpty(jwtId);

        // TTL = time until the token expires (plus a small floor). Once the token
        // can no longer validate on its own merits, the jti entry is useless and
        // Redis evicts it automatically — the cache never grows without bound.
        TimeSpan? ttl = expiresAt == DateTimeOffset.MaxValue
            ? null
            : Max(expiresAt - _time.GetUtcNow(), TimeSpan.FromSeconds(1));

        // Atomic set-if-absent at the server. Returns true only if the key did
        // not already exist — i.e. this is the FIRST time we've seen this jti.
        // Two nodes racing the same jti: exactly one gets true.
        return _db.StringSet(
            _prefix + jwtId,
            value: "1",
            expiry: ttl,
            when: When.NotExists);
    }

    private static TimeSpan Max(TimeSpan a, TimeSpan b) => a > b ? a : b;
}

/// <summary>
/// Portable replay cache over <see cref="IDistributedCache"/> (Redis, SQL Server,
/// etc.). NOTE: <see cref="IDistributedCache"/> has no atomic set-if-absent, so
/// this cannot fully eliminate the race where two nodes register the same jti
/// simultaneously. Prefer <see cref="RedisReplayCache"/> for true atomicity; use
/// this only when provider portability outweighs that residual risk, or when
/// your store's Set is atomic.
/// </summary>
public sealed class DistributedCacheReplayCache : IPqJwtReplayCache
{
    private readonly IDistributedCache _cache;
    private readonly string _prefix;
    private readonly TimeProvider _time;
    private static readonly byte[] Marker = "1"u8.ToArray();

    public DistributedCacheReplayCache(
        IDistributedCache cache,
        string keyPrefix = "pqjwt:jti:",
        TimeProvider? timeProvider = null)
    {
        _cache = cache ?? throw new ArgumentNullException(nameof(cache));
        _prefix = keyPrefix;
        _time = timeProvider ?? TimeProvider.System;
    }

    /// <inheritdoc />
    public bool TryRegister(string jwtId, DateTimeOffset expiresAt)
    {
        ArgumentException.ThrowIfNullOrEmpty(jwtId);
        var key = _prefix + jwtId;

        // The interface is synchronous; IDistributedCache is async. We block here
        // deliberately and document it. (RedisReplayCache avoids this by using the
        // synchronous StackExchange.Redis API directly.)
        if (_cache.Get(key) is not null)
        {
            return false;   // already seen -> replay
        }

        var options = new DistributedCacheEntryOptions();
        if (expiresAt != DateTimeOffset.MaxValue)
        {
            var ttl = expiresAt - _time.GetUtcNow();
            options.AbsoluteExpirationRelativeToNow = ttl > TimeSpan.Zero ? ttl : TimeSpan.FromSeconds(1);
        }

        // RACE WINDOW between the Get above and this Set: two nodes can both pass
        // the Get and both Set. See the class summary — use RedisReplayCache to
        // close it. Kept here because the pattern is what people ask for.
        _cache.Set(key, Marker, options);
        return true;
    }
}
```

---

## 29. `samples/DistributedReplayCache/README.md`

~~~markdown
# Distributed replay cache (multi-node `jti` defense)

`InMemoryReplayCache` (in the library) is single-process: a token replayed on a
different node isn't detected. For a clustered deployment you need a **shared**
store. This sample implements `IPqJwtReplayCache` two ways.

## The one rule that matters: atomicity

`IPqJwtReplayCache.TryRegister` must **record-and-test atomically**. A naive
get-then-set lets two nodes racing the same replayed token both see "absent" and
both accept it — defeating the whole point.

| Implementation | Atomic? | Use when |
| -------------- | ------- | -------- |
| `RedisReplayCache` | **Yes** — Redis `SET … NX PX` | Recommended. True set-if-absent at the server. |
| `DistributedCacheReplayCache` | No (residual race) | Portability across `IDistributedCache` providers, if you accept the small window. |

## Wiring it in

```csharp
// Program.cs — register a shared multiplexer once, then the cache.
builder.Services.AddSingleton<IConnectionMultiplexer>(
    _ => ConnectionMultiplexer.Connect("your-redis:6379"));
builder.Services.AddSingleton<IPqJwtReplayCache>(sp =>
    new RedisReplayCache(sp.GetRequiredService<IConnectionMultiplexer>()));

// …then pass it to the validator / AddPqJwtBearer:
options.ValidationParameters = new PqJwtValidationParameters
{
    SignatureVerificationKey = verificationKey,
    ReplayCache = sp.GetRequiredService<IPqJwtReplayCache>(),
    RequireReplayProtection = true,   // constructor throws if the cache is missing
};
```

The TTL is derived from the token's `exp`, so entries evict themselves once the
token can no longer validate anyway — the cache never grows unbounded.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 30. `samples/TestingSupport/TestingSupport.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <!--
    A test-only authentication handler that lets CONSUMERS of PostQuantum.Jwt
    test their own [Authorize] endpoints without running ML-DSA / X-Wing crypto.
    Depends only on ASP.NET Core auth - NOT on the crypto library - so it's a
    clean candidate to lift into a published PostQuantum.Jwt.Testing package.
  -->
  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
  </PropertyGroup>

  <ItemGroup>
    <FrameworkReference Include="Microsoft.AspNetCore.App" />
  </ItemGroup>

</Project>
```

---

## 31. `samples/TestingSupport/TestPqJwtAuthHandler.cs`

```csharp
// TestPqJwtAuthHandler
//
// A drop-in ASP.NET Core authentication handler for CONSUMERS of PostQuantum.Jwt
// to use in their OWN integration tests. It bypasses ML-DSA / X-Wing entirely and
// authenticates every request with a fixed, test-controlled set of claims.
//
// WHY: running real PQ crypto across hundreds of WebApplicationFactory tests is
// slow, and worse, the native primitives need OpenSSL 3.5+, which a CI runner may
// not have. Tests of YOUR [Authorize] endpoints shouldn't depend on that - they
// should exercise your authorization logic, not re-test the crypto (the library's
// own suite does that). This handler lets a test say "treat the caller as an admin"
// and get a 200/403 decision without a single signature operation.
//
// SAFETY: this authenticates EVERYONE as the configured principal. It must NEVER
// be registered outside a test host. Guard it behind your test environment.
//
// Shipped as a SAMPLE showing the pattern. To make it a real
// PostQuantum.Jwt.Testing NuGet package, lift this file into its own project - it
// depends only on ASP.NET Core auth, not on the crypto library.
//
// To God be the glory - 1 Corinthians 10:31.

using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace PostQuantum.Jwt.Testing;

/// <summary>
/// Options for <see cref="TestPqJwtAuthHandler"/>: the claims every request gets.
/// </summary>
public sealed class TestPqJwtOptions : AuthenticationSchemeOptions
{
    /// <summary>Scheme name; mirrors the real PqJwtBearer scheme so [Authorize] works unchanged.</summary>
    public const string DefaultScheme = "PqJwtBearer";

    /// <summary>Claims assigned to the authenticated test principal.</summary>
    public IList<Claim> Claims { get; } = new List<Claim>
    {
        new("sub", "test-user"),
        new("role", "admin"),
    };

    /// <summary>
    /// When set, only requests carrying this header authenticate (others are
    /// anonymous), so you can exercise the 401 path too. Null = authenticate all.
    /// </summary>
    public string? RequireHeader { get; set; }

    /// <summary>
    /// Environment names under which this handler is permitted to run. The handler
    /// THROWS at construction outside these, so it can never silently authenticate
    /// everyone in production even if misregistered. Defaults to common test names.
    /// </summary>
    public ISet<string> AllowedEnvironments { get; } =
        new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "Test", "Testing", "IntegrationTest" };
}

/// <summary>
/// Authenticates requests with fixed claims and no cryptography. TEST HOSTS ONLY.
/// Register via <see cref="TestAuthExtensions.AddTestPqJwtBearer"/>.
/// </summary>
public sealed class TestPqJwtAuthHandler : AuthenticationHandler<TestPqJwtOptions>
{
    public TestPqJwtAuthHandler(
        IOptionsMonitor<TestPqJwtOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        IWebHostEnvironment environment)
        : base(options, logger, encoder)
    {
        // Absolute safeguard: refuse to exist outside an allowed test environment.
        // This is belt-and-suspenders on top of "only register it in
        // ConfigureTestServices" — if it's ever wired into a real host, startup
        // fails loudly instead of authenticating every caller as admin.
        var allowed = options.CurrentValue.AllowedEnvironments;
        if (!allowed.Contains(environment.EnvironmentName))
        {
            throw new InvalidOperationException(
                $"TestPqJwtAuthHandler must not run in environment '{environment.EnvironmentName}'. " +
                $"It authenticates every request with fixed claims and is for test hosts only. " +
                $"Allowed: {string.Join(", ", allowed)}.");
        }
    }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        if (Options.RequireHeader is { } header && !Request.Headers.ContainsKey(header))
        {
            return Task.FromResult(AuthenticateResult.NoResult());
        }

        var identity = new ClaimsIdentity(Options.Claims, Scheme.Name, nameType: "sub", roleType: "role");
        var principal = new ClaimsPrincipal(identity);
        var ticket = new AuthenticationTicket(principal, Scheme.Name);
        return Task.FromResult(AuthenticateResult.Success(ticket));
    }
}

/// <summary>Registration helper for the test handler.</summary>
public static class TestAuthExtensions
{
    /// <summary>
    /// Registers the no-crypto test handler under the PqJwtBearer scheme name so
    /// existing <c>[Authorize]</c> attributes light up in tests unchanged.
    /// </summary>
    public static AuthenticationBuilder AddTestPqJwtBearer(
        this AuthenticationBuilder builder,
        Action<TestPqJwtOptions>? configure = null)
        => builder.AddScheme<TestPqJwtOptions, TestPqJwtAuthHandler>(
            TestPqJwtOptions.DefaultScheme, configure ?? (_ => { }));
}
```

---

## 32. `samples/TestingSupport/README.md`

~~~markdown
# Test support: authenticate without crypto

A test-only ASP.NET Core auth handler so **consumers** of PostQuantum.Jwt can
test their own `[Authorize]` endpoints without running ML-DSA / X-Wing — fast,
and without needing OpenSSL 3.5+ on the CI runner.

## Use it in a WebApplicationFactory test

```csharp
public class MyApiTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public MyApiTests(WebApplicationFactory<Program> factory) =>
        _factory = factory.WithWebHostBuilder(b => b.ConfigureTestServices(services =>
        {
            services.AddAuthentication(TestPqJwtOptions.DefaultScheme)
                    .AddTestPqJwtBearer(o =>
                    {
                        o.Claims.Clear();
                        o.Claims.Add(new("sub", "alice"));
                        o.Claims.Add(new("role", "admin"));   // make the caller an admin
                    });
        }));

    [Fact]
    public async Task Admin_endpoint_allows_admin()
    {
        var resp = await _factory.CreateClient().GetAsync("/admin");
        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
    }
}
```

To test the **401 path**, set `o.RequireHeader = "X-Test-Auth"` and omit that
header on the request.

## Safety

This handler authenticates **every** request (or every one with the configured
header) as the fixed principal. **Never register it outside a test host.**

As an absolute safeguard it injects `IWebHostEnvironment` and **throws at
construction** if the environment isn't in `AllowedEnvironments` (defaults:
`Test`, `Testing`, `IntegrationTest`). So even if it's accidentally wired into a
real host, startup fails loudly instead of silently authenticating everyone as
admin. Set your test host's environment accordingly (e.g.
`builder.UseEnvironment("Test")` in your `WebApplicationFactory`).

> This is a sample of the pattern. It depends only on ASP.NET Core auth, not the
> crypto library, so it's a clean candidate to lift into a published
> `PostQuantum.Jwt.Testing` package if you want one.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 33. `samples/RefreshTokenDemo/RefreshTokenDemo.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <AssemblyName>PostQuantum.Jwt.RefreshTokenDemo</AssemblyName>
    <RootNamespace>PostQuantum.Jwt.RefreshTokenDemo</RootNamespace>
  </PropertyGroup>

  <ItemGroup>
    <ProjectReference Include="..\..\src\PostQuantum.Jwt\PostQuantum.Jwt.csproj" />
    <ProjectReference Include="..\..\src\PostQuantum.Jwt.AspNetCore\PostQuantum.Jwt.AspNetCore.csproj" />
  </ItemGroup>

</Project>
```

---

## 34. `samples/RefreshTokenDemo/Program.cs`

```csharp
// PostQuantum.Jwt.RefreshTokenDemo
//
// The library's job is the ACCESS token: a short-lived, signed ML-DSA-65 JWT
// that proves "this is user X" and nothing more. But a bare access token can't
// be revoked and shouldn't be long-lived — so this demo shows the architecture
// that surrounds it: the access/refresh split with refresh-token ROTATION and
// REUSE DETECTION. This is the pattern that gives you working logout and
// revocation, which stateless JWTs alone cannot.
//
// Design (matches modern best practice):
//   • Access token  — ML-DSA-65 JWT, 15 min, carries ONLY `sub`. Sent on every
//                     API request. The library validates it. Never stored in
//                     localStorage in a real client — keep it in memory.
//   • Refresh token — opaque 64-byte random string (NOT a JWT). Long-lived.
//                     Only its SHA-256 HASH is stored server-side, so a store
//                     leak yields hashes, not usable tokens. Delivered in an
//                     HttpOnly, Secure, SameSite=Strict cookie scoped to
//                     /auth/refresh so it never rides along on normal requests.
//
// Rotation + reuse detection: every refresh issues a NEW refresh token and
// marks the old one used. If a used token is presented again, we assume theft
// and revoke the whole token "family". That is the mechanism behind real logout.
//
// DEMO STORAGE: an in-memory ConcurrentDictionary stands in for the database.
// A real service uses a durable, shared store (and the access-token signing key
// should be persisted — see WebApiDemo/FileBackedSigningKey.cs).
//
// To God be the glory - 1 Corinthians 10:31.

using System.Collections.Concurrent;
using System.Security.Cryptography;
using PostQuantum.Jwt;
using PostQuantum.Jwt.AspNetCore;

const string Issuer = "https://demo.systemslibrarian.dev";
const string Audience = "https://api.demo.local";
const string Kid = "refresh-demo-2026-01";
var AccessTokenTtl = TimeSpan.FromMinutes(15);
var RefreshTokenTtl = TimeSpan.FromDays(30);

var builder = WebApplication.CreateBuilder(args);

// Access-token signing key (ephemeral here; persist in production).
var signingKey = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
var verificationKey = MLDsa.ImportMLDsaPublicKey(
    MLDsaAlgorithm.MLDsa65, signingKey.ExportMLDsaPublicKey());

builder.Services
    .AddAuthentication(PqJwtBearerDefaults.AuthenticationScheme)
    .AddPqJwtBearer(options =>
    {
        options.ValidationParameters = new PqJwtValidationParameters
        {
            SignatureKeyResolver = kid => kid == Kid ? verificationKey : null,
            ValidIssuer = Issuer,
            ValidAudience = Audience,
        };
    });
builder.Services.AddAuthorization();

// Stand-in for the refresh-token table. Key = SHA-256(refresh token).
var store = new RefreshTokenStore();
builder.Services.AddSingleton(store);

var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();

// Mints a short-lived access token carrying ONLY `sub`. Everything else
// (role, email, org) is looked up server-side when needed — so a leaked access
// token reveals nothing an attacker didn't already know to ask for.
string MintAccessToken(string userId) => new PqJwtBuilder()
    .WithIssuer(Issuer)
    .WithAudience(Audience)
    .WithSubject(userId)
    .WithKeyId(Kid)
    .WithJwtId(Guid.NewGuid().ToString("N"))
    .WithLifetime(AccessTokenTtl)
    .SignWith(signingKey)
    .Build();

// Issues a fresh opaque refresh token, stores only its hash, sets the cookie.
void IssueRefreshCookie(HttpResponse res, string userId, string family)
{
    var raw = Convert.ToHexString(RandomNumberGenerator.GetBytes(64));
    store.Add(Hash(raw), new RefreshRecord(userId, family,
        ExpiresAt: DateTimeOffset.UtcNow + RefreshTokenTtl));
    res.Cookies.Append("refresh_token", raw, new CookieOptions
    {
        HttpOnly = true,
        Secure = true,
        SameSite = SameSiteMode.Strict,
        Path = "/auth/refresh",                 // never sent on normal requests
        MaxAge = RefreshTokenTtl,
    });
}

// -- Login: verify credentials (faked here), issue access + refresh ----------
app.MapPost("/auth/login", (string? user, HttpResponse res) =>
{
    // A real service checks a password hash here. The demo trusts the param.
    var userId = string.IsNullOrWhiteSpace(user) ? "demo-user" : user;
    IssueRefreshCookie(res, userId, family: Guid.NewGuid().ToString("N"));
    return Results.Ok(new { accessToken = MintAccessToken(userId), expiresInSeconds = (int)AccessTokenTtl.TotalSeconds });
});

// -- Refresh: rotate the refresh token, detect reuse, mint a new access token-
app.MapPost("/auth/refresh", (HttpRequest req, HttpResponse res) =>
{
    if (!req.Cookies.TryGetValue("refresh_token", out var presented) || string.IsNullOrEmpty(presented))
        return Results.Json(new { error = "Missing refresh token." }, statusCode: 401);

    var hash = Hash(presented);
    if (!store.TryGet(hash, out var record) || record.ExpiresAt < DateTimeOffset.UtcNow)
        return Results.Json(new { error = "Invalid or expired refresh token." }, statusCode: 401);

    // REUSE DETECTION: a token already marked used means either impossible
    // double-refresh or a stolen token. Assume theft; revoke the whole family.
    if (record.Used)
    {
        store.RevokeFamily(record.Family);
        return Results.Json(new { error = "Refresh token reuse detected — family revoked." }, statusCode: 401);
    }
    if (record.Revoked)
        return Results.Json(new { error = "Refresh token revoked." }, statusCode: 401);

    store.MarkUsed(hash);
    IssueRefreshCookie(res, record.UserId, record.Family);   // rotate within the same family
    return Results.Ok(new { accessToken = MintAccessToken(record.UserId), expiresInSeconds = (int)AccessTokenTtl.TotalSeconds });
});

// -- Logout: revoke server-side so the refresh token can't mint more ---------
app.MapPost("/auth/logout", (HttpRequest req, HttpResponse res) =>
{
    if (req.Cookies.TryGetValue("refresh_token", out var presented) && !string.IsNullOrEmpty(presented))
        store.Revoke(Hash(presented));
    res.Cookies.Delete("refresh_token", new CookieOptions { Path = "/auth/refresh" });
    // The current access token still works until it expires (<=15 min) — the
    // bounded blast radius is the whole point of short-lived access tokens.
    return Results.NoContent();
});

// -- A protected resource that consumes the access token ---------------------
app.MapGet("/me", (HttpContext ctx) => Results.Ok(new
{
    sub = ctx.User.FindFirst("sub")?.Value,
    note = "Access token carried only 'sub'; a real app looks up role/email server-side here.",
})).RequireAuthorization();

app.MapGet("/", () => Results.Text(
    "RefreshTokenDemo: POST /auth/login -> {accessToken} + refresh cookie. " +
    "POST /auth/refresh rotates. POST /auth/logout revokes. GET /me needs the access token. " +
    "See README.md for the full curl walkthrough incl. the reuse-detection demo."));

app.Run();

static string Hash(string raw) =>
    Convert.ToHexString(SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(raw)));

/// <summary>One stored refresh token (only its hash is the dictionary key).</summary>
internal sealed record RefreshRecord(string UserId, string Family, DateTimeOffset ExpiresAt)
{
    public bool Used { get; set; }
    public bool Revoked { get; set; }
}

/// <summary>In-memory stand-in for the refresh-token table. Thread-safe.</summary>
internal sealed class RefreshTokenStore
{
    private readonly ConcurrentDictionary<string, RefreshRecord> _byHash = new();

    public void Add(string hash, RefreshRecord record) => _byHash[hash] = record;
    public bool TryGet(string hash, out RefreshRecord record) => _byHash.TryGetValue(hash, out record!);
    public void MarkUsed(string hash) { if (_byHash.TryGetValue(hash, out var r)) r.Used = true; }
    public void Revoke(string hash) { if (_byHash.TryGetValue(hash, out var r)) r.Revoked = true; }

    public void RevokeFamily(string family)
    {
        foreach (var r in _byHash.Values)
            if (r.Family == family) r.Revoked = true;
    }
}
```

---

## 35. `samples/RefreshTokenDemo/appsettings.json`

```json
{
  "Logging": { "LogLevel": { "Default": "Information", "Microsoft.AspNetCore": "Warning" } },
  "AllowedHosts": "*"
}
```

---

## 36. `samples/RefreshTokenDemo/Properties/launchSettings.json`

```json
{
  "profiles": {
    "https": {
      "commandName": "Project",
      "launchBrowser": false,
      "applicationUrl": "https://localhost:7110;http://localhost:5110",
      "environmentVariables": { "ASPNETCORE_ENVIRONMENT": "Development" }
    }
  }
}
```

---

## 37. `samples/RefreshTokenDemo/Dockerfile`

```dockerfile
# PostQuantum.Jwt RefreshTokenDemo
# OpenSSL 3.5+ required (Azure Linux 3.0 base). Build context = repo root:
#   docker build -f samples/RefreshTokenDemo/Dockerfile -t pqjwt-refresh .

FROM mcr.microsoft.com/dotnet/sdk:10.0-azurelinux3.0 AS build
WORKDIR /src
COPY src/PostQuantum.Jwt/ src/PostQuantum.Jwt/
COPY src/PostQuantum.Jwt.AspNetCore/ src/PostQuantum.Jwt.AspNetCore/
COPY Directory.Build.props ./
COPY samples/RefreshTokenDemo/ samples/RefreshTokenDemo/
RUN dotnet restore samples/RefreshTokenDemo/RefreshTokenDemo.csproj
RUN dotnet publish samples/RefreshTokenDemo/RefreshTokenDemo.csproj -c Release -o /app --no-restore

FROM mcr.microsoft.com/dotnet/aspnet:10.0-azurelinux3.0 AS runtime
WORKDIR /app
COPY --from=build /app .
ENV ASPNETCORE_HTTP_PORTS=8080
EXPOSE 8080
ENTRYPOINT ["dotnet", "PostQuantum.Jwt.RefreshTokenDemo.dll"]
```

---

## 38. `samples/RefreshTokenDemo/README.md`

~~~markdown
# Refresh-token rotation demo

The library issues the **access token** — a short-lived, signed ML-DSA-65 JWT.
But an access token alone can't be revoked and shouldn't be long-lived. This
demo shows the architecture that surrounds it: the **access/refresh split** with
**rotation** and **reuse detection** — the pattern that gives you working logout
and revocation.

| Token | What | Lifetime | Storage | Sent |
| ----- | ---- | -------- | ------- | ---- |
| Access | ML-DSA-65 JWT, carries only `sub` | 15 min | client memory (NOT localStorage) | every API request |
| Refresh | opaque 64-byte random (not a JWT) | 30 days | server stores only its SHA-256 hash; client holds an HttpOnly cookie | only to `/auth/refresh` |

## What this defends against

The "JWT & Token Exploitation — Advanced API Attacks" guides frame two attacks
that the *token itself* can't answer — they're properties of the surrounding
architecture, which is exactly what this demo supplies:

- **Token replay / "session never invalidated"** — the bug-bounty test is: log
  out, replay the old token, and if it still works the session was never really
  killed. Here, every refresh **rotates** the refresh token and marks the old one
  used; replaying a used token triggers **reuse detection** and revokes the whole
  family. See the runnable "See reuse detection fire" walkthrough below.
- **No revocation** (a stateless JWT lives until it expires) — logout deletes the
  refresh token server-side, so it can mint no more access tokens. The current
  access token still works until expiry (≤15 min); that bounded window is the
  point of keeping it short-lived.

The token-level attacks from those same guides — `alg:none`, algorithm
confusion, weak-secret cracking, role manipulation by editing the payload,
missing signature verification — are demonstrated failing closed in
`../ConsoleDemo` (Attack Mode) and `../SpecByExample`, and mapped row-by-row in
`../HARDENING-CHECKLIST.md`. This demo deliberately covers the architectural half
that those don't.

## Run it

```bash
cd samples/RefreshTokenDemo
dotnet run
```

## Walkthrough (curl)

A cookie jar (`-c`/`-b`) stands in for the browser holding the HttpOnly cookie.

```bash
# 1. Log in -> get an access token + a refresh cookie (saved to jar.txt)
curl -sk -c jar.txt -X POST "https://localhost:7110/auth/login?user=alice" | jq

# 2. Call the protected resource with the access token
ACCESS=$(curl -sk -c jar.txt -X POST "https://localhost:7110/auth/login?user=alice" | jq -r .accessToken)
curl -sk https://localhost:7110/me -H "Authorization: Bearer $ACCESS" | jq

# 3. Refresh -> the refresh cookie is rotated, a new access token comes back
curl -sk -b jar.txt -c jar.txt -X POST https://localhost:7110/auth/refresh | jq
```

### See reuse detection fire

Rotation means the OLD refresh token is now used. Present it again and the whole
family is revoked — exactly what happens if a thief replays a stolen token:

```bash
# Capture a refresh token, use it once (rotates), then try the OLD one again.
curl -sk -c a.txt -X POST "https://localhost:7110/auth/login?user=alice" >/dev/null
cp a.txt old.txt
curl -sk -b a.txt -c a.txt -X POST https://localhost:7110/auth/refresh >/dev/null  # old.txt now stale
curl -sk -b old.txt -X POST https://localhost:7110/auth/refresh | jq
# -> {"error":"Refresh token reuse detected — family revoked."}
```

### Logout

```bash
curl -sk -b jar.txt -X POST https://localhost:7110/auth/logout -i   # 204; refresh revoked server-side
```

The current access token still validates until it expires (≤15 min). That
bounded window is the entire point of short-lived access tokens.

## What's demo-grade vs production

- The refresh store is an in-memory `ConcurrentDictionary` — use a durable,
  shared store in production (and persist the access-token signing key; see
  `../WebApiDemo/FileBackedSigningKey.cs`).
- `/auth/login` trusts the `user` query param instead of checking a password.
- No expired-entry sweeper; rely on the store's TTL/eviction in a real system.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 39. `samples/SECURE-USAGE.md`

~~~markdown
# Secure usage: getting the architecture around the token right

`PostQuantum.Jwt` makes the *token* sound — fail-closed validation, no `alg:none`,
no algorithm confusion, required `exp`. But a sound token can still sit inside an
unsound system. These are the surrounding decisions that matter, drawn from
current web-auth guidance and adapted to this library.

## 0. Authentication is not authorization (the boundary that matters most)

This library answers exactly one question: **is this token authentic, and who
does it say the caller is?** It does *not* — and cannot — answer **what is that
caller allowed to do?** That second question is your application's job, and it
is where the #1 bug class lives: **broken access control**.

A perfectly validated PostQuantum.Jwt token tells you the caller is user `123`.
It tells you nothing about whether user `123` may read order `456`, edit another
user's profile, or reach an admin route. If your server skips those checks, the
strongest token in the world doesn't save you:

- **IDOR / horizontal escalation** — `GET /api/user/123` works; the attacker
  tries `/api/user/124` with the *same valid token* and reads someone else's
  data. The token was never the problem; the missing ownership check was.
- **Vertical escalation** — a valid non-admin token reaches `/api/admin` because
  the route only checked *authentication*, not *role*.
- **Hidden-parameter / mass-assignment escalation** — a request adds
  `role=admin` and the server trusts the body over the token's identity.
- **Frontend-only restrictions** — the UI hides a button; the backend still
  honors the request. Never trust the client to enforce access.

What this means in practice:

1. **Derive identity from the token, authority from the server.** Take `sub`
   from the validated token, then look up that user's roles/permissions and the
   target resource's owner server-side, and check them on every protected route.
2. **Check ownership, not just authentication.** "Is the caller logged in?" is
   not "may the caller touch *this* object?" Compare the resource's owner to the
   token's `sub` before returning or mutating it.
3. **Enforce authorization on the backend, every time.** Hiding an action in the
   UI is not enforcement.

The `WebApiDemo`'s `/admin` policy shows the *role* half of this (authorization
on top of a valid token), but no token library can supply your per-resource
ownership checks — those are yours to write. Treat a green validation result as
the *start* of an authorization decision, never the end of one.

## 1. Put only `sub` in the access token

A signed JWT payload is **readable by anyone holding the token** — it's base64,
not encrypted. (Encrypt-for a recipient if you need confidentiality; see the
`EncryptFor` path. But even then, minimize.) Don't pack `role`, `email`,
`org`, or internal IDs into the access token. Carry `sub` and look up everything
else server-side, from a fresh query, on the routes that care.

- A leaked access token then reveals nothing an attacker didn't already know to ask for.
- Authorization decisions reflect *current* server state, not whatever was true when the token was minted.

```csharp
// Good: minimal access token.
new PqJwtBuilder()
    .WithIssuer(issuer).WithAudience(audience)
    .WithSubject(userId)                 // <- and essentially nothing else
    .WithLifetime(TimeSpan.FromMinutes(15))
    .SignWith(signingKey)
    .Build();
```

## 2. Keep the access token in memory, never in localStorage

Anything in `localStorage` is readable by any JavaScript on the page — your code,
every npm dependency, every analytics snippet, every extension. One XSS anywhere
in that tree and the token walks. Keep the access token in a JS variable / auth
context in memory. On tab refresh it's gone; bootstrap a new one from the refresh
endpoint.

## 3. Make the access token short-lived, and add a refresh token for revocation

A stateless JWT can't be revoked — logout doesn't truly invalidate it. The fix is
the access/refresh split (runnable in `RefreshTokenDemo/`):

- **Access token**: this library, ≤15 min, in memory.
- **Refresh token**: opaque random string (not a JWT), long-lived, stored
  server-side **as a hash**, delivered in an `HttpOnly; Secure; SameSite=Strict`
  cookie scoped to the refresh path so it never rides normal requests. Rotate it
  on every use and revoke the family on reuse. That's what makes logout real.

## 4. Always pin issuer and audience on the validator

Set `ValidIssuer` and `ValidAudience`. They stop a token minted for one service
from being accepted by another — free if you're single-service today, essential
the day you aren't.

## 5. Turn on replay protection where one-time use matters

For tokens that should be used once (e.g. a sensitive action), set
`RequireReplayProtection = true` and supply a `ReplayCache` — distributed if you
run more than one node (see `DistributedReplayCache/`).

## 6. Persist and protect the signing key

An ephemeral key invalidates every token on restart. Persist it (encrypted
PKCS#8 at minimum; HSM / key vault in production). See
`WebApiDemo/FileBackedSigningKey.cs`. Never log or return private key material —
only the public key is shareable.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 40. `samples/HARDENING-CHECKLIST.md`

```markdown
# JWT attack → how PostQuantum.Jwt blocks it

A defensive map of the classic JWT attacks (the ones in every bug-bounty guide)
against this library's behavior. The recurring theme: most of these are
*impossible by design* here, not "mitigated if configured." Where a row depends
on you, it says so.

| # | Attack | Blocked? | Why / what you must do |
| - | ------ | -------- | ---------------------- |
| 1 | **`alg: none`** (strip the signature) | By design | There is no unsigned code path. The validator requires `ML-DSA-65` and verifies a real signature; a `none`/missing signature can't validate. |
| 2 | **Algorithm confusion** (RS256→HS256, sign with the public key as HMAC secret) | By design | One suite only. The validator does not trust the token's `alg` to pick a verification path, and ML-DSA is asymmetric — there is no symmetric secret to confuse it with. |
| 3 | **Weak HMAC secret** (brute-force `secret`/`password123`) | By design | No shared secret exists. Signing is ML-DSA-65 (asymmetric); there is nothing to crack offline. |
| 4 | **No expiration / `exp` not checked** | By design (default) | `exp` is validated, and `RequireExpiration` rejects tokens lacking it. Keep `ValidateLifetime` on. |
| 5 | **No revocation** (stateless token lives until expiry) | Architecture | A bare access token can't be revoked — that's inherent to stateless JWTs. Use short lifetimes + the refresh/rotation pattern (`RefreshTokenDemo/`) for real logout. |
| 6 | **Sensitive data in payload** (PII/role readable) | Your choice | Signed payloads are readable. Carry only `sub`; look up the rest server-side (`SECURE-USAGE.md`). Use `EncryptFor` if you need confidentiality. |
| 7 | **`kid` injection** (kid → SQL/path traversal) | By design + your resolver | `kid` is passed to *your* `SignatureKeyResolver` as an opaque lookup value; the library never feeds it to a query or file path. Don't build an injection into your own resolver — look it up in a fixed map / key ring. |
| 8 | **Role manipulation** (edit payload to `role: admin`) | By design | Editing any byte of the payload breaks the ML-DSA signature; validation fails closed. (And if you followed #6, there's no `role` in the token to edit.) |
| 9 | **Missing signature verification** (decode but don't verify) | By design | `Validate()` always verifies the signature before returning; there is no decode-only path. It throws on failure rather than returning a degraded result. |
| 10 | **Token replay** (reuse a captured token) | Opt-in | Set `RequireReplayProtection = true` + a `ReplayCache` (distributed across nodes — `DistributedReplayCache/`). Requires a `jti`. |
| 11 | **Cross-service token acceptance** | Your config | Pin `ValidIssuer` and `ValidAudience` so a token minted elsewhere isn't accepted here. |
| 12 | **Token theft via `localStorage` + XSS** | Architecture | Not a token property — keep the access token in memory and the refresh token in an `HttpOnly` cookie (`SECURE-USAGE.md`, `RefreshTokenDemo/`). |

## The honest caveat

This library is **preview, unaudited**, and uses **non-IANA-registered**
identifiers — so its tokens are deliberately **non-interoperable** with standard
JWT stacks. It's the right tool only when you control both issuer and verifier.
That non-interoperability is itself a hardening property against tooling that
expects standard JWTs, but it is a deliberate trade-off, not a free lunch.

---

*To God be the glory — 1 Corinthians 10:31.*
```

---

## 41. `samples/PqJwtPlayground/PqJwtPlayground.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <AssemblyName>PostQuantum.Jwt.Playground</AssemblyName>
    <RootNamespace>PostQuantum.Jwt.Playground</RootNamespace>
  </PropertyGroup>

  <ItemGroup>
    <ProjectReference Include="..\..\src\PostQuantum.Jwt\PostQuantum.Jwt.csproj" />
    <ProjectReference Include="..\Shared\Pq.Samples.Shared.csproj" />
  </ItemGroup>

</Project>
```

---

## 42. `samples/PqJwtPlayground/Program.cs`

```csharp
// PqJwtPlayground — Blazor Server host.
//
// Blazor Server (not WASM) is deliberate: the ML-DSA / ML-KEM primitives need a
// real .NET 10 runtime with OpenSSL 3.5+ and do not run in the browser. All
// crypto executes server-side; private keys never leave the server.
//
// To God be the glory - 1 Corinthians 10:31.

using PostQuantum.Jwt.Playground.Components;
using PostQuantum.Jwt.Playground.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddSingleton<PqJwtDemoService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseAntiforgery();
app.MapStaticAssets();
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();

app.Run();
```

---

## 43. `samples/PqJwtPlayground/Services/PqJwtDemoService.cs`

```csharp
// PqJwtPlayground — server-side crypto service.
//
// All post-quantum crypto runs on the SERVER (Blazor Server). The PQ primitives
// require a real .NET 10 runtime with OpenSSL 3.5+; they do not run in the
// browser. Demo keys live in this singleton for the life of the process and are
// never sent to the client.
//
// To God be the glory — 1 Corinthians 10:31.

using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using PostQuantum.Jwt;
using PostQuantum.Jwt.Cryptography;
using Pq.Samples.Shared;

namespace PostQuantum.Jwt.Playground.Services;

/// <summary>Result of building a token, for display in the UI.</summary>
public sealed record BuildResult(
    string Token,
    int EncodedLength,
    int ApproxBytes,
    int Segments,
    bool Encrypted,
    double ElapsedMs,
    string DecodedHeaderJson,
    string DecodedPayloadJson);

/// <summary>Result of validating a token, for display in the UI.</summary>
public sealed record ValidationView(
    bool Valid,
    string Message,          // raw validator message (shown as technical detail)
    string What,             // plain-language headline when rejected
    string Why,              // plain-language explanation when rejected
    double ElapsedMs,
    bool WasEncrypted,
    string? Subject,
    string? Issuer,
    string? Audience,
    string? JwtId,
    string? ExpiresAt,
    string ClaimsJson);

/// <summary>One custom claim row from the UI. Value type is inferred safely.</summary>
public readonly record struct ClaimInput(string Name, string Value);

/// <summary>
/// Holds demo keys and wraps the library so Razor components stay thin.
/// Singleton: one key set per process. Regenerating replaces them.
/// </summary>
public sealed class PqJwtDemoService : IDisposable
{
    private readonly object _gate = new();
    private MLDsa _signingKey;
    private MLDsa _verificationKey;
    private XWingPrivateKey _recipientKey;

    public string SigningKid { get; private set; } = "playground-key-1";

    public PqJwtDemoService()
    {
        _signingKey = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
        _verificationKey = MLDsa.ImportMLDsaPublicKey(
            MLDsaAlgorithm.MLDsa65, _signingKey.ExportMLDsaPublicKey());
        _recipientKey = XWingPrivateKey.Generate();
    }

    /// <summary>Base64 of the current ML-DSA-65 public verification key.</summary>
    public string VerificationPublicKeyBase64
    {
        get { lock (_gate) return Convert.ToBase64String(_verificationKey.ExportMLDsaPublicKey()); }
    }

    /// <summary>Base64 of the current X-Wing recipient public key (1216 bytes).</summary>
    public string RecipientPublicKeyBase64
    {
        get { lock (_gate) return Convert.ToBase64String(_recipientKey.PublicKey.Export()); }
    }

    /// <summary>Regenerate all demo keys. Previously issued tokens stop validating.</summary>
    public void RegenerateKeys()
    {
        lock (_gate)
        {
            _signingKey.Dispose();
            _verificationKey.Dispose();
            _recipientKey.Dispose();

            _signingKey = MLDsa.GenerateKey(MLDsaAlgorithm.MLDsa65);
            _verificationKey = MLDsa.ImportMLDsaPublicKey(
                MLDsaAlgorithm.MLDsa65, _signingKey.ExportMLDsaPublicKey());
            _recipientKey = XWingPrivateKey.Generate();
            SigningKid = "playground-key-" + Random.Shared.Next(1000, 9999);
        }
    }

    /// <summary>
    /// Build a token from UI inputs. <paramref name="claims"/> are optional extra
    /// claims as name/value rows; each value is inferred to bool, long, double,
    /// or string (in that order) so the UI never has to hand us raw JSON.
    /// </summary>
    public BuildResult Build(
        string? subject,
        string? issuer,
        string? audience,
        int lifetimeMinutes,
        bool encrypt,
        bool includeJti,
        IReadOnlyList<ClaimInput>? claims)
    {
        lock (_gate)
        {
            var builder = new PqJwtBuilder()
                .WithLifetime(TimeSpan.FromMinutes(Math.Clamp(lifetimeMinutes, 1, 1440)))
                .WithKeyId(SigningKid);

            if (!string.IsNullOrWhiteSpace(subject)) builder = builder.WithSubject(subject);
            if (!string.IsNullOrWhiteSpace(issuer)) builder = builder.WithIssuer(issuer);
            if (!string.IsNullOrWhiteSpace(audience)) builder = builder.WithAudience(audience);
            if (includeJti) builder = builder.WithJwtId(Guid.NewGuid().ToString("N"));

            if (claims is not null)
            {
                foreach (var c in claims)
                {
                    if (string.IsNullOrWhiteSpace(c.Name)) continue;
                    builder = builder.WithClaim(c.Name, InferValue(c.Value));
                }
            }

            builder = builder.SignWith(_signingKey);
            if (encrypt) builder = builder.EncryptFor(_recipientKey.PublicKey);

            var sw = Stopwatch.StartNew();
            string token = builder.Build();
            sw.Stop();

            var segments = token.Split('.');
            var (header, payload) = DecodeForDisplay(segments, encrypt);

            return new BuildResult(
                Token: token,
                EncodedLength: token.Length,
                ApproxBytes: token.Length * 3 / 4,
                Segments: segments.Length,
                Encrypted: encrypt,
                ElapsedMs: sw.Elapsed.TotalMilliseconds,
                DecodedHeaderJson: header,
                DecodedPayloadJson: payload);
        }
    }

    // Infer a typed claim value from a UI string, most specific first.
    private static object InferValue(string raw)
    {
        if (bool.TryParse(raw, out var b)) return b;
        if (long.TryParse(raw, out var l)) return l;
        if (double.TryParse(raw, System.Globalization.CultureInfo.InvariantCulture, out var d)) return d;
        return raw;
    }

    /// <summary>Validate a token against the current demo keys. Fail-closed: catches the throw.</summary>
    public ValidationView Validate(string token)
    {
        lock (_gate)
        {
            var validator = new PqJwtValidator(new PqJwtValidationParameters
            {
                SignatureVerificationKey = _verificationKey,
                DecryptionKey = _recipientKey,
                RequireReplayProtection = false,
            });

            var sw = Stopwatch.StartNew();
            try
            {
                var r = validator.Validate(token);
                sw.Stop();
                var claimsJson = JsonSerializer.Serialize(
                    r.Claims.ToDictionary(kv => kv.Key, kv => kv.Value),
                    new JsonSerializerOptions { WriteIndented = true });

                return new ValidationView(
                    Valid: true,
                    Message: "Token is valid.",
                    What: "Valid",
                    Why: "Signature verified, lifetime and claims passed every check.",
                    ElapsedMs: sw.Elapsed.TotalMilliseconds,
                    WasEncrypted: r.WasEncrypted,
                    Subject: r.Subject,
                    Issuer: r.Issuer,
                    Audience: r.GetString("aud"),
                    JwtId: r.JwtId,
                    ExpiresAt: r.ExpiresAt?.ToString("u"),
                    ClaimsJson: claimsJson);
            }
            catch (PqJwtValidationException ex)
            {
                sw.Stop();
                var (what, why) = RejectionExplainer.Explain(ex);
                return new ValidationView(
                    Valid: false,
                    Message: ex.Message,
                    What: what,
                    Why: why,
                    ElapsedMs: sw.Elapsed.TotalMilliseconds,
                    WasEncrypted: false,
                    Subject: null, Issuer: null, Audience: null, JwtId: null, ExpiresAt: null,
                    ClaimsJson: "{}");
            }
        }
    }

    // Decode header (and payload for signed tokens) purely for display.
    // Encrypted tokens have an opaque ciphertext payload, so we only show the header.
    private static (string Header, string Payload) DecodeForDisplay(string[] segments, bool encrypted)
    {
        string header = "{}";
        string payload = encrypted
            ? "\"(encrypted — payload is ciphertext until decrypted by the recipient)\""
            : "{}";
        try
        {
            if (segments.Length >= 1) header = Pretty(DecodeSegment(segments[0]));
            if (!encrypted && segments.Length >= 2) payload = Pretty(DecodeSegment(segments[1]));
        }
        catch { /* display-only; ignore decode hiccups */ }
        return (header, payload);
    }

    private static string DecodeSegment(string seg)
    {
        string s = seg.Replace('-', '+').Replace('_', '/');
        switch (s.Length % 4) { case 2: s += "=="; break; case 3: s += "="; break; }
        return System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(s));
    }

    private static string Pretty(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            return JsonSerializer.Serialize(doc.RootElement, new JsonSerializerOptions { WriteIndented = true });
        }
        catch { return json; }
    }

    public void Dispose()
    {
        _signingKey.Dispose();
        _verificationKey.Dispose();
        _recipientKey.Dispose();
    }
}
```

---

## 44. `samples/PqJwtPlayground/Components/_Imports.razor`

```razor
@using System.Net.Http
@using Microsoft.AspNetCore.Components.Forms
@using Microsoft.AspNetCore.Components.Routing
@using Microsoft.AspNetCore.Components.Web
@using Microsoft.JSInterop
@using PostQuantum.Jwt.Playground
@using PostQuantum.Jwt.Playground.Components
@using PostQuantum.Jwt.Playground.Components.Layout
@using PostQuantum.Jwt.Playground.Services
@using Pq.Samples.Shared
```

---

## 45. `samples/PqJwtPlayground/Components/App.razor`

```razor
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Post-Quantum JWT Playground</title>
    <base href="/" />
    <link rel="stylesheet" href="app.css" />
    <HeadOutlet />
</head>
<body>
    <Routes />
    <script src="_framework/blazor.web.js"></script>
</body>
</html>
```

---

## 46. `samples/PqJwtPlayground/Components/Routes.razor`

```razor
<Router AppAssembly="@typeof(Program).Assembly">
    <Found Context="routeData">
        <RouteView RouteData="@routeData" DefaultLayout="@typeof(Layout.MainLayout)" />
        <FocusOnNavigate RouteData="@routeData" Selector="h1" />
    </Found>
</Router>
```

---

## 47. `samples/PqJwtPlayground/Components/Layout/MainLayout.razor`

```razor
@inherits LayoutComponentBase

<div class="shell">
    <header class="topbar">
        <div class="brand">
            <span class="glyph">&#9763;</span>
            <span class="brandtext">POST&#8211;QUANTUM <strong>JWT</strong> PLAYGROUND</span>
        </div>
        <div class="badge">ML-DSA-65 &middot; X-Wing &middot; .NET 10 &middot; preview</div>
    </header>
    <main>@Body</main>
    <footer class="footnote">
        Preview software, not audited &middot; non-IANA identifiers, non-interoperable tokens
        &middot; <em>To God be the glory &#8212; 1 Corinthians 10:31.</em>
    </footer>
</div>
```

---

## 48. `samples/PqJwtPlayground/Components/Pages/Home.razor`

```razor
@page "/"
@rendermode InteractiveServer
@inject PqJwtDemoService Demo

<PageTitle>Post-Quantum JWT Playground</PageTitle>

<h1 class="screenreader">Post-Quantum JWT Playground</h1>

<div class="warnbar" role="note">
    These tokens use <code>ML-DSA-65</code> / <code>X-Wing</code> / <code>A256GCM</code> &mdash;
    <strong>not</strong> IANA-registered. They will not validate in generic JWT tooling.
    This is preview, unaudited software.
</div>

<div class="grid">

    <!-- 01 BUILD -->
    <section class="card" aria-labelledby="build-h">
        <h2 id="build-h"><span class="num">01</span> Build a token</h2>

        <label>Subject (sub)
            <input @bind="_sub" placeholder="user-123" aria-label="Subject claim" />
        </label>
        <div class="row">
            <label>Issuer (iss)
                <input @bind="_iss" placeholder="https://issuer.example" aria-label="Issuer claim" />
            </label>
            <label>Audience (aud)
                <input @bind="_aud" placeholder="https://api.example" aria-label="Audience claim" />
            </label>
        </div>
        <div class="row">
            <label>Lifetime (minutes)
                <input type="number" min="1" max="1440" @bind="_minutes" aria-label="Lifetime in minutes" />
            </label>
            <label class="check">
                <input type="checkbox" @bind="_encrypt" /> Encrypt (X-Wing)
            </label>
            <label class="check">
                <input type="checkbox" @bind="_jti" /> Include jti
            </label>
        </div>

        <fieldset class="claims-edit">
            <legend>Custom claims</legend>
            @if (_claimRows.Count == 0)
            {
                <p class="empty-state">No custom claims yet. Add one (e.g. <code>role</code> = <code>admin</code>) or just build with the standard claims above.</p>
            }
            @for (int i = 0; i < _claimRows.Count; i++)
            {
                var idx = i;
                <div class="claim-row">
                    <input class="cn" placeholder="name (e.g. role)" @bind="_claimRows[idx].Name"
                           @onkeydown="@(e => OnClaimKey(e, idx))" aria-label="Claim name" />
                    <input class="cv" placeholder="value (admin / 3 / true)" @bind="_claimRows[idx].Value"
                           @onkeydown="@(e => OnClaimKey(e, idx))" aria-label="Claim value" />
                    <button class="mini" @onclick="() => RemoveClaim(idx)" aria-label="Remove claim">&times;</button>
                </div>
            }
            <button class="ghost mini-add" @onclick="AddClaim">+ add claim</button>
            <p class="hint small">Values are typed automatically: <code>true</code>/<code>false</code> &rarr; bool,
                whole numbers &rarr; integer, decimals &rarr; number, everything else &rarr; string. No raw JSON needed.
                Press <kbd>Enter</kbd> on the last row to add another.</p>
        </fieldset>

        <button class="primary" @onclick="DoBuild">Create token</button>

        @if (_buildError is not null)
        {
            <p class="err" role="alert">@_buildError</p>
        }

        @if (_build is not null)
        {
            <div class="output">
                <div class="tokenhead">
                    <span>Compact token</span>
                    <span class="chip">@_build.Segments segments</span>
                    <span class="chip">@_build.ApproxBytes bytes</span>
                    <span class="chip">@_build.ElapsedMs.ToString("F1") ms</span>
                </div>
                <pre class="token" tabindex="0">@_build.Token</pre>

                <div class="cols">
                    <div>
                        <h3>Header</h3>
                        <pre class="json">@_build.DecodedHeaderJson</pre>
                    </div>
                    <div>
                        <h3>Payload</h3>
                        <pre class="json">@_build.DecodedPayloadJson</pre>
                    </div>
                </div>

                <SizeBar PqBytes="_build.ApproxBytes" Encrypted="_build.Encrypted" />

                <button class="ghost" @onclick="UseInValidator">Send to validator &darr;</button>
            </div>
        }
    </section>

    <!-- 02 VALIDATE -->
    <section class="card" aria-labelledby="val-h">
        <h2 id="val-h"><span class="num">02</span> Validate a token</h2>
        <p class="hint">Validates against this session's demo keys. Fail-closed: anything wrong is rejected with a reason.</p>

        <label>Token
            <textarea rows="6" @bind="_validateInput" placeholder="paste a token..." aria-label="Token to validate"></textarea>
        </label>
        <button class="primary" @onclick="DoValidate">Validate</button>

        @if (_validation is not null)
        {
            <div class="result @(_validation.Valid ? "ok" : "bad")" role="status">
                <div class="resulthead">
                    <span class="status">@(_validation.Valid ? "VALID" : "REJECTED")</span>
                    <span class="chip">@_validation.ElapsedMs.ToString("F1") ms</span>
                    @if (_validation.WasEncrypted)
                    {
                        <span class="chip">decrypted</span>
                    }
                </div>

                @if (_validation.Valid)
                {
                    <table class="claims">
                        <tbody>
                            <tr><td>sub</td><td>@(_validation.Subject ?? "—")</td></tr>
                            <tr><td>iss</td><td>@(_validation.Issuer ?? "—")</td></tr>
                            <tr><td>aud</td><td>@(_validation.Audience ?? "—")</td></tr>
                            <tr><td>jti</td><td>@(_validation.JwtId ?? "—")</td></tr>
                            <tr><td>exp</td><td>@(_validation.ExpiresAt ?? "—")</td></tr>
                        </tbody>
                    </table>
                    <h3>All claims</h3>
                    <pre class="json">@_validation.ClaimsJson</pre>
                }
                else
                {
                    <!-- The highest-value teaching moment: WHY it was rejected. -->
                    <div class="why">
                        <h3>Why was this rejected?</h3>
                        <p class="why-what">@_validation.What</p>
                        <p class="why-why">@_validation.Why</p>
                        <details>
                            <summary>Technical detail</summary>
                            <code class="raw">@_validation.Message</code>
                        </details>
                    </div>
                }
            </div>
        }
    </section>

    <!-- 03 KEYS -->
    <section class="card span2" aria-labelledby="keys-h">
        <h2 id="keys-h"><span class="num">03</span> Session keys</h2>
        <p class="hint">
            Generated server-side and held in memory. Private keys never reach the browser.
            Regenerating invalidates tokens built with the old keys.
        </p>
        <div class="cols">
            <div>
                <h3>ML-DSA-65 verification (public)</h3>
                <pre class="json mono small">@_verPub</pre>
            </div>
            <div>
                <h3>X-Wing recipient (public, 1216 B)</h3>
                <pre class="json mono small">@_recPub</pre>
            </div>
        </div>
        <button class="ghost" @onclick="Regenerate">Regenerate keys</button>
        <span class="kid">active kid: <code>@Demo.SigningKid</code></span>
    </section>

    <!-- 04 SECURITY PROPERTIES -->
    <section class="card span2" aria-labelledby="props-h">
        <h2 id="props-h"><span class="num">04</span> What this protects against</h2>
        <div class="props">
            <div class="prop"><span class="ok-dot"></span><strong>Forgery &amp; tampering</strong>
                <p>ML-DSA-65 over header+payload. Edit any claim and the signature no longer verifies.</p></div>
            <div class="prop"><span class="ok-dot"></span><strong>Algorithm downgrade</strong>
                <p>The validator accepts one suite and never trusts the token's own <code>alg</code>. No <code>alg: none</code> path exists.</p></div>
            <div class="prop"><span class="ok-dot"></span><strong>Quantum harvest-now-decrypt-later</strong>
                <p>Hybrid X-Wing: an attacker must break <em>both</em> X25519 and ML-KEM-768 to recover an encrypted payload.</p></div>
            <div class="prop"><span class="ok-dot"></span><strong>Stale &amp; replayed tokens</strong>
                <p><code>exp</code> is required; <code>nbf</code> enforced; optional <code>jti</code> replay cache rejects reuse.</p></div>
            <div class="prop warn"><span class="warn-dot"></span><strong>Not protected: interop</strong>
                <p>Non-IANA identifiers mean these tokens are deliberately non-interoperable with standard JWT stacks.</p></div>
            <div class="prop warn"><span class="warn-dot"></span><strong>Not protected: audited assurance</strong>
                <p>Preview software; the construction has not had an independent third-party audit.</p></div>
        </div>
    </section>

</div>

@code {
    // build inputs
    private string _sub = "user-123";
    private string _iss = "https://issuer.example";
    private string _aud = "https://api.example";
    private int _minutes = 15;
    private bool _encrypt;
    private bool _jti = true;

    // mutable claim rows (class so @bind can write into list elements)
    private sealed class Row { public string Name { get; set; } = ""; public string Value { get; set; } = ""; }
    private readonly List<Row> _claimRows = new() { new Row { Name = "role", Value = "admin" } };

    private BuildResult? _build;
    private string? _buildError;

    private string _validateInput = "";
    private ValidationView? _validation;

    private string _verPub = "";
    private string _recPub = "";

    protected override void OnInitialized() => RefreshKeys();

    private void RefreshKeys()
    {
        _verPub = Wrap(Demo.VerificationPublicKeyBase64);
        _recPub = Wrap(Demo.RecipientPublicKeyBase64);
    }

    private void AddClaim() => _claimRows.Add(new Row());
    private void RemoveClaim(int i) { if (i >= 0 && i < _claimRows.Count) _claimRows.RemoveAt(i); }

    // Enter on the last row appends a new empty row, so a keyboard user can add
    // several claims without reaching for the mouse.
    private void OnClaimKey(KeyboardEventArgs e, int idx)
    {
        if (e.Key == "Enter" && idx == _claimRows.Count - 1)
            AddClaim();
    }

    private void DoBuild()
    {
        _buildError = null;
        try
        {
            var claims = _claimRows
                .Where(r => !string.IsNullOrWhiteSpace(r.Name))
                .Select(r => new ClaimInput(r.Name.Trim(), r.Value))
                .ToList();
            _build = Demo.Build(_sub, _iss, _aud, _minutes, _encrypt, _jti, claims);
        }
        catch (Exception ex)
        {
            _build = null;
            _buildError = "Could not build token: " + ex.Message;
        }
    }

    private void DoValidate()
    {
        if (string.IsNullOrWhiteSpace(_validateInput)) return;
        _validation = Demo.Validate(_validateInput.Trim());
    }

    private void UseInValidator()
    {
        if (_build is not null)
        {
            _validateInput = _build.Token;
            _validation = null;
        }
    }

    private void Regenerate()
    {
        Demo.RegenerateKeys();
        RefreshKeys();
        _validation = null;
        _build = null;
    }

    private static string Wrap(string s)
    {
        const int w = 64;
        var sb = new System.Text.StringBuilder(s.Length + s.Length / w + 1);
        for (int i = 0; i < s.Length; i += w)
            sb.AppendLine(s.Substring(i, Math.Min(w, s.Length - i)));
        return sb.ToString().TrimEnd();
    }
}
```

---

## 49. `samples/PqJwtPlayground/Components/Pages/SizeBar.razor`

```razor
@* Token-size comparison. Uses representative classical sizes and the ACTUAL
   measured PQ token size from this build, on a shared scale, so the gap is
   honest rather than illustrative. *@
<div class="sizebar">
    <h3>Token size vs classical</h3>
    @{
        // Representative compact-JWT sizes for the same small claim set.
        const int hs256 = 180;   // HMAC-SHA256
        const int es256 = 230;   // ECDSA P-256
        const int eddsa = 240;   // Ed25519
        int max = Math.Max(PqBytes, 1);
    }
    <div class="bar"><span class="lbl">HS256</span><span class="track"><span class="fill c1" style="width:@Pct(hs256, max)%"></span></span><span class="val">~@hs256 B</span></div>
    <div class="bar"><span class="lbl">ES256</span><span class="track"><span class="fill c1" style="width:@Pct(es256, max)%"></span></span><span class="val">~@es256 B</span></div>
    <div class="bar"><span class="lbl">EdDSA</span><span class="track"><span class="fill c2" style="width:@Pct(eddsa, max)%"></span></span><span class="val">~@eddsa B</span></div>
    <div class="bar"><span class="lbl">@(Encrypted ? "PQ enc" : "PQ sig")</span><span class="track"><span class="fill c3" style="width:100%"></span></span><span class="val">@PqBytes B</span></div>
    <p class="hint small">
        Measured this build: <strong>@PqBytes bytes</strong>
        (@(Multiple(PqBytes, es256))&times; an ES256 token).
        ML-DSA-65 signatures are ~3.3&nbsp;KB; X-Wing encryption adds ~1.5&nbsp;KB.
        Comfortable in an <code>Authorization</code> header; usually too large for cookies.
    </p>
</div>

@code {
    [Parameter] public int PqBytes { get; set; }
    [Parameter] public bool Encrypted { get; set; }
    private static int Pct(int v, int max) => Math.Clamp((int)Math.Round(100.0 * v / max), 1, 100);
    private static string Multiple(int v, int baseline) => baseline == 0 ? "—" : (v / (double)baseline).ToString("F0");
}
```

---

## 50. `samples/PqJwtPlayground/wwwroot/app.css`

```css
/* PqJwtPlayground — "cipher terminal" aesthetic.
   Deep ink background, phosphor-green + amber accents, monospace display.
   To God be the glory — 1 Corinthians 10:31. */

@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Space+Mono:wght@400;700&display=swap');

:root {
    --ink:        #0a0e0d;
    --ink-2:      #0f1614;
    --panel:      #111b18;
    --panel-2:    #14211d;
    --line:       #1f322c;
    --text:       #d7e4de;
    --dim:        #6f8a80;
    --phos:       #4ef0a8;   /* phosphor green */
    --phos-dim:   #2bbd80;
    --amber:      #f0b24e;
    --red:        #ff6b6b;
    --shadow:     0 18px 50px rgba(0,0,0,.55);
}

* { box-sizing: border-box; }

html, body {
    margin: 0;
    background:
        radial-gradient(1200px 600px at 80% -10%, #11201b 0%, transparent 60%),
        radial-gradient(900px 500px at -10% 110%, #161f12 0%, transparent 55%),
        var(--ink);
    color: var(--text);
    font-family: 'IBM Plex Mono', ui-monospace, monospace;
    font-size: 14px;
    line-height: 1.5;
    -webkit-font-smoothing: antialiased;
}

/* subtle scanline texture */
body::before {
    content: "";
    position: fixed; inset: 0; pointer-events: none; z-index: 0;
    background: repeating-linear-gradient(0deg, rgba(255,255,255,.015) 0 1px, transparent 1px 3px);
    mix-blend-mode: overlay;
}

.shell { position: relative; z-index: 1; max-width: 1180px; margin: 0 auto; padding: 28px 22px 60px; }

.topbar {
    display: flex; align-items: center; justify-content: space-between;
    gap: 16px; padding-bottom: 20px; border-bottom: 1px solid var(--line); margin-bottom: 22px;
}
.brand { display: flex; align-items: center; gap: 12px; }
.glyph { color: var(--phos); font-size: 22px; text-shadow: 0 0 14px rgba(78,240,168,.6); }
.brandtext { font-family: 'Space Mono', monospace; letter-spacing: .14em; font-size: 13px; color: var(--dim); }
.brandtext strong { color: var(--text); }
.badge {
    font-size: 11px; letter-spacing: .08em; color: var(--amber);
    border: 1px solid #3a2f12; background: #1a1407; padding: 5px 10px; border-radius: 999px;
}

.warnbar {
    border: 1px solid #3a2f12; background: linear-gradient(180deg, #1c1606, #140f04);
    color: #e9cd92; padding: 10px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 22px;
}
.warnbar code { color: var(--amber); background: #241a07; padding: 1px 6px; border-radius: 5px; }

.grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
.card {
    background: linear-gradient(180deg, var(--panel), var(--panel-2));
    border: 1px solid var(--line); border-radius: 16px; padding: 20px;
    box-shadow: var(--shadow); animation: rise .5s ease both;
}
.card.span2 { grid-column: 1 / -1; }
@keyframes rise { from { opacity: 0; transform: translateY(10px); } }

h2 { margin: 0 0 16px; font-family: 'Space Mono', monospace; font-size: 16px; letter-spacing: .03em; display: flex; align-items: baseline; gap: 10px; }
.num { color: var(--phos); font-size: 12px; border: 1px solid var(--phos-dim); border-radius: 6px; padding: 2px 7px; }
h3 { font-size: 11.5px; letter-spacing: .1em; text-transform: uppercase; color: var(--dim); margin: 16px 0 6px; }

label { display: block; font-size: 12px; color: var(--dim); margin-bottom: 12px; }
.row { display: flex; gap: 12px; }
.row > label { flex: 1; }
.check { display: flex; align-items: center; gap: 8px; color: var(--text); white-space: nowrap; }
.check input { width: auto; }

input, textarea {
    width: 100%; margin-top: 5px; background: var(--ink-2); color: var(--text);
    border: 1px solid var(--line); border-radius: 8px; padding: 9px 11px;
    font-family: inherit; font-size: 13px; transition: border-color .15s, box-shadow .15s;
}
input:focus, textarea:focus { outline: none; border-color: var(--phos-dim); box-shadow: 0 0 0 3px rgba(78,240,168,.12); }
textarea { resize: vertical; }

button { font-family: 'Space Mono', monospace; cursor: pointer; border-radius: 9px; padding: 10px 16px; font-size: 13px; letter-spacing: .03em; transition: transform .12s, filter .15s, background .15s; }
button:active { transform: translateY(1px); }
button.primary { background: var(--phos); color: #04140c; border: none; font-weight: 700; box-shadow: 0 0 22px rgba(78,240,168,.25); }
button.primary:hover { filter: brightness(1.08); }
button.ghost { background: transparent; color: var(--phos); border: 1px solid var(--phos-dim); margin-top: 12px; }
button.ghost:hover { background: rgba(78,240,168,.08); }

.output { margin-top: 18px; border-top: 1px dashed var(--line); padding-top: 16px; }
.tokenhead { display: flex; align-items: center; gap: 8px; font-size: 11px; letter-spacing: .08em; text-transform: uppercase; color: var(--dim); margin-bottom: 8px; }
.chip { background: #0c1512; border: 1px solid var(--line); color: var(--phos); border-radius: 999px; padding: 2px 9px; font-size: 11px; }
pre.token { background: #050a08; border: 1px solid var(--line); border-radius: 10px; padding: 12px; font-size: 11.5px; color: var(--phos); white-space: pre-wrap; word-break: break-all; max-height: 180px; overflow: auto; }
pre.json { background: #050a08; border: 1px solid var(--line); border-radius: 10px; padding: 12px; font-size: 11.5px; color: #bfe9d4; white-space: pre-wrap; word-break: break-word; }
pre.small { font-size: 10.5px; max-height: 150px; overflow: auto; }
.mono { color: var(--dim); }
.cols { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }

.hint { color: var(--dim); font-size: 12px; margin: 0 0 12px; }
.hint.small { font-size: 11px; margin-top: 8px; }
.err { color: var(--red); font-size: 12.5px; }

.result { margin-top: 16px; border-radius: 12px; padding: 14px; border: 1px solid var(--line); }
.result.ok { background: linear-gradient(180deg, #08160f, #0a1d13); border-color: var(--phos-dim); }
.result.bad { background: linear-gradient(180deg, #190a0a, #1d0d0d); border-color: #5a2a2a; }
.resulthead { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.status { font-family: 'Space Mono', monospace; font-weight: 700; letter-spacing: .12em; }
.result.ok .status { color: var(--phos); }
.result.bad .status { color: var(--red); }
.msg { color: #ffb4b4; font-size: 12.5px; margin: 6px 0 0; }

table.claims { width: 100%; border-collapse: collapse; margin-top: 4px; }
table.claims td { padding: 5px 8px; border-bottom: 1px solid var(--line); font-size: 12.5px; }
table.claims td:first-child { color: var(--dim); width: 70px; }

.sizebar { margin-top: 16px; }
.bar { display: flex; align-items: center; gap: 10px; margin: 6px 0; font-size: 12px; }
.bar .lbl { width: 64px; color: var(--dim); }
.bar .track { flex: 1; height: 16px; background: #06100c; border: 1px solid var(--line); border-radius: 6px; overflow: hidden; }
.bar .fill { display: block; height: 100%; border-radius: 5px; transition: width .6s cubic-bezier(.2,.8,.2,1); }
.fill.c1 { background: #2b6e57; }
.fill.c2 { background: #3a8f6d; }
.fill.c3 { background: linear-gradient(90deg, var(--phos-dim), var(--phos)); }
.bar .val { width: 64px; text-align: right; color: var(--text); }

.kid { margin-left: 14px; color: var(--dim); font-size: 12px; }
.kid code { color: var(--amber); }

.footnote { margin-top: 30px; padding-top: 16px; border-top: 1px solid var(--line); color: var(--dim); font-size: 11.5px; text-align: center; }
.footnote em { color: var(--phos-dim); font-style: italic; }
.screenreader { position: absolute; left: -9999px; }

@media (max-width: 820px) {
    .grid { grid-template-columns: 1fr; }
    .cols { grid-template-columns: 1fr; }
    .row { flex-direction: column; gap: 0; }
}

/* ── custom-claim editor ───────────────────────────────────────────── */
.claims-edit { border: 1px solid var(--line); border-radius: 12px; padding: 12px 14px 14px; margin: 4px 0 14px; }
.claims-edit legend { font-size: 11px; letter-spacing: .1em; text-transform: uppercase; color: var(--dim); padding: 0 6px; }
.claim-row { display: flex; gap: 8px; margin-bottom: 8px; }
.claim-row .cn { flex: 0 0 38%; }
.claim-row .cv { flex: 1; }
.claim-row input { margin-top: 0; }
button.mini { flex: 0 0 auto; background: transparent; border: 1px solid var(--line); color: var(--dim); border-radius: 8px; padding: 0 12px; font-size: 16px; line-height: 1; }
button.mini:hover { color: var(--red); border-color: #5a2a2a; }
button.mini-add { padding: 6px 12px; font-size: 12px; }

/* ── why-rejected panel ────────────────────────────────────────────── */
.why { margin-top: 6px; }
.why h3 { color: var(--red); margin-top: 4px; }
.why-what { font-family: 'Space Mono', monospace; font-weight: 700; color: #ffd0d0; margin: 2px 0 6px; font-size: 14px; }
.why-why { color: #f0c9c9; font-size: 12.5px; margin: 0 0 10px; line-height: 1.55; }
.why details { border-top: 1px solid #3a2020; padding-top: 8px; }
.why summary { cursor: pointer; color: var(--dim); font-size: 11.5px; letter-spacing: .05em; }
.why .raw { display: block; margin-top: 8px; color: #c89a9a; font-size: 11.5px; background: #160c0c; border: 1px solid #3a2020; border-radius: 8px; padding: 8px 10px; }

/* ── security-properties grid ──────────────────────────────────────── */
.props { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 14px; }
.prop { background: #0c1512; border: 1px solid var(--line); border-radius: 12px; padding: 12px 14px; position: relative; }
.prop strong { display: block; margin: 4px 0 4px 18px; font-size: 13px; }
.prop p { margin: 0 0 0 18px; color: var(--dim); font-size: 12px; line-height: 1.5; }
.prop .ok-dot, .prop .warn-dot { position: absolute; top: 15px; left: 14px; width: 9px; height: 9px; border-radius: 50%; }
.prop .ok-dot { background: var(--phos); box-shadow: 0 0 10px rgba(78,240,168,.6); }
.prop.warn { border-color: #3a2f12; background: #150f04; }
.prop .warn-dot { background: var(--amber); box-shadow: 0 0 10px rgba(240,178,78,.5); }

@media (max-width: 820px) {
    .props { grid-template-columns: 1fr; }
    .claim-row { flex-wrap: wrap; }
    .claim-row .cn, .claim-row .cv { flex: 1 1 100%; }
    .token, pre.json { font-size: 11px; }
}

/* claims editor: empty state + keyboard hint */
.empty-state { color: var(--dim); font-size: 12px; margin: 2px 0 10px; line-height: 1.5; }
.empty-state code { color: var(--phos); background: #0c1512; padding: 1px 6px; border-radius: 5px; }
kbd { font-family: 'IBM Plex Mono', monospace; font-size: 11px; background: #0c1512; border: 1px solid var(--line); border-bottom-width: 2px; border-radius: 5px; padding: 1px 6px; color: var(--text); }
```

---

## 51. `samples/PqJwtPlayground/appsettings.json`

```json
{
  "Logging": { "LogLevel": { "Default": "Information", "Microsoft.AspNetCore": "Warning" } },
  "AllowedHosts": "*"
}
```

---

## 52. `samples/PqJwtPlayground/Properties/launchSettings.json`

```json
{
  "profiles": {
    "https": {
      "commandName": "Project",
      "launchBrowser": true,
      "applicationUrl": "https://localhost:7100;http://localhost:5100",
      "environmentVariables": { "ASPNETCORE_ENVIRONMENT": "Development" }
    }
  }
}
```

---

## 53. `samples/PqJwtPlayground/Dockerfile`

```dockerfile
# PqJwtPlayground (Blazor Server)
#
# OpenSSL 3.5+ required for ML-KEM / ML-DSA. Use the Azure Linux 3.0 images;
# the default Ubuntu 24.04 .NET 10 images ship OpenSSL 3.0 and fail closed on
# the PQ paths. Build from the REPOSITORY ROOT:
#   docker build -f samples/PqJwtPlayground/Dockerfile -t pqjwt-playground .
#   docker run --rm -p 5100:8080 pqjwt-playground

FROM mcr.microsoft.com/dotnet/sdk:10.0-azurelinux3.0 AS build
WORKDIR /src
COPY src/PostQuantum.Jwt/ src/PostQuantum.Jwt/
COPY Directory.Build.props ./
COPY samples/Shared/ samples/Shared/
COPY samples/PqJwtPlayground/ samples/PqJwtPlayground/
RUN dotnet restore samples/PqJwtPlayground/PqJwtPlayground.csproj
RUN dotnet publish samples/PqJwtPlayground/PqJwtPlayground.csproj -c Release -o /app --no-restore

FROM mcr.microsoft.com/dotnet/aspnet:10.0-azurelinux3.0 AS runtime
WORKDIR /app
COPY --from=build /app .
ENV ASPNETCORE_HTTP_PORTS=8080
EXPOSE 8080
ENTRYPOINT ["dotnet", "PostQuantum.Jwt.Playground.dll"]
```

---

## 54. `samples/PqJwtPlayground/README.md`

~~~markdown
# PostQuantum.Jwt — Interactive Playground (Blazor Server)

A browser UI for building and validating post-quantum JWTs in real time, built
to *teach* — not just to demo the happy path.

## Features

- **Build**: set sub/iss/aud, lifetime, and custom claims; toggle X-Wing
  encryption and `jti`. Custom claims use a safe name/value editor — values are
  typed automatically (`true`/`false` → bool, integers → long, decimals →
  number, else string), so there's no fragile raw-JSON box and no AOT-unsafe
  reflection path in the hot loop.
- **Validate**: paste any token; fail-closed result with claims and timing.
- **"Why was this rejected?"**: when validation fails, the UI explains the
  failure in plain language (e.g. *"The token was altered after signing"*),
  with the raw validator message tucked behind a "technical detail" disclosure.
  This is the highest-value part of the playground.
- **Size comparison**: the measured PQ token size against representative
  HS256 / ES256 / EdDSA tokens, on a shared scale.
- **"What this protects against"**: a callout covering forgery, algorithm
  downgrade, harvest-now-decrypt-later, and replay — plus an honest pair of
  *not*-protected items (interop, audited assurance).
- **Session keys**: view the ML-DSA-65 and X-Wing public keys; regenerate.

## Why Blazor Server (not WASM)

The ML-DSA / ML-KEM primitives need a real .NET 10 runtime with **OpenSSL 3.5+**
and do not run in the browser. All crypto executes server-side; **private keys
never leave the server**. WASM support for these primitives is still maturing.

## Quick start

```bash
cd samples/PqJwtPlayground
dotnet run
```

Open the printed HTTPS URL (e.g. https://localhost:7100).

## Requirements

- .NET 10 SDK
- OpenSSL 3.5+ (Linux) or recent Windows for the native PQ primitives

## Docker

See the `Dockerfile` (build from the repository root). Uses Azure Linux 3.0 for
a new-enough OpenSSL.

## Hosting note

This is a stateful Blazor Server app. To put it on `systemslibrarian.dev`, host
it on a runtime that provides OpenSSL 3.5+ (a container on a VM, Azure Container
Apps, etc.). It cannot run as a static GitHub Pages site, because the crypto is
server-side by necessity.

## Accessibility

Sections are labelled (`aria-labelledby`), inputs carry `aria-label`s, the
result panel is a live `status` region, and the layout collapses to a single
column on narrow screens.

## Notes

- Demo keys are per-process and in-memory; regenerating invalidates old tokens.
- Preview software, not audited; non-IANA identifiers; non-interoperable tokens.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 55. `samples/PqJwtPlayground/deploy.sh`

```bash
#!/usr/bin/env bash
# One-shot bootstrap: build the PqJwtPlayground image in ACR and deploy it to
# Azure Container Apps with scale-to-zero. Run from the REPOSITORY ROOT
# (the Dockerfile references ../../src, so the build context must be the root).
#
#   bash samples/PqJwtPlayground/deploy.sh
#
# Idempotent enough to re-run; resource creation is skipped if it already exists.
# To God be the glory - 1 Corinthians 10:31.
set -euo pipefail

# ---- variables (edit these) ------------------------------------------------
RESOURCE_GROUP="pqjwt-demos"
LOCATION="eastus"
ENVIRONMENT="pqjwt-env"
ACR_NAME="pqjwtdemoacr"          # must be globally unique
APP_NAME="pqjwt-playground"
IMAGE="pqjwt-playground:latest"
DOCKERFILE="samples/PqJwtPlayground/Dockerfile"
# ---------------------------------------------------------------------------

echo ">> Ensuring resource group, environment, and registry exist..."
az group create --name "$RESOURCE_GROUP" --location "$LOCATION" -o none
az containerapp env create --name "$ENVIRONMENT" --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" -o none 2>/dev/null || true
az acr create --resource-group "$RESOURCE_GROUP" --name "$ACR_NAME" \
  --sku Basic --location "$LOCATION" -o none 2>/dev/null || true

echo ">> Building image in ACR (cloud build, repo root as context)..."
az acr build --registry "$ACR_NAME" --image "$IMAGE" --file "$DOCKERFILE" .

echo ">> Deploying / updating the container app..."
az containerapp up \
  --name "$APP_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --environment "$ENVIRONMENT" \
  --image "${ACR_NAME}.azurecr.io/${IMAGE}" \
  --registry-server "${ACR_NAME}.azurecr.io" \
  --ingress external \
  --target-port 8080

az containerapp update --name "$APP_NAME" --resource-group "$RESOURCE_GROUP" \
  --min-replicas 0 --max-replicas 1 -o none

URL=$(az containerapp show -n "$APP_NAME" -g "$RESOURCE_GROUP" \
  --query "properties.configuration.ingress.fqdn" -o tsv)
echo ">> Live at: https://${URL}"
echo ">> Verify PQ crypto:  az containerapp exec -n $APP_NAME -g $RESOURCE_GROUP --command 'openssl version'"
```

---

## 56. `samples/PqJwtPlayground/DEPLOY.md`

~~~markdown
# Deploying the Playground live (Azure Container Apps)

The playground is a stateful Blazor Server app whose crypto runs server-side and
needs **OpenSSL 3.5+**, so it can't be a static GitHub Pages site. Azure
Container Apps (ACA) is the cheapest, simplest fit: it builds the existing
`Dockerfile` (Azure Linux 3.0 base → new-enough OpenSSL) and gives you a public
HTTPS URL with scale-to-zero so an idle demo costs almost nothing.

> **Build context is the repo root.** This Dockerfile references `../../src`, so
> every command below runs from the **repository root** and points at the
> Dockerfile with `-f`. Don't `cd` into the sample folder.

## One-time setup

```bash
# Install / update the CLI extension and register providers (once per subscription)
az extension add --name containerapp --upgrade
az provider register --namespace Microsoft.App
az provider register --namespace Microsoft.OperationalInsights
az login
```

## Option 1 — one command from local source (fastest)

From the **repository root**:

```bash
az containerapp up \
  --name pqjwt-playground \
  --resource-group pqjwt-demos \
  --location eastus \
  --source . \
  --ingress external

# Tip: `up` looks for a Dockerfile in the source root. Because ours lives at
# samples/PqJwtPlayground/Dockerfile, the simplest reliable path is to build the
# image yourself (Option 2) OR temporarily copy the Dockerfile to the repo root.
```

Because the Dockerfile isn't at the context root, the most predictable route is
to build-and-push explicitly, then deploy the image:

## Option 2 — build with ACR, then deploy the image (most reliable)

From the **repository root**:

```bash
# 1) Create the resource group + a registry (once)
az group create --name pqjwt-demos --location eastus
az acr create --resource-group pqjwt-demos --name pqjwtdemoacr --sku Basic --admin-enabled true

# 2) Build the image in the cloud, using our Dockerfile and the repo root as context
az acr build \
  --registry pqjwtdemoacr \
  --image pqjwt-playground:latest \
  --file samples/PqJwtPlayground/Dockerfile \
  .

# 3) Deploy the image to Container Apps (scale-to-zero keeps idle cost ~$0)
az containerapp up \
  --name pqjwt-playground \
  --resource-group pqjwt-demos \
  --environment pqjwt-env \
  --image pqjwtdemoacr.azurecr.io/pqjwt-playground:latest \
  --registry-server pqjwtdemoacr.azurecr.io \
  --ingress external \
  --target-port 8080

# 4) (optional) allow scale to zero when idle
az containerapp update \
  --name pqjwt-playground \
  --resource-group pqjwt-demos \
  --min-replicas 0 --max-replicas 1
```

The deploy prints the public URL (e.g. `https://pqjwt-playground.<region>.azurecontainerapps.io`).

## Verify OpenSSL inside the running container

If the PQ paths ever fail closed in the cloud, the base image's OpenSSL is the
first suspect:

```bash
az containerapp exec \
  --name pqjwt-playground --resource-group pqjwt-demos \
  --command "openssl version"
# expect: OpenSSL 3.5.x or newer
```

## Continuous deploy from GitHub (optional)

A ready workflow lives at `.github/workflows/deploy-playground.yml` (added at the
repo root). It builds with ACR and updates the container app on every push to
`main` that touches the playground. Set these repository secrets:

- `AZURE_CREDENTIALS` — output of `az ad sp create-for-rbac --sdk-auth ...`
- `ACR_NAME` — e.g. `pqjwtdemoacr`

## Tear down

```bash
az group delete --name pqjwt-demos --yes --no-wait
```

## Cost note

With `--min-replicas 0`, ACA scales the demo to zero when no one is using it, so
you pay only for actual request time plus the small ACR storage. A low-traffic
public demo typically costs a few dollars a month or less.

---

*To God be the glory — 1 Corinthians 10:31.*

## Recommended: managed identity for ACR pull (no admin credentials)

The quickstart above lets Container Apps pull with registry admin credentials.
For anything you keep around, prefer a system-assigned managed identity with the
`AcrPull` role — no stored secrets:

```bash
# 1) Give the app a system-assigned identity
PRINCIPAL_ID=$(az containerapp identity assign \
  --name pqjwt-playground --resource-group pqjwt-demos \
  --system-assigned --query principalId -o tsv)

# 2) Grant it pull rights on the registry
ACR_ID=$(az acr show --name pqjwtdemoacr --query id -o tsv)
az role assignment create \
  --assignee "$PRINCIPAL_ID" --role AcrPull --scope "$ACR_ID"

# 3) Point the app at the registry via that identity (no --registry-password)
az containerapp registry set \
  --name pqjwt-playground --resource-group pqjwt-demos \
  --server pqjwtdemoacr.azurecr.io --identity system
```

## Custom domain

To serve the playground at `pqjwt.systemslibrarian.dev` with a free managed
certificate (Cloudflare DNS), see **[CUSTOM-DOMAIN.md](CUSTOM-DOMAIN.md)**.
~~~

---

## 57. `samples/PqJwtPlayground/CUSTOM-DOMAIN.md`

~~~markdown
# Custom domain: pqjwt.systemslibrarian.dev (Cloudflare DNS + Azure managed cert)

Do this **after** the app is live and working on its default
`*.azurecontainerapps.io` URL (see `DEPLOY.md`). You own `systemslibrarian.dev`
on Cloudflare, so this is DNS + two Azure commands + a free managed certificate.

> **Two things that trip people up — handled below:**
> 1. The TXT validation value is **your app's `customDomainVerificationId`** —
>    not a value you can guess or copy from a guide. We read the real one.
> 2. Bind can fail with `RequireCustomHostnameInEnvironment` if the cert is
>    requested before the hostname is registered and the TXT record is live.
>    The order below (add hostname → create both DNS records → confirm with
>    `dig` → bind) avoids it.

## At a glance

The whole flow, in order — each step is detailed below:

1. **Deploy** the app so its default `*.azurecontainerapps.io` URL works (`DEPLOY.md`).
2. **Read** the two values you'll need: the app's FQDN (CNAME target) and its
   `customDomainVerificationId` (TXT value). — *step 1*
3. **Register** the hostname on the app: `az containerapp hostname add`. — *step 2*
4. **Create** two Cloudflare records: `CNAME pqjwt` → FQDN (grey cloud) and
   `TXT asuid.pqjwt` → verification id (grey cloud). — *step 3*
5. **Confirm** both records resolve with `dig` before going further. — *step 4*
6. **Bind** + provision the managed cert: `az containerapp hostname bind … --validation-method CNAME`. — *step 5*
7. **Verify** the binding and certificate status, then open the URL. — *step 6*

The single most important ordering rule: **don't bind (step 6) until `dig`
confirms both records (step 5).** Binding early is the usual cause of the
`RequireCustomHostnameInEnvironment` failure.

## Variables

```bash
RESOURCE_GROUP="pqjwt-demos"
APP_NAME="pqjwt-playground"
ENVIRONMENT="pqjwt-env"
CUSTOM_DOMAIN="pqjwt.systemslibrarian.dev"
SUBDOMAIN="pqjwt"   # the label only, for Cloudflare record names
```

## 1. Get the two values you'll put in Cloudflare

```bash
# (a) The CNAME target: your app's current default FQDN
az containerapp show -n "$APP_NAME" -g "$RESOURCE_GROUP" \
  --query "properties.configuration.ingress.fqdn" -o tsv
# e.g. pqjwt-playground.politegrass-abc123.eastus.azurecontainerapps.io

# (b) The domain-ownership token for the TXT record (THIS is the real
#     validation value — not a guessed string)
az containerapp show -n "$APP_NAME" -g "$RESOURCE_GROUP" \
  --query "properties.customDomainVerificationId" -o tsv
# e.g. A1B2C3...long-hex-string
```

## 2. Register the hostname on the app (before requesting a cert)

```bash
az containerapp hostname add \
  --hostname "$CUSTOM_DOMAIN" \
  -g "$RESOURCE_GROUP" \
  -n "$APP_NAME"
```

## 3. Create the two Cloudflare DNS records

In the Cloudflare dashboard for `systemslibrarian.dev`:

| Type  | Name                | Content / Target                          | Proxy        |
| ----- | ------------------- | ----------------------------------------- | ------------ |
| CNAME | `pqjwt`             | *(the FQDN from step 1a)*                 | **DNS only** |
| TXT   | `asuid.pqjwt`       | *(the verification id from step 1b)*      | **DNS only** |

**Critical:** the CNAME must be **DNS only (grey cloud)**, not proxied (orange).
Azure provisions the managed certificate by reaching your app directly; with
Cloudflare's proxy on, validation and cert issuance fail. You can turn the proxy
on later only if you front it with Cloudflare's own certificate, which is a
different setup — leave it grey for the managed-cert path.

(Cloudflare appends the zone automatically, so the TXT **Name** is just
`asuid.pqjwt`, which becomes `asuid.pqjwt.systemslibrarian.dev`.)

## 4. Wait for DNS, then confirm both records resolve

```bash
# CNAME should point at the azurecontainerapps.io FQDN
dig +short CNAME pqjwt.systemslibrarian.dev
# TXT should return your customDomainVerificationId
dig +short TXT  asuid.pqjwt.systemslibrarian.dev
```

Give it 1–5 minutes. Don't bind until both return the expected values — binding
early is the usual cause of the `RequireCustomHostnameInEnvironment` error.

## 5. Bind + provision the free managed certificate

```bash
az containerapp hostname bind \
  --hostname "$CUSTOM_DOMAIN" \
  -g "$RESOURCE_GROUP" \
  -n "$APP_NAME" \
  --environment "$ENVIRONMENT" \
  --validation-method CNAME
```

Certificate issuance can take several minutes. If this command errors with
`RequireCustomHostnameInEnvironment`, the hostname/TXT weren't ready — re-check
step 4 and run it again (it's idempotent).

## 6. Verify

```bash
az containerapp hostname list -n "$APP_NAME" -g "$RESOURCE_GROUP" -o table
# look for pqjwt.systemslibrarian.dev with a bound certificate

# managed certs live on the ENVIRONMENT:
az containerapp env certificate list \
  -g "$RESOURCE_GROUP" -n "$ENVIRONMENT" \
  --managed-certificates-only -o table
# status should be Succeeded
```

Then open <https://pqjwt.systemslibrarian.dev> — valid cert, your Playground.

## Troubleshooting

- **`RequireCustomHostnameInEnvironment` on bind** — the most common error. The
  hostname must be added (step 2) and the `asuid.` TXT must be live (step 4)
  before the cert is requested. Wait for `dig` to show the TXT, then re-run bind.
- **Cert stuck / fails** — confirm the CNAME is **grey-cloud** in Cloudflare.
  A proxied record blocks DigiCert from validating.
- **TXT name** — it is `asuid.pqjwt` in Cloudflare (zone auto-appended), giving
  `asuid.pqjwt.systemslibrarian.dev`. Wrong prefix = failed validation.
- **Wrong TXT value** — it must be the app's `customDomainVerificationId`
  (step 1b), nothing else.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 58. `.github/workflows/deploy-playground.yml`

```yaml
# Build the PqJwtPlayground image with ACR and deploy it to Azure Container Apps
# on every push to main that touches the playground or the library source.
#
# Place this file at: .github/workflows/deploy-playground.yml  (repo root)
#
# Required repository secrets:
#   AZURE_CREDENTIALS  - JSON from: az ad sp create-for-rbac --sdk-auth \
#                          --role contributor --scopes /subscriptions/<SUB>/resourceGroups/pqjwt-demos
#   ACR_NAME           - e.g. pqjwtdemoacr
#
# Assumes the resource group (pqjwt-demos), ACR, and container app
# (pqjwt-playground) already exist - create them once via samples/PqJwtPlayground/DEPLOY.md.
#
# To God be the glory - 1 Corinthians 10:31.

name: Deploy Playground

on:
  push:
    branches: [main]
    paths:
      - "samples/PqJwtPlayground/**"
      - "src/PostQuantum.Jwt/**"
      - "samples/Shared/**"
      - ".github/workflows/deploy-playground.yml"
  workflow_dispatch:

env:
  RESOURCE_GROUP: pqjwt-demos
  APP_NAME: pqjwt-playground
  IMAGE_NAME: pqjwt-playground

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Azure login
        uses: azure/login@v2
        with:
          creds: ${{ secrets.AZURE_CREDENTIALS }}

      - name: Build image in ACR (repo root as context)
        run: |
          TAG="${GITHUB_SHA::8}"
          az acr build \
            --registry "${{ secrets.ACR_NAME }}" \
            --image "${IMAGE_NAME}:${TAG}" \
            --image "${IMAGE_NAME}:latest" \
            --file samples/PqJwtPlayground/Dockerfile \
            .

      - name: Update Container App to new image
        run: |
          TAG="${GITHUB_SHA::8}"
          az containerapp update \
            --name "${APP_NAME}" \
            --resource-group "${RESOURCE_GROUP}" \
            --image "${{ secrets.ACR_NAME }}.azurecr.io/${IMAGE_NAME}:${TAG}"
```

---

## 59. `docs/img/README.md`

```markdown
# Screenshots / GIFs for the README

Place captured assets here as:

- `docs/img/playground-why-rejected.png` — the Playground with a rejected token,
  showing the "Why was this rejected?" panel expanded. Validate a tampered token
  (build one, click "Send to validator", edit a character, validate) to trigger
  "signature verification failed".
- `docs/img/console-attack-mode.gif` — ConsoleDemo running option 7 (Attack
  Mode), scrolling through the six REJECTED results.

## Capturing tips

- **GIF of the console**: `asciinema` + `agg`, or just a screen recorder cropped
  to the terminal. Keep it under ~8s and ~720px wide so it loads fast on GitHub.
- **Playground screenshot**: dark theme already; capture at ~1280px wide and
  downscale to 720px for crispness. PNG, not JPG (sharp text).
- Keep total asset size modest — GitHub READMEs feel slow when images are heavy.
```

---

## 60. `library-patches/README-METRICS-PATCH.md`

~~~markdown
# Library patch: validation metrics in `PqJwtValidator` (Gemini #2)

This is a **proposed change to library source** (`src/PostQuantum.Jwt/PqJwtValidator.cs`),
not a sample. Apply it, build, and run the existing 79 tests before shipping.

## Files here

- `PqJwtValidator.original.cs` — the file you gave me, unchanged (for diffing).
- `PqJwtValidator.cs` — the patched version. Diff them, or replace your source
  after review.

## What it does

Adds OpenTelemetry-compatible metrics via `System.Diagnostics.Metrics` (no new
package dependency — consumers opt in with their own OTel/meter listener):

- Meter name: `PostQuantum.Jwt`
- Counter: `pqjwt.validations`, tagged:
  - `outcome` = `success` | `failure`
  - `reason` (failures only) = `signature_mismatch`, `expired`, `replay_detected`,
    `audience_mismatch`, `algorithm_not_accepted`, `unknown_kid`,
    `decryption_failed`, … (a small, fixed, bounded-cardinality vocabulary)

## Why it's safe

- **Validation logic is untouched.** The fail-closed control flow is byte-for-byte
  identical; instrumentation sits only at the single `Validate()` boundary that
  every path already funnels through. Success is counted only after all checks
  pass; failures are counted in the two existing catch blocks.
- **No sensitive data.** The `reason` tag is derived from a fixed mapping of the
  library's own exception messages to coarse codes. No token, claim value, key
  material, `jti`, issuer, or audience value is ever emitted — only the category.
- **Bounded cardinality.** `reason` is a closed set, so it won't explode a
  metrics backend.

## Two things for your review

1. **Message-coupling.** `Categorize(message)` matches on the validator's own
   message strings. If you change a throw message, update the matching arm.
   (Cleaner long-term: emit a structured reason enum at each throw site and tag
   from that — but that touches ~15 sites; this single-boundary approach was the
   minimal, low-risk change you asked for.)
2. **Meter version string** is hardcoded `"1.0.0"`. Wire it to your assembly
   version if you prefer.

## Consumer wiring (OpenTelemetry)

```csharp
builder.Services.AddOpenTelemetry().WithMetrics(m => m
    .AddMeter("PostQuantum.Jwt")        // <-- the meter name above
    .AddPrometheusExporter());          // or OTLP, console, etc.
```

A dashboard can then alert on `pqjwt.validations{outcome="failure",reason="signature_mismatch"}`
spiking — a live forgery signal — without logging anything sensitive.

---

*To God be the glory — 1 Corinthians 10:31.*
~~~

---

## 61. `library-patches/PqJwtValidator.cs`

```csharp
using System.Diagnostics.Metrics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using PostQuantum.Jwt.Cryptography;
using PostQuantum.Jwt.Internal;

namespace PostQuantum.Jwt;

/// <summary>
/// Validates post-quantum hybrid JWTs. Fail-closed by design: any problem with
/// structure, decryption, signature, or claims raises
/// <see cref="PqJwtValidationException"/> rather than returning a degraded result.
/// </summary>
/// <remarks>Instances are immutable and safe to reuse across threads.</remarks>
public sealed class PqJwtValidator
{
    private const int SignedPartCount = 3;
    private const int EncryptedPartCount = 5;

    // -- Observability -------------------------------------------------------
    // Emitted via System.Diagnostics.Metrics so consumers can wire OpenTelemetry
    // (or any IMeterListener) without the library taking a dependency on it.
    // We tag failures with a coarse `reason` derived ONLY from the exception type
    // and a small fixed set of categories — never the token, claims, or any key
    // material. The meter name is stable API; treat it as part of the contract.
    private static readonly Meter Meter = new("PostQuantum.Jwt", "1.0.0");

    private static readonly Counter<long> ValidationsTotal =
        Meter.CreateCounter<long>(
            "pqjwt.validations",
            unit: "{validation}",
            description: "Total token validations, tagged outcome=success|failure (and reason on failure).");

    private readonly PqJwtValidationParameters _parameters;
    private readonly TimeProvider _timeProvider;

    /// <summary>Creates a validator.</summary>
    /// <param name="parameters">Validation configuration.</param>
    /// <param name="timeProvider">Clock used for lifetime checks; defaults to <see cref="TimeProvider.System"/>.</param>
    /// <exception cref="ArgumentNullException"><paramref name="parameters"/> is <see langword="null"/>.</exception>
    /// <exception cref="ArgumentException">
    /// Neither <see cref="PqJwtValidationParameters.SignatureVerificationKey"/> nor
    /// <see cref="PqJwtValidationParameters.SignatureKeyResolver"/> is configured,
    /// or <see cref="PqJwtValidationParameters.RequireReplayProtection"/> is
    /// <see langword="true"/> while <see cref="PqJwtValidationParameters.ReplayCache"/>
    /// is <see langword="null"/>. A security validator without a way to obtain a
    /// verification key — or one whose replay-protection requirement is asserted
    /// but unwired — is misconfigured by definition; rejecting that at
    /// construction time means the misconfiguration surfaces before the first
    /// token arrives.
    /// </exception>
    /// <exception cref="ArgumentOutOfRangeException">
    /// <see cref="PqJwtValidationParameters.ClockSkew"/> is negative — negative skew
    /// is rejected up front so time-validation behaviour is never harder to reason
    /// about than the documented contract.
    /// </exception>
    public PqJwtValidator(PqJwtValidationParameters parameters, TimeProvider? timeProvider = null)
    {
        ArgumentNullException.ThrowIfNull(parameters);
        if (parameters.SignatureVerificationKey is null && parameters.SignatureKeyResolver is null)
        {
            throw new ArgumentException(
                "PqJwtValidationParameters requires SignatureVerificationKey or SignatureKeyResolver.",
                nameof(parameters));
        }

        ArgumentOutOfRangeException.ThrowIfLessThan(parameters.ClockSkew, TimeSpan.Zero);

        if (parameters.RequireReplayProtection && parameters.ReplayCache is null)
        {
            throw new ArgumentException(
                "PqJwtValidationParameters.RequireReplayProtection is set, but no ReplayCache was supplied. " +
                "Either provide a ReplayCache or clear RequireReplayProtection.",
                nameof(parameters));
        }

        _parameters = parameters;
        _timeProvider = timeProvider ?? TimeProvider.System;
    }

    /// <summary>Validates a compact token and returns its claims.</summary>
    /// <param name="token">The compact-serialized token.</param>
    /// <returns>The validated result.</returns>
    /// <exception cref="PqJwtValidationException">The token failed any validation check, including those caused by malformed Base64, malformed JSON, or malformed key material in the token's payload.</exception>
    /// <exception cref="PqJwtException">The validator is misconfigured for this token (e.g. an encrypted token arrived but no decryption key was supplied).</exception>
    public PqJwtValidationResult Validate(string token)
    {
        ArgumentException.ThrowIfNullOrEmpty(token);

        try
        {
            var parts = token.Split('.');
            var result = parts.Length switch
            {
                SignedPartCount => ValidateSigned(parts, wasEncrypted: false),
                EncryptedPartCount => ValidateEncrypted(parts),
                _ => throw new PqJwtValidationException(
                    $"Malformed token: expected {SignedPartCount} or {EncryptedPartCount} segments, got {parts.Length}."),
            };

            // Success is recorded only after every check has passed (fail-closed:
            // we never reach here on a rejected token).
            ValidationsTotal.Add(1, new KeyValuePair<string, object?>("outcome", "success"));
            return result;
        }
        catch (PqJwtException ex)
        {
            // PqJwtException and its subclass PqJwtValidationException
            // are the documented fail-closed types — pass through unchanged,
            // but record the failure with a coarse, non-sensitive reason first.
            RecordFailure(ex);
            throw;
        }
        catch (Exception ex) when (ex is FormatException or CryptographicException or JsonException)
        {
            RecordFailure(ex);
            // Known leak families from deeper layers: Base64 parsing
            // (FormatException), JSON parsing (System.Text.Json.JsonException),
            // and primitive crypto material checks (CryptographicException).
            // Adversarial inputs can drive any of these out of the validator;
            // the fail-closed contract says "every validation failure becomes
            // PqJwtValidationException" — so we wrap them with the original
            // as inner exception for diagnostics.
            throw new PqJwtValidationException(
                "Token failed validation due to malformed structure or invalid cryptographic material.",
                ex);
        }
    }

    private PqJwtValidationResult ValidateEncrypted(string[] parts)
    {
        if (_parameters.DecryptionKey is null)
        {
            throw new PqJwtException(
                "Token is encrypted but PqJwtValidationParameters.DecryptionKey was not supplied.");
        }

        var header = JoseHeader.Parse(Base64Url.DecodeToUtf8(parts[0]));
        if (!string.Equals(header.Algorithm, PqJwtAlgorithms.XWing, StringComparison.Ordinal))
        {
            throw new PqJwtValidationException(
                $"Unsupported key-agreement algorithm '{header.Algorithm}'; expected '{PqJwtAlgorithms.XWing}'.");
        }

        if (!string.Equals(header.Encryption, PqJwtAlgorithms.Aes256Gcm, StringComparison.Ordinal))
        {
            throw new PqJwtValidationException(
                $"Unsupported content-encryption algorithm '{header.Encryption}'; expected '{PqJwtAlgorithms.Aes256Gcm}'.");
        }

        // The builder always emits cty=JWT for encrypted (nested) tokens; require it on
        // the validator side too so a producer can't ship an encrypted blob that
        // *happens* to decrypt to something signed-JWT-shaped but was labelled as some
        // other content type.
        if (!string.Equals(header.ContentType, PqJwtAlgorithms.TokenType, StringComparison.Ordinal))
        {
            throw new PqJwtValidationException(
                $"Encrypted token must declare 'cty' = '{PqJwtAlgorithms.TokenType}'; got '{header.ContentType ?? "<missing>"}'.");
        }

        var innerJws = Decrypt(parts, header, _parameters.DecryptionKey);

        // The decrypted content is itself a signed JWT; validate it fully.
        var innerParts = innerJws.Split('.');
        if (innerParts.Length != SignedPartCount)
        {
            throw new PqJwtValidationException("Decrypted content is not a signed JWT.");
        }

        return ValidateSigned(innerParts, wasEncrypted: true);
    }

    private static string Decrypt(string[] parts, JoseHeader header, XWingPrivateKey decryptionKey)
    {
        byte[] sharedSecret;
        try
        {
            sharedSecret = XWing.Decapsulate(decryptionKey, Base64Url.Decode(parts[1]));
        }
        catch (Exception ex) when (ex is FormatException or PqJwtException)
        {
            throw new PqJwtValidationException("Token key-agreement material is malformed.", ex);
        }

        byte[]? plaintext = null;
        try
        {
            var nonce = Base64Url.Decode(parts[2]);
            var ciphertext = Base64Url.Decode(parts[3]);
            var tag = Base64Url.Decode(parts[4]);
            var aad = Encoding.ASCII.GetBytes(parts[0]);
            plaintext = new byte[ciphertext.Length];

            using (var gcm = new AesGcm(sharedSecret, tag.Length))
            {
                gcm.Decrypt(nonce, ciphertext, tag, plaintext, aad);
            }

            // The decoded string still lives in managed memory beyond our control,
            // but zeroing the intermediate byte buffer shortens one plaintext
            // copy's lifetime to a few microseconds — consistent with the rest of
            // the project's key-material hygiene discipline.
            return Encoding.UTF8.GetString(plaintext);
        }
        catch (Exception ex) when (ex is CryptographicException or FormatException or ArgumentException)
        {
            // A bad tag, tampered ciphertext, or wrong key all land here. Fail closed.
            throw new PqJwtValidationException("Token decryption failed (authentication tag mismatch).", ex);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(sharedSecret);
            if (plaintext is not null)
            {
                CryptographicOperations.ZeroMemory(plaintext);
            }
        }
    }

    private PqJwtValidationResult ValidateSigned(string[] parts, bool wasEncrypted)
    {
        var header = JoseHeader.Parse(Base64Url.DecodeToUtf8(parts[0]));
        if (!string.Equals(header.Algorithm, PqJwtAlgorithms.MLDsa65, StringComparison.Ordinal))
        {
            throw new PqJwtValidationException(
                $"Unsupported or disallowed signature algorithm '{header.Algorithm}'; expected '{PqJwtAlgorithms.MLDsa65}'.");
        }

        var verificationKey = ResolveVerificationKey(header.KeyId);
        VerifySignature(parts, verificationKey);

        var claims = ParseClaims(parts[1]);
        ValidateClaims(claims);
        EnforceReplayPolicy(claims);
        return new PqJwtValidationResult(claims, wasEncrypted);
    }

    private MLDsa ResolveVerificationKey(string? keyId)
    {
        // The constructor already guarantees at least one of these is set.
        if (_parameters.SignatureKeyResolver is { } resolver)
        {
            return resolver(keyId)
                ?? throw new PqJwtValidationException(
                    $"No verification key was resolved for kid '{keyId}'.");
        }

        return _parameters.SignatureVerificationKey!;
    }

    private void EnforceReplayPolicy(Dictionary<string, JsonElement> claims)
    {
        if (_parameters.ReplayCache is not { } cache)
        {
            return;
        }

        var jwtId = claims.TryGetValue("jti", out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

        if (string.IsNullOrEmpty(jwtId))
        {
            throw new PqJwtValidationException("Replay protection is enabled but the token has no 'jti' claim.");
        }

        var expiresAt = TryGetUnixTime(claims, "exp", out var exp) ? exp : DateTimeOffset.MaxValue;
        if (!cache.TryRegister(jwtId, expiresAt))
        {
            throw new PqJwtValidationException($"Token replay detected for jti '{jwtId}'.");
        }
    }

    private static void VerifySignature(string[] parts, MLDsa verificationKey)
    {
        byte[] signature;
        try
        {
            signature = Base64Url.Decode(parts[2]);
        }
        catch (FormatException ex)
        {
            throw new PqJwtValidationException("Token signature is not valid base64url.", ex);
        }

        var signingInput = Encoding.ASCII.GetBytes($"{parts[0]}.{parts[1]}");
        if (!verificationKey.VerifyData(signingInput, signature))
        {
            throw new PqJwtValidationException("Token signature verification failed.");
        }
    }

    private static Dictionary<string, JsonElement> ParseClaims(string encodedPayload)
    {
        JsonDocument document;
        try
        {
            document = JsonDocument.Parse(Base64Url.Decode(encodedPayload));
        }
        catch (Exception ex) when (ex is FormatException or JsonException)
        {
            throw new PqJwtValidationException("Token payload is not valid JSON.", ex);
        }

        using (document)
        {
            if (document.RootElement.ValueKind != JsonValueKind.Object)
            {
                throw new PqJwtValidationException("Token payload is not a JSON object.");
            }

            var claims = new Dictionary<string, JsonElement>(StringComparer.Ordinal);
            foreach (var property in document.RootElement.EnumerateObject())
            {
                claims[property.Name] = property.Value.Clone();
            }

            return claims;
        }
    }

    private void ValidateClaims(Dictionary<string, JsonElement> claims)
    {
        ValidateLifetime(claims);
        ValidateIssuer(claims);
        ValidateAudience(claims);
    }

    private void ValidateLifetime(Dictionary<string, JsonElement> claims)
    {
        if (!_parameters.ValidateLifetime)
        {
            return;
        }

        var now = _timeProvider.GetUtcNow();
        var skew = _parameters.ClockSkew;

        if (TryGetUnixTime(claims, "exp", out var exp))
        {
            if (now > exp + skew)
            {
                throw new PqJwtValidationException($"Token expired at {exp:O}.");
            }
        }
        else if (_parameters.RequireExpiration)
        {
            throw new PqJwtValidationException("Token is missing the required 'exp' claim.");
        }

        if (TryGetUnixTime(claims, "nbf", out var nbf) && now < nbf - skew)
        {
            throw new PqJwtValidationException($"Token is not valid before {nbf:O}.");
        }
    }

    private void ValidateIssuer(Dictionary<string, JsonElement> claims)
    {
        if (_parameters.ValidIssuer is null)
        {
            return;
        }

        var issuer = claims.TryGetValue("iss", out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

        if (!string.Equals(issuer, _parameters.ValidIssuer, StringComparison.Ordinal))
        {
            throw new PqJwtValidationException(
                $"Token issuer '{issuer}' does not match the expected issuer.");
        }
    }

    private void ValidateAudience(Dictionary<string, JsonElement> claims)
    {
        if (_parameters.ValidAudience is null)
        {
            return;
        }

        if (!claims.TryGetValue("aud", out var aud) || !AudienceContains(aud, _parameters.ValidAudience))
        {
            throw new PqJwtValidationException("Token audience does not include the expected audience.");
        }
    }

    private static bool AudienceContains(JsonElement audience, string expected)
    {
        switch (audience.ValueKind)
        {
            case JsonValueKind.String:
                return string.Equals(audience.GetString(), expected, StringComparison.Ordinal);
            case JsonValueKind.Array:
                foreach (var item in audience.EnumerateArray())
                {
                    if (item.ValueKind == JsonValueKind.String &&
                        string.Equals(item.GetString(), expected, StringComparison.Ordinal))
                    {
                        return true;
                    }
                }

                return false;
            default:
                return false;
        }
    }

    private static bool TryGetUnixTime(
        Dictionary<string, JsonElement> claims, string name, out DateTimeOffset value)
    {
        if (claims.TryGetValue(name, out var element) &&
            element.ValueKind == JsonValueKind.Number &&
            element.TryGetInt64(out var seconds))
        {
            value = DateTimeOffset.FromUnixTimeSeconds(seconds);
            return true;
        }

        value = default;
        return false;
    }

    // Maps a failure to a coarse, non-sensitive `reason` tag derived from the
    // exception. Deliberately a small fixed vocabulary so the metric has bounded
    // cardinality and never leaks token contents or key material.
    private static void RecordFailure(Exception ex)
    {
        string reason = ex switch
        {
            PqJwtValidationException v => Categorize(v.Message),
            FormatException => "malformed_encoding",
            JsonException => "malformed_json",
            CryptographicException => "crypto_material",
            _ => "other",
        };

        ValidationsTotal.Add(
            1,
            new KeyValuePair<string, object?>("outcome", "failure"),
            new KeyValuePair<string, object?>("reason", reason));
    }

    // Bucket a validation message into a stable reason code. Matches on the
    // library's own message text (the only producer of these messages), so the
    // mapping stays in sync with the throw sites above.
    private static string Categorize(string message)
    {
        if (message.Contains("signature verification failed", StringComparison.OrdinalIgnoreCase)) return "signature_mismatch";
        if (message.Contains("not valid base64url", StringComparison.OrdinalIgnoreCase)) return "malformed_signature";
        if (message.Contains("expired at", StringComparison.OrdinalIgnoreCase)) return "expired";
        if (message.Contains("not valid before", StringComparison.OrdinalIgnoreCase)) return "not_yet_valid";
        if (message.Contains("missing the required 'exp'", StringComparison.OrdinalIgnoreCase)) return "missing_exp";
        if (message.Contains("replay detected", StringComparison.OrdinalIgnoreCase)) return "replay_detected";
        if (message.Contains("no 'jti'", StringComparison.OrdinalIgnoreCase)) return "missing_jti";
        if (message.Contains("issuer", StringComparison.OrdinalIgnoreCase)) return "issuer_mismatch";
        if (message.Contains("audience", StringComparison.OrdinalIgnoreCase)) return "audience_mismatch";
        if (message.Contains("Unsupported", StringComparison.OrdinalIgnoreCase)) return "algorithm_not_accepted";
        if (message.Contains("No verification key was resolved", StringComparison.OrdinalIgnoreCase)) return "unknown_kid";
        if (message.Contains("decryption failed", StringComparison.OrdinalIgnoreCase)) return "decryption_failed";
        if (message.Contains("key-agreement material", StringComparison.OrdinalIgnoreCase)) return "malformed_keyagreement";
        if (message.Contains("not a signed JWT", StringComparison.OrdinalIgnoreCase)) return "inner_not_signed";
        if (message.Contains("not valid JSON", StringComparison.OrdinalIgnoreCase) ||
            message.Contains("not a JSON object", StringComparison.OrdinalIgnoreCase)) return "malformed_payload";
        if (message.Contains("Malformed token", StringComparison.OrdinalIgnoreCase) ||
            message.Contains("malformed structure", StringComparison.OrdinalIgnoreCase)) return "wrong_segment_count";
        return "other";
    }
}
```

---

## 62. `library-patches/PostQuantum.Jwt.Analyzers/PqJwtUsageAnalyzer.cs`

```csharp
// PostQuantum.Jwt.Analyzers
//
// Two Roslyn diagnostics that push the LLM-USAGE.md rules down to the compiler,
// so human developers get IDE warnings before bad patterns compile:
//
//   PQJWT001  catching Exception / PqJwtException (the base) around a call to
//             PqJwtValidator.Validate(...), instead of the specific
//             PqJwtValidationException. The fail-closed contract throws the
//             specific type; catching the base swallows misconfiguration
//             (PqJwtException) as if it were a validation failure.
//
//   PQJWT002  constructing PqJwtValidationParameters without assigning either
//             SignatureVerificationKey or SignatureKeyResolver. The validator's
//             constructor throws on this at runtime; PQJWT002 surfaces it at
//             author time.
//
// STATUS: this is a working starting point, NOT a battle-tested analyzer. It uses
// simple syntax/symbol checks that will catch the common shapes but can miss
// indirection (a parameters object built in a helper, a catch in a different
// method, etc.). Real-world hardening + a test project (Microsoft.CodeAnalysis.
// Testing) are required before shipping it in the nupkg. See README.
//
// To God be the glory - 1 Corinthians 10:31.

using System.Collections.Immutable;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace PostQuantum.Jwt.Analyzers;

[DiagnosticAnalyzer(LanguageNames.CSharp)]
public sealed class PqJwtUsageAnalyzer : DiagnosticAnalyzer
{
    public static readonly DiagnosticDescriptor CatchTooBroad = new(
        id: "PQJWT001",
        title: "Catch PqJwtValidationException, not a broader type",
        messageFormat: "Catch 'PqJwtValidationException' here; catching '{0}' also swallows misconfiguration (PqJwtException) and generic errors",
        category: "PostQuantum.Jwt.Usage",
        defaultSeverity: DiagnosticSeverity.Warning,
        isEnabledByDefault: true,
        description: "PqJwtValidator.Validate is fail-closed and throws PqJwtValidationException on a rejected token. " +
                     "Catching System.Exception or the PqJwtException base treats misconfiguration like a normal rejection.");

    public static readonly DiagnosticDescriptor MissingKeySource = new(
        id: "PQJWT002",
        title: "PqJwtValidationParameters needs a key source",
        messageFormat: "Set SignatureVerificationKey or SignatureKeyResolver; without one the PqJwtValidator constructor throws at runtime",
        category: "PostQuantum.Jwt.Usage",
        defaultSeverity: DiagnosticSeverity.Warning,
        isEnabledByDefault: true,
        description: "A validator with no way to obtain a verification key is misconfigured by definition.");

    public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics =>
        ImmutableArray.Create(CatchTooBroad, MissingKeySource);

    public override void Initialize(AnalysisContext context)
    {
        context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
        context.EnableConcurrentExecution();

        context.RegisterSyntaxNodeAction(AnalyzeCatch, SyntaxKind.TryStatement);
        context.RegisterSyntaxNodeAction(AnalyzeObjectCreation, SyntaxKind.ObjectCreationExpression);
    }

    // PQJWT001 — a try that calls Validate(...) but catches a too-broad type.
    private static void AnalyzeCatch(SyntaxNodeAnalysisContext context)
    {
        var tryStmt = (TryStatementSyntax)context.Node;

        // Does the try block invoke something named Validate? (cheap syntactic gate)
        bool callsValidate = tryStmt.Block.DescendantNodes()
            .OfType<InvocationExpressionSyntax>()
            .Any(inv => inv.Expression is MemberAccessExpressionSyntax m &&
                        m.Name.Identifier.ValueText == "Validate");
        if (!callsValidate)
            return;

        foreach (var c in tryStmt.Catches)
        {
            // A catch with no declared type catches everything — too broad.
            if (c.Declaration is null)
            {
                context.ReportDiagnostic(Diagnostic.Create(CatchTooBroad, c.GetLocation(), "everything"));
                continue;
            }

            var caught = context.SemanticModel.GetTypeInfo(c.Declaration.Type, context.CancellationToken).Type;
            if (caught is null)
                continue;

            string name = caught.Name;
            // Flag Exception and the PqJwtException base, but NOT the correct specific type.
            if (name is "Exception" or "SystemException" or "PqJwtException")
            {
                context.ReportDiagnostic(Diagnostic.Create(CatchTooBroad, c.Declaration.Type.GetLocation(), caught.ToDisplayString()));
            }
        }
    }

    // PQJWT002 — new PqJwtValidationParameters { ... } with neither key member set.
    private static void AnalyzeObjectCreation(SyntaxNodeAnalysisContext context)
    {
        var creation = (ObjectCreationExpressionSyntax)context.Node;

        var type = context.SemanticModel.GetTypeInfo(creation, context.CancellationToken).Type;
        if (type?.Name != "PqJwtValidationParameters")
            return;

        // Only analyze the object-initializer form; a parameters object populated
        // elsewhere is beyond this simple check (documented limitation).
        if (creation.Initializer is null)
            return;

        bool hasKeySource = creation.Initializer.Expressions
            .OfType<AssignmentExpressionSyntax>()
            .Select(a => (a.Left as IdentifierNameSyntax)?.Identifier.ValueText)
            .Any(n => n is "SignatureVerificationKey" or "SignatureKeyResolver");

        if (!hasKeySource)
        {
            context.ReportDiagnostic(Diagnostic.Create(MissingKeySource, creation.GetLocation()));
        }
    }
}
```

---

## 63. `library-patches/PostQuantum.Jwt.Analyzers/PostQuantum.Jwt.Analyzers.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <!-- Analyzers target netstandard2.0 so they load in all IDE/build hosts. -->
    <TargetFramework>netstandard2.0</TargetFramework>
    <Nullable>enable</Nullable>
    <LangVersion>latest</LangVersion>
    <EnforceExtendedAnalyzerRules>true</EnforceExtendedAnalyzerRules>
    <IsPackable>true</IsPackable>
    <IncludeBuildOutput>false</IncludeBuildOutput>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.CodeAnalysis.CSharp" Version="4.11.0" PrivateAssets="all" />
    <PackageReference Include="Microsoft.CodeAnalysis.Analyzers" Version="3.11.0" PrivateAssets="all" />
  </ItemGroup>

  <!-- To ship INSIDE the PostQuantum.Jwt nupkg, pack this assembly into the
       analyzers/dotnet/cs path of that package (or distribute as its own
       PostQuantum.Jwt.Analyzers package and have the main package depend on it). -->
  <ItemGroup>
    <None Include="$(OutputPath)\PostQuantum.Jwt.Analyzers.dll"
          Pack="true" PackagePath="analyzers/dotnet/cs" Visible="false" />
  </ItemGroup>

</Project>
```

---

## 64. `library-patches/PostQuantum.Jwt.Analyzers/README.md`

```markdown
# PostQuantum.Jwt.Analyzers (Gemini #3)

Two compile-time diagnostics that enforce the `LLM-USAGE.md` rules for human
developers, in their IDE, before bad patterns compile.

| ID | Flags | Why |
| -- | ----- | --- |
| **PQJWT001** | A `try` that calls `.Validate(...)` but catches `Exception`, `SystemException`, the `PqJwtException` base, or an untyped catch | The fail-closed contract throws the specific `PqJwtValidationException`. Catching broader also swallows *misconfiguration* (`PqJwtException`) as if it were a normal rejection. |
| **PQJWT002** | `new PqJwtValidationParameters { … }` with neither `SignatureVerificationKey` nor `SignatureKeyResolver` set | The validator constructor throws on this at runtime; catch it at author time. |

## Honest status

This is a **working starting point, not a hardened analyzer.** It uses
straightforward syntax + symbol checks that catch the common shapes. Known gaps:

- PQJWT001 keys off a method named `Validate` and a `try` in the same method; a
  catch in a different method, or a wrapper, won't be seen.
- PQJWT002 only inspects the object-initializer form; a parameters object
  populated in a helper or via `with` isn't analyzed.
- No code fixes yet (could add `CodeFixProvider`s to auto-narrow the catch).

**Before shipping it in the nupkg:** add a test project using
`Microsoft.CodeAnalysis.CSharp.Analyzer.Testing` with positive/negative cases for
both rules, and decide packaging (bundle into `PostQuantum.Jwt` under
`analyzers/dotnet/cs`, or ship as a separate `PostQuantum.Jwt.Analyzers` package
the main one depends on — the csproj is set up for either).

## Packaging note

The `.csproj` packs the analyzer DLL into `analyzers/dotnet/cs`, targets
`netstandard2.0` (required for analyzer load), and marks CodeAnalysis refs
`PrivateAssets="all"` so they don't leak as dependencies.

---

*To God be the glory — 1 Corinthians 10:31.*
```

---

*End of bundle (v3.2). To God be the glory — 1 Corinthians 10:31.*
