# PostQuantum.Jwt.Analyzers (Gemini #3)

Two compile-time diagnostics that enforce the `LLM-USAGE.md` rules for human
developers, in their IDE, before bad patterns compile.

| ID | Flags | Why |
| -- | ----- | --- |
| **PQJWT001** | A `try` that calls `.Validate(...)` but catches `Exception`, `SystemException`, the `PqJwtException` base, or an untyped catch | The fail-closed contract throws the specific `PqJwtValidationException`. Catching broader also swallows *misconfiguration* (`PqJwtException`) as if it were a normal rejection. |
| **PQJWT002** | `new PqJwtValidationParameters { … }` with neither `SignatureVerificationKey` nor `SignatureKeyResolver` set | The validator constructor throws on this at runtime; catch it at author time. |

## Honest status

This is a **working starting point, not a hardened analyzer.** It uses
straightforward syntax + symbol checks that catch the common shapes. Known gaps:

- PQJWT001 keys off a method named `Validate` and a `try` in the same method; a
  catch in a different method, or a wrapper, won't be seen.
- PQJWT002 only inspects the object-initializer form; a parameters object
  populated in a helper or via `with` isn't analyzed.
- No code fixes yet (could add `CodeFixProvider`s to auto-narrow the catch).

**Before shipping it in the nupkg:** add a test project using
`Microsoft.CodeAnalysis.CSharp.Analyzer.Testing` with positive/negative cases for
both rules, and decide packaging (bundle into `PostQuantum.Jwt` under
`analyzers/dotnet/cs`, or ship as a separate `PostQuantum.Jwt.Analyzers` package
the main one depends on — the csproj is set up for either).

## Packaging note

The `.csproj` packs the analyzer DLL into `analyzers/dotnet/cs`, targets
`netstandard2.0` (required for analyzer load), and marks CodeAnalysis refs
`PrivateAssets="all"` so they don't leak as dependencies.

---

*To God be the glory — 1 Corinthians 10:31.*
