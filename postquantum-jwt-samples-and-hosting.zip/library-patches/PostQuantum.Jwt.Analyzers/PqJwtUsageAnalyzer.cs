// PostQuantum.Jwt.Analyzers
//
// Two Roslyn diagnostics that push the LLM-USAGE.md rules down to the compiler,
// so human developers get IDE warnings before bad patterns compile:
//
//   PQJWT001  catching Exception / PqJwtException (the base) around a call to
//             PqJwtValidator.Validate(...), instead of the specific
//             PqJwtValidationException. The fail-closed contract throws the
//             specific type; catching the base swallows misconfiguration
//             (PqJwtException) as if it were a validation failure.
//
//   PQJWT002  constructing PqJwtValidationParameters without assigning either
//             SignatureVerificationKey or SignatureKeyResolver. The validator's
//             constructor throws on this at runtime; PQJWT002 surfaces it at
//             author time.
//
// STATUS: this is a working starting point, NOT a battle-tested analyzer. It uses
// simple syntax/symbol checks that will catch the common shapes but can miss
// indirection (a parameters object built in a helper, a catch in a different
// method, etc.). Real-world hardening + a test project (Microsoft.CodeAnalysis.
// Testing) are required before shipping it in the nupkg. See README.
//
// To God be the glory - 1 Corinthians 10:31.

using System.Collections.Immutable;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace PostQuantum.Jwt.Analyzers;

[DiagnosticAnalyzer(LanguageNames.CSharp)]
public sealed class PqJwtUsageAnalyzer : DiagnosticAnalyzer
{
    public static readonly DiagnosticDescriptor CatchTooBroad = new(
        id: "PQJWT001",
        title: "Catch PqJwtValidationException, not a broader type",
        messageFormat: "Catch 'PqJwtValidationException' here; catching '{0}' also swallows misconfiguration (PqJwtException) and generic errors",
        category: "PostQuantum.Jwt.Usage",
        defaultSeverity: DiagnosticSeverity.Warning,
        isEnabledByDefault: true,
        description: "PqJwtValidator.Validate is fail-closed and throws PqJwtValidationException on a rejected token. " +
                     "Catching System.Exception or the PqJwtException base treats misconfiguration like a normal rejection.");

    public static readonly DiagnosticDescriptor MissingKeySource = new(
        id: "PQJWT002",
        title: "PqJwtValidationParameters needs a key source",
        messageFormat: "Set SignatureVerificationKey or SignatureKeyResolver; without one the PqJwtValidator constructor throws at runtime",
        category: "PostQuantum.Jwt.Usage",
        defaultSeverity: DiagnosticSeverity.Warning,
        isEnabledByDefault: true,
        description: "A validator with no way to obtain a verification key is misconfigured by definition.");

    public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics =>
        ImmutableArray.Create(CatchTooBroad, MissingKeySource);

    public override void Initialize(AnalysisContext context)
    {
        context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
        context.EnableConcurrentExecution();

        context.RegisterSyntaxNodeAction(AnalyzeCatch, SyntaxKind.TryStatement);
        context.RegisterSyntaxNodeAction(AnalyzeObjectCreation, SyntaxKind.ObjectCreationExpression);
    }

    // PQJWT001 — a try that calls Validate(...) but catches a too-broad type.
    private static void AnalyzeCatch(SyntaxNodeAnalysisContext context)
    {
        var tryStmt = (TryStatementSyntax)context.Node;

        // Does the try block invoke something named Validate? (cheap syntactic gate)
        bool callsValidate = tryStmt.Block.DescendantNodes()
            .OfType<InvocationExpressionSyntax>()
            .Any(inv => inv.Expression is MemberAccessExpressionSyntax m &&
                        m.Name.Identifier.ValueText == "Validate");
        if (!callsValidate)
            return;

        foreach (var c in tryStmt.Catches)
        {
            // A catch with no declared type catches everything — too broad.
            if (c.Declaration is null)
            {
                context.ReportDiagnostic(Diagnostic.Create(CatchTooBroad, c.GetLocation(), "everything"));
                continue;
            }

            var caught = context.SemanticModel.GetTypeInfo(c.Declaration.Type, context.CancellationToken).Type;
            if (caught is null)
                continue;

            string name = caught.Name;
            // Flag Exception and the PqJwtException base, but NOT the correct specific type.
            if (name is "Exception" or "SystemException" or "PqJwtException")
            {
                context.ReportDiagnostic(Diagnostic.Create(CatchTooBroad, c.Declaration.Type.GetLocation(), caught.ToDisplayString()));
            }
        }
    }

    // PQJWT002 — new PqJwtValidationParameters { ... } with neither key member set.
    private static void AnalyzeObjectCreation(SyntaxNodeAnalysisContext context)
    {
        var creation = (ObjectCreationExpressionSyntax)context.Node;

        var type = context.SemanticModel.GetTypeInfo(creation, context.CancellationToken).Type;
        if (type?.Name != "PqJwtValidationParameters")
            return;

        // Only analyze the object-initializer form; a parameters object populated
        // elsewhere is beyond this simple check (documented limitation).
        if (creation.Initializer is null)
            return;

        bool hasKeySource = creation.Initializer.Expressions
            .OfType<AssignmentExpressionSyntax>()
            .Select(a => (a.Left as IdentifierNameSyntax)?.Identifier.ValueText)
            .Any(n => n is "SignatureVerificationKey" or "SignatureKeyResolver");

        if (!hasKeySource)
        {
            context.ReportDiagnostic(Diagnostic.Create(MissingKeySource, creation.GetLocation()));
        }
    }
}
