# Library patch: validation metrics in `PqJwtValidator` (Gemini #2)

This is a **proposed change to library source** (`src/PostQuantum.Jwt/PqJwtValidator.cs`),
not a sample. Apply it, build, and run the existing 79 tests before shipping.

## Files here

- `PqJwtValidator.original.cs` — the file you gave me, unchanged (for diffing).
- `PqJwtValidator.cs` — the patched version. Diff them, or replace your source
  after review.

## What it does

Adds OpenTelemetry-compatible metrics via `System.Diagnostics.Metrics` (no new
package dependency — consumers opt in with their own OTel/meter listener):

- Meter name: `PostQuantum.Jwt`
- Counter: `pqjwt.validations`, tagged:
  - `outcome` = `success` | `failure`
  - `reason` (failures only) = `signature_mismatch`, `expired`, `replay_detected`,
    `audience_mismatch`, `algorithm_not_accepted`, `unknown_kid`,
    `decryption_failed`, … (a small, fixed, bounded-cardinality vocabulary)

## Why it's safe

- **Validation logic is untouched.** The fail-closed control flow is byte-for-byte
  identical; instrumentation sits only at the single `Validate()` boundary that
  every path already funnels through. Success is counted only after all checks
  pass; failures are counted in the two existing catch blocks.
- **No sensitive data.** The `reason` tag is derived from a fixed mapping of the
  library's own exception messages to coarse codes. No token, claim value, key
  material, `jti`, issuer, or audience value is ever emitted — only the category.
- **Bounded cardinality.** `reason` is a closed set, so it won't explode a
  metrics backend.

## Two things for your review

1. **Message-coupling.** `Categorize(message)` matches on the validator's own
   message strings. If you change a throw message, update the matching arm.
   (Cleaner long-term: emit a structured reason enum at each throw site and tag
   from that — but that touches ~15 sites; this single-boundary approach was the
   minimal, low-risk change you asked for.)
2. **Meter version string** is hardcoded `"1.0.0"`. Wire it to your assembly
   version if you prefer.

## Consumer wiring (OpenTelemetry)

```csharp
builder.Services.AddOpenTelemetry().WithMetrics(m => m
    .AddMeter("PostQuantum.Jwt")        // <-- the meter name above
    .AddPrometheusExporter());          // or OTLP, console, etc.
```

A dashboard can then alert on `pqjwt.validations{outcome="failure",reason="signature_mismatch"}`
spiking — a live forgery signal — without logging anything sensitive.

---

*To God be the glory — 1 Corinthians 10:31.*
