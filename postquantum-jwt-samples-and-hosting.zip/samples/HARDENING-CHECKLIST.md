# JWT attack → how PostQuantum.Jwt blocks it

A defensive map of the classic JWT attacks (the ones in every bug-bounty guide)
against this library's behavior. The recurring theme: most of these are
*impossible by design* here, not "mitigated if configured." Where a row depends
on you, it says so.

| # | Attack | Blocked? | Why / what you must do |
| - | ------ | -------- | ---------------------- |
| 1 | **`alg: none`** (strip the signature) | By design | There is no unsigned code path. The validator requires `ML-DSA-65` and verifies a real signature; a `none`/missing signature can't validate. |
| 2 | **Algorithm confusion** (RS256→HS256, sign with the public key as HMAC secret) | By design | One suite only. The validator does not trust the token's `alg` to pick a verification path, and ML-DSA is asymmetric — there is no symmetric secret to confuse it with. |
| 3 | **Weak HMAC secret** (brute-force `secret`/`password123`) | By design | No shared secret exists. Signing is ML-DSA-65 (asymmetric); there is nothing to crack offline. |
| 4 | **No expiration / `exp` not checked** | By design (default) | `exp` is validated, and `RequireExpiration` rejects tokens lacking it. Keep `ValidateLifetime` on. |
| 5 | **No revocation** (stateless token lives until expiry) | Architecture | A bare access token can't be revoked — that's inherent to stateless JWTs. Use short lifetimes + the refresh/rotation pattern (`RefreshTokenDemo/`) for real logout. |
| 6 | **Sensitive data in payload** (PII/role readable) | Your choice | Signed payloads are readable. Carry only `sub`; look up the rest server-side (`SECURE-USAGE.md`). Use `EncryptFor` if you need confidentiality. |
| 7 | **`kid` injection** (kid → SQL/path traversal) | By design + your resolver | `kid` is passed to *your* `SignatureKeyResolver` as an opaque lookup value; the library never feeds it to a query or file path. Don't build an injection into your own resolver — look it up in a fixed map / key ring. |
| 8 | **Role manipulation** (edit payload to `role: admin`) | By design | Editing any byte of the payload breaks the ML-DSA signature; validation fails closed. (And if you followed #6, there's no `role` in the token to edit.) |
| 9 | **Missing signature verification** (decode but don't verify) | By design | `Validate()` always verifies the signature before returning; there is no decode-only path. It throws on failure rather than returning a degraded result. |
| 10 | **Token replay** (reuse a captured token) | Opt-in | Set `RequireReplayProtection = true` + a `ReplayCache` (distributed across nodes — `DistributedReplayCache/`). Requires a `jti`. |
| 11 | **Cross-service token acceptance** | Your config | Pin `ValidIssuer` and `ValidAudience` so a token minted elsewhere isn't accepted here. |
| 12 | **Token theft via `localStorage` + XSS** | Architecture | Not a token property — keep the access token in memory and the refresh token in an `HttpOnly` cookie (`SECURE-USAGE.md`, `RefreshTokenDemo/`). |

## The honest caveat

This library is **preview, unaudited**, and uses **non-IANA-registered**
identifiers — so its tokens are deliberately **non-interoperable** with standard
JWT stacks. It's the right tool only when you control both issuer and verifier.
That non-interoperability is itself a hardening property against tooling that
expects standard JWTs, but it is a deliberate trade-off, not a free lunch.

---

*To God be the glory — 1 Corinthians 10:31.*
