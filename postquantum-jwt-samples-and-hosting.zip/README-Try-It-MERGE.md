# Exact "Try it" merge for your README.md

Placement decision (differs from the generic guide): insert the block **after
both top callouts** — the "Read this first" non-interop warning *and* the
"Status / preview" warning — and **immediately before** the `---` that precedes
`## Table of contents`.

Rationale: your two callouts are a deliberate honesty gate. A reader should hit
"these tokens are non-interoperable" and "preview, not audited" *before* being
invited to play. Putting "Try it" above them would invert your own priorities.
After them, "now go play" reads naturally.

---

## Step 1 — add a TOC entry

In `## Table of contents`, add this as the **first** list item (above `- [Why](#why)`):

```markdown
- [Try it](#-try-it)
```

(The anchor is `#-try-it` because the heading starts with the ▶ glyph; GitHub
strips the glyph and the leading space collapses to a single leading hyphen.)

---

## Step 2 — paste this block

Place it between the preview-status callout and the `---` line above the TOC:

```markdown

---

## ▶ Try it

**Play with post-quantum JWTs right now — no install:**

👉 **[Live Playground](https://pqjwt.systemslibrarian.dev)** — build a token,
toggle X-Wing encryption, paste any token to validate it, and see *why* an
invalid one is rejected.

<p align="center">
  <img src="docs/img/playground-why-rejected.png"
       alt="The Playground's 'Why was this rejected?' panel explaining a signature failure"
       width="720">
</p>

Prefer the terminal? The console demo's **Attack Mode** walks six realistic
forgery attempts — privilege escalation, `alg: none`, wrong key, expired,
missing `exp`, replay — and shows each one failing closed with a plain-language
reason.

<!-- Optional: uncomment once you've recorded a clean GIF (see docs/img/README.md).
     Left commented so the README renders without a broken-image icon until then.
<p align="center">
  <img src="docs/img/console-attack-mode.gif"
       alt="ConsoleDemo Attack Mode rejecting forged, expired, and replayed tokens"
       width="720">
</p>
-->

### Run the samples locally

```bash
git clone https://github.com/systemslibrarian/postquantum-jwt.git
cd postquantum-jwt

dotnet run --project samples/ConsoleDemo        # interactive, menu-driven
dotnet run --project samples/WebApiDemo         # minimal API (AddPqJwtBearer)
dotnet run --project samples/PqJwtPlayground    # the Blazor UI, locally
```

Requires the **.NET 10 SDK** and **OpenSSL 3.5+** (Linux) or a recent Windows —
the native ML-KEM / ML-DSA primitives need them, and every sample fails closed
with a clear message if they're missing.

| Sample | What it teaches | README |
| ------ | --------------- | ------ |
| **ConsoleDemo** | Every feature + Attack Mode with plain-language rejection reasons | [samples/ConsoleDemo](samples/ConsoleDemo/README.md) |
| **WebApiDemo** | Real ASP.NET Core integration, key directory, multi-service rotation | [samples/WebApiDemo](samples/WebApiDemo/README.md) |
| **PqJwtPlayground** | Interactive build/validate UI; deploy guide for going live | [samples/PqJwtPlayground](samples/PqJwtPlayground/README.md) |

> The Playground is a Blazor **Server** app (crypto runs server-side and needs
> OpenSSL 3.5+). Host it on Azure Container Apps with scale-to-zero
> ([DEPLOY.md](samples/PqJwtPlayground/DEPLOY.md)) and put it on a custom domain
> like `pqjwt.systemslibrarian.dev`
> ([CUSTOM-DOMAIN.md](samples/PqJwtPlayground/CUSTOM-DOMAIN.md)).

```

(The leading `---` in the block gives you the visual separator above the heading
that the generic guide suggested — already included, don't add a second one.)

---

## Before you commit — checklist

1. **`<LIVE_URL>` is real.** The block hardcodes `https://pqjwt.systemslibrarian.dev`.
   Don't push it until that domain actually resolves to your deployed app, or a
   reader's first click 404s on your most-visible page. If you haven't deployed
   yet, temporarily change the link text to "Live Playground (coming soon)" and
   drop the `href`.
2. **`docs/img/playground-why-rejected.png` exists.** This one IS embedded
   (not commented out), so a missing file = broken image. Capture it first
   (see `docs/img/README.md`), or comment this `<p>` block out too until you have it.
3. **The GIF stays commented** until recorded — already handled above.
4. **TOC entry added** (Step 1) so the table of contents stays complete.

---

*To God be the glory — 1 Corinthians 10:31.*
